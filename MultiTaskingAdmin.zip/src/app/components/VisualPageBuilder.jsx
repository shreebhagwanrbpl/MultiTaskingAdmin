'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Check,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Sparkles,
  Layers,
  Settings2,
  Globe,
  Save,
  RefreshCw,
  LayoutGrid,
  AlertCircle,
  Phone,
  ShieldCheck,
  Package,
  Building2,
  ExternalLink,
  Laptop,
  Tablet,
  Smartphone,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Palette,
  ArrowLeft,
  FileText,
  Sliders,
  RotateCcw,
  PanelLeftClose,
  PanelLeftOpen,
  Image as ImageIcon,
  Menu,
  Award,
  Zap,
  Activity,
  HeartPulse,
  Cpu,
  MessageSquare,
  HelpCircle,
  Copy,
  Code2,
  Code,
  PlusCircle,
  CheckCheck,
  Terminal,
  Dices,
  Wand2,
  GripVertical
} from 'lucide-react';
import { AVAILABLE_BLOCK_TYPES, getDefaultBlocksForSite, SITE_PAGES } from '../../data/pageBlocks';
import SiteThemeImporterModal from './SiteThemeImporterModal';

// Friendly Hindi/Hinglish section descriptions & badge titles
const SECTION_META = {
  announcement: {
    title: 'Top Notice Bar',
    hindi: 'Sabse upar ki alert / discount patti',
    icon: AlertCircle,
    color: 'text-amber-500 bg-amber-50'
  },
  header: {
    title: 'Header & Navigation Bar',
    hindi: 'Logo, Company Name, Menu & Contact Phone',
    icon: Layers,
    color: 'text-sky-500 bg-sky-50'
  },
  quickNav: {
    title: 'Floating Quick-Access Sidebar',
    hindi: 'Left side ka vertical quick-dock bar',
    icon: Menu,
    color: 'text-indigo-500 bg-indigo-50'
  },
  hero: {
    title: 'Main Hero Banner',
    hindi: 'Bada main banner, headline aur RFQ button',
    icon: Sparkles,
    color: 'text-indigo-500 bg-indigo-50'
  },
  trustBadges: {
    title: 'Trust & Certifications',
    hindi: 'ISO 13485, CE, GeM & AERB certified badges',
    icon: ShieldCheck,
    color: 'text-emerald-500 bg-emerald-50'
  },
  categories: {
    title: 'Clinical Specialty Grid',
    hindi: '12 Medical Departments & Category Cards',
    icon: Building2,
    color: 'text-purple-500 bg-purple-50'
  },
  topBrands: {
    title: 'Top Healthcare Brands',
    hindi: 'Philips, Omron, BPL, Nipro, BD, 3M logos',
    icon: Award,
    color: 'text-blue-500 bg-blue-50'
  },
  dealSpotlight: {
    title: 'Lightning Deals & Spotlight',
    hindi: 'Countdown timer aur discounted offer products',
    icon: Zap,
    color: 'text-amber-500 bg-amber-50'
  },
  trendingConsumables: {
    title: 'Hospital Consumables Shelf',
    hindi: 'Gloves, Syringes, Cannula, Infusion sets',
    icon: Package,
    color: 'text-emerald-500 bg-emerald-50'
  },
  diagnosticMachinery: {
    title: 'Diagnostic & Lab Machinery',
    hindi: 'Hematology, Biochemistry & Pathology units',
    icon: Activity,
    color: 'text-teal-500 bg-teal-50'
  },
  criticalCare: {
    title: 'ICU & Monitoring Systems',
    hindi: 'Ventilators, Monitors & Syringe Pumps',
    icon: HeartPulse,
    color: 'text-rose-500 bg-rose-50'
  },
  refurbishedEquipment: {
    title: 'Refurbished Imaging & Radiology',
    hindi: 'CT Scanners, 1.5T MRI, C-Arm systems',
    icon: Cpu,
    color: 'text-purple-500 bg-purple-50'
  },
  products: {
    title: 'Hardware Equipment Catalog',
    hindi: 'Biomedical devices, rate list aur quotation cards',
    icon: Package,
    color: 'text-blue-500 bg-blue-50'
  },
  customContent: {
    title: 'Custom Rich Text & Headline',
    hindi: 'Apna manchaha text, heading aur button',
    icon: FileText,
    color: 'text-indigo-500 bg-indigo-50'
  },
  customGrid: {
    title: 'Custom Feature Cards Grid',
    hindi: '2, 3 ya 4 column feature cards grid',
    icon: LayoutGrid,
    color: 'text-sky-500 bg-sky-50'
  },
  customBanner: {
    title: 'Custom Promotional Banner',
    hindi: 'Bada image banner aur callout button',
    icon: ImageIcon,
    color: 'text-purple-500 bg-purple-50'
  },
  customEmbed: {
    title: 'Custom Code / HTML / Widget',
    hindi: 'Raw HTML, Tailwind, map iframe ya video embed',
    icon: Code2,
    color: 'text-amber-500 bg-amber-50'
  },
  customCta: {
    title: 'High-Converting Call-To-Action',
    hindi: 'Dual button CTA box aur badge',
    icon: Sparkles,
    color: 'text-rose-500 bg-rose-50'
  },
  turnkeySolutions: {
    title: 'Turnkey Hospital Setup Package',
    hindi: 'Complete Modular OT & ICU setup offer',
    icon: LayoutGrid,
    color: 'text-teal-500 bg-teal-50'
  },
  testimonials: {
    title: 'Doctor & Hospital Testimonials',
    hindi: 'Medical director reviews aur 5-star ratings',
    icon: MessageSquare,
    color: 'text-indigo-500 bg-indigo-50'
  },
  faqs: {
    title: 'Frequently Asked Questions (FAQ)',
    hindi: 'Ordering, delivery, warranty aur GeM FAQs',
    icon: HelpCircle,
    color: 'text-slate-600 bg-slate-100'
  },
  rfqBanner: {
    title: 'Instant RFQ / Quotation Callout',
    hindi: 'Doctor quotation inquiry callout box',
    icon: Phone,
    color: 'text-rose-500 bg-rose-50'
  },
  contactDesk: {
    title: 'Biomedical Helpdesk & Hubs',
    hindi: 'Regional warehouse address aur support phone',
    icon: Globe,
    color: 'text-cyan-500 bg-cyan-50'
  },
  footer: {
    title: 'Compliance & Legal Footer',
    hindi: 'Copyright, NABH disclaimer aur policy links',
    icon: Settings2,
    color: 'text-slate-600 bg-slate-100'
  }
};

const THEME_PALETTES = [
  { name: 'Medikabazaar Navy', color: '#182A54' },
  { name: 'Sky Clinical', color: '#0ea5e9' },
  { name: 'Emerald Bio', color: '#059669' },
  { name: 'High-Tech Indigo', color: '#4f46e5' },
  { name: 'Emergency Rose', color: '#e11d48' },
  { name: 'Precision Violet', color: '#7c3aed' },
  { name: 'Clinical Amber', color: '#d97706' }
];

export const UI_ARCHETYPES = [
  {
    id: 'enterprise_b2b',
    name: 'Enterprise B2B',
    icon: '🏢',
    desc: 'Two-tier telemetry bar, split B2B showcase & clean bordered minimal cards',
    config: {
      headerStyle: 'Telemetry Bar',
      homepageLayout: 'Split Sidebar B2B',
      cardStyle: 'Bordered Minimal',
      font: 'Inter',
      primaryColor: '#0f172a'
    }
  },
  {
    id: 'nordic_glass',
    name: 'Nordic Glassmorphism',
    icon: '💎',
    desc: 'Floating pill navbar, centered grand impact hero & frosted glass cards',
    config: {
      headerStyle: 'Sticky Floating Pill',
      homepageLayout: 'Centered Grand Impact',
      cardStyle: 'Glassmorphic Modern',
      font: 'Outfit',
      primaryColor: '#0284c7'
    }
  },
  {
    id: 'ecommerce_catalog',
    name: 'E-Commerce Portal',
    icon: '⚡',
    desc: 'Centered search catalog bar, promotional banner hero & gradient accent cards',
    config: {
      headerStyle: 'Centered Search',
      homepageLayout: 'Banner Carousel',
      cardStyle: 'B2B Row Table',
      font: 'Plus Jakarta Sans',
      primaryColor: '#059669'
    }
  },
  {
    id: 'biotech_dark',
    name: 'Biotech High-Tech',
    icon: '🌙',
    desc: 'Floating pill navbar, split clinical hero & glass cards with biotech violet',
    config: {
      headerStyle: 'Sticky Floating Pill',
      homepageLayout: 'Split Sidebar B2B',
      cardStyle: 'Glassmorphic Modern',
      font: 'Space Grotesk',
      primaryColor: '#7c3aed'
    }
  },
  {
    id: 'emergency_trauma',
    name: 'Emergency Trauma',
    icon: '🚨',
    desc: 'Telemetry dispatch bar, centered impact hero & 3D floating shadow cards',
    config: {
      headerStyle: 'Telemetry Bar',
      homepageLayout: 'Centered Grand Impact',
      cardStyle: 'Floating Shadow',
      font: 'Poppins',
      primaryColor: '#e11d48'
    }
  }
];

export const PRESET_HEADER_STYLES = [
  { value: 'Sticky Floating Pill', label: 'Floating Pill Navbar (Apple/Linear SaaS)' },
  { value: 'Minimalist Single Row', label: 'Minimalist Single Row (Nordic Clean)' },
  { value: 'Centered Search', label: 'Centered Search Bar (E-Commerce Portal)' },
  { value: 'Telemetry Bar', label: 'Two-Tier Telemetry Bar (Enterprise B2B)' }
];

export const PRESET_HERO_STYLES = [
  { value: 'Centered Grand Impact', label: 'Centered Grand Impact (Pill Badges + Stat Grid)' },
  { value: 'Split Sidebar B2B', label: 'Split 2-Column B2B (Headline + Rapid Hotline Box)' },
  { value: 'Banner Carousel', label: 'Banner Showcase (Full Promotional Banner Hero)' }
];

export const PRESET_CARD_STYLES = [
  { value: 'Floating Shadow', label: 'Floating Shadow (3D Lift Elevation)' },
  { value: 'Glassmorphic Modern', label: 'Glassmorphic Modern (Frosted Glass & Blur)' },
  { value: 'B2B Row Table', label: 'Top Accent Border (Hospital Procurement)' },
  { value: 'Bordered Minimal', label: 'Bordered Minimal (Clean 1px Precision)' }
];

export const PRESET_FONTS = [
  { value: 'Plus Jakarta Sans', label: 'Plus Jakarta Sans (Modern Medical)' },
  { value: 'Outfit', label: 'Outfit (High-Tech Geometric)' },
  { value: 'Inter', label: 'Inter (Clean Neutral)' },
  { value: 'Space Grotesk', label: 'Space Grotesk (Biotech Tech)' },
  { value: 'Poppins', label: 'Poppins (Friendly & Clean)' },
  { value: 'Manrope', label: 'Manrope (Swiss Precision)' }
];

export default function VisualPageBuilder({ site, isOpen, onClose, onSaveSuccess, existingSites = [] }) {
  if (!isOpen || !site) return null;

  // Initialize site state (allows modifying primaryColor & brandName right in builder)
  const [currentSite, setCurrentSite] = useState(() => ({ ...site }));

  // UI Archetypes & Design Panel Collapsible state
  const [showUiDesignPanel, setShowUiDesignPanel] = useState(true);
  const [randomUiToast, setRandomUiToast] = useState('');

  // Active Multi-Page state ('home' | 'shop' | 'equipment' | 'rfq' | 'about' | 'contact' | custom slug)
  const [activePage, setActivePage] = useState('home');

  // Custom Created Pages
  const [customPages, setCustomPages] = useState(() => currentSite.customPages || []);
  const [showAddPageModal, setShowAddPageModal] = useState(false);
  const [newPageName, setNewPageName] = useState('');
  const [newPageSlug, setNewPageSlug] = useState('');

  // Developer Custom CSS panel toggle
  const [showCssEditor, setShowCssEditor] = useState(false);

  // Initialize blocks
  const [blocks, setBlocks] = useState(() => {
    if (site.layoutBlocks && Array.isArray(site.layoutBlocks) && site.layoutBlocks.length > 0) {
      return site.layoutBlocks;
    }
    return getDefaultBlocksForSite(site);
  });

  // Selected / Expanded Accordion Block ID
  const [expandedBlockId, setExpandedBlockId] = useState(() => {
    if (site.layoutBlocks && site.layoutBlocks.length > 0) {
      return site.layoutBlocks[0].id;
    }
    return 'block-hero';
  });

  // Sidebar Expand / Collapse Toggle (for full page view)
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Viewport Device: 'desktop' | 'tablet' | 'mobile'
  const [deviceViewport, setDeviceViewport] = useState('desktop');

  // Saving states
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [addBlockOpen, setAddBlockOpen] = useState(false);
  const [isImporterOpen, setIsImporterOpen] = useState(false);
  const [previewReloadKey, setPreviewReloadKey] = useState(Date.now());

  // HTML5 Drag & Drop reordering state (Utha ke knhi bhi chipka diya)
  const [draggedBlockIndex, setDraggedBlockIndex] = useState(null);
  const [dragOverBlockIndex, setDragOverBlockIndex] = useState(null);

  const handleDragStart = (e, index) => {
    setDraggedBlockIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverBlockIndex !== index) {
      setDragOverBlockIndex(index);
    }
  };

  const handleDragLeave = () => {
    setDragOverBlockIndex(null);
  };

  const handleDrop = (e, targetIndex) => {
    e.preventDefault();
    if (draggedBlockIndex === null || draggedBlockIndex === targetIndex) {
      setDraggedBlockIndex(null);
      setDragOverBlockIndex(null);
      return;
    }

    const reordered = [...blocks];
    const [draggedItem] = reordered.splice(draggedBlockIndex, 1);
    reordered.splice(targetIndex, 0, draggedItem);

    setBlocks(reordered);
    setDraggedBlockIndex(null);
    setDragOverBlockIndex(null);
  };

  const iframeRef = useRef(null);

  // In-Preview Direct Click-to-Edit Listener & Page Change Listener
  useEffect(() => {
    const handleMessage = (e) => {
      if (e.data?.type === 'SECTION_SELECT' && e.data?.blockType) {
        const targetType = e.data.blockType;
        const targetBlock = blocks.find(b => b.type === targetType);
        if (targetBlock) {
          setIsSidebarCollapsed(false); // Auto expand sidebar so user can edit instantly
          setExpandedBlockId(targetBlock.id);
          setTimeout(() => {
            const cardEl = document.getElementById(`section-card-${targetBlock.id}`);
            if (cardEl) {
              cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
              cardEl.classList.add('ring-4', 'ring-sky-400');
              setTimeout(() => {
                cardEl.classList.remove('ring-4', 'ring-sky-400');
              }, 1200);
            }
          }, 50);
        }
      }

      if (e.data?.type === 'PAGE_CHANGED' && e.data?.page) {
        setActivePage(e.data.page);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [blocks]);

  // Handle Switch Page from Top Select or navigation
  const handleSwitchPage = (pageId) => {
    setActivePage(pageId);
    if (iframeRef.current && iframeRef.current.contentWindow) {
      iframeRef.current.contentWindow.postMessage({
        type: 'SET_ACTIVE_PAGE',
        page: pageId
      }, '*');
    }
  };

  // Sync state to localStorage & broadcast via postMessage to iframe for real-time live preview
  useEffect(() => {
    try {
      const previewPayload = {
        ...currentSite,
        layoutBlocks: blocks,
        activePage: activePage,
        customCss: currentSite.customCss,
        customPages: customPages,
        primaryColor: currentSite.primaryColor,
        brandName: currentSite.brandName,
        tagline: currentSite.tagline,
        heroTitle: currentSite.heroTitle,
        phone: currentSite.phone,
        email: currentSite.email,
        city: currentSite.city,
        logo: currentSite.logo,
        bannerImage: currentSite.bannerImage,
        categories: currentSite.categories,
        customProducts: currentSite.customProducts,
        font: currentSite.font,
        headerStyle: currentSite.headerStyle,
        homepageLayout: currentSite.homepageLayout,
        cardStyle: currentSite.cardStyle
      };
      localStorage.setItem(`preview_override_${site.domain}`, JSON.stringify(previewPayload));

      if (iframeRef.current && iframeRef.current.contentWindow) {
        iframeRef.current.contentWindow.postMessage({
          type: 'BUILDER_LIVE_UPDATE',
          payload: previewPayload
        }, '*');
      }
    } catch (e) {
      // fallback
    }
  }, [blocks, currentSite, site.domain, activePage, customPages]);

  // Handle Apply Extracted Theme from Live URL or Local HTML
  const handleApplyExtractedTheme = (resultOrData, maybeBlocks) => {
    if (!resultOrData) return;
    const extractedData = resultOrData.extractedData || resultOrData;
    const layoutBlocks = resultOrData.layoutBlocks || maybeBlocks;

    setCurrentSite(prev => ({
      ...prev,
      brandName: extractedData.brandName || prev.brandName,
      tagline: extractedData.tagline || prev.tagline,
      heroTitle: extractedData.heroTitle || prev.heroTitle,
      primaryColor: extractedData.primaryColor || prev.primaryColor,
      phone: extractedData.phone || prev.phone,
      email: extractedData.email || prev.email,
      categoryFocus: extractedData.categoryFocus || prev.categoryFocus,
      headerStyle: extractedData.headerStyle || prev.headerStyle,
      homepageLayout: extractedData.homepageLayout || prev.homepageLayout,
      font: extractedData.font || prev.font,
      logo: extractedData.logo || prev.logo,
      bannerImage: extractedData.bannerImage || prev.bannerImage,
      categories: extractedData.categories || prev.categories,
      customProducts: extractedData.customProducts || prev.customProducts
    }));

    if (layoutBlocks && layoutBlocks.length > 0) {
      setBlocks(layoutBlocks);
      setExpandedBlockId(layoutBlocks[0].id);
    }

    setPreviewReloadKey(Date.now());
  };

  // Reordering blocks
  const moveBlock = (index, direction) => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= blocks.length) return;

    const newBlocks = [...blocks];
    const [moved] = newBlocks.splice(index, 1);
    newBlocks.splice(targetIndex, 0, moved);
    setBlocks(newBlocks);
  };

  // Duplicate / Clone block
  const duplicateBlock = (index) => {
    const blockToClone = blocks[index];
    const clonedBlock = {
      ...JSON.parse(JSON.stringify(blockToClone)),
      id: `block-${blockToClone.type}-${Math.random().toString(36).substr(2, 6)}`,
      name: `${blockToClone.name || blockToClone.type} (Copy)`
    };
    const newBlocks = [...blocks];
    newBlocks.splice(index + 1, 0, clonedBlock);
    setBlocks(newBlocks);
    setExpandedBlockId(clonedBlock.id);
  };

  // Toggle block visibility
  const toggleBlockVisibility = (id) => {
    setBlocks(blocks.map(b => b.id === id ? { ...b, enabled: !b.enabled } : b));
  };

  // Delete block
  const deleteBlock = (id) => {
    if (blocks.length <= 1) {
      alert('You must have at least one block on the page!');
      return;
    }
    setBlocks(blocks.filter(b => b.id !== id));
  };

  // Update block internal data
  const updateBlockData = (blockId, key, value) => {
    setBlocks(blocks.map(b => {
      if (b.id !== blockId) return b;
      return {
        ...b,
        data: {
          ...b.data,
          [key]: value
        }
      };
    }));
  };

  // Add block to page
  const handleAddBlock = (blockType) => {
    const typeDef = AVAILABLE_BLOCK_TYPES.find(t => t.type === blockType);
    if (!typeDef) return;

    const newBlock = {
      id: `block-${blockType}-${Math.random().toString(36).substr(2, 6)}`,
      type: typeDef.type,
      name: typeDef.name,
      enabled: true,
      data: { ...typeDef.defaultData }
    };

    setBlocks([...blocks, newBlock]);
    setExpandedBlockId(newBlock.id);
    setAddBlockOpen(false);
  };

  // Create New Custom Page
  const handleCreatePage = (e) => {
    e?.preventDefault();
    if (!newPageName.trim()) return;
    const slug = (newPageSlug.trim() || newPageName.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-'));
    const pageObj = {
      id: slug,
      name: `📄 ${newPageName.trim()}`,
      slug: `/${slug}`,
      description: `Custom ${newPageName.trim()} page`
    };
    const updatedPages = [...customPages, pageObj];
    setCustomPages(updatedPages);
    setCurrentSite(prev => ({
      ...prev,
      customPages: updatedPages
    }));
    setActivePage(slug);
    setNewPageName('');
    setNewPageSlug('');
    setShowAddPageModal(false);
  };

  // Category management
  const handleAddCategory = () => {
    const newCat = {
      id: `cat-${Date.now()}`,
      name: 'New Department',
      desc: 'Biomedical devices & consumables',
      icon: '🏥',
      image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=300&q=80'
    };
    const existingCats = currentSite.categories || [];
    setCurrentSite(prev => ({ ...prev, categories: [...existingCats, newCat] }));
  };

  const handleDeleteCategory = (catId) => {
    const existingCats = currentSite.categories || [];
    setCurrentSite(prev => ({ ...prev, categories: existingCats.filter(c => (c.id || c.name) !== catId) }));
  };

  // Custom Products management
  const handleAddProduct = () => {
    const newProd = {
      id: `prod-${Date.now()}`,
      sku: `BIO-${Math.floor(1000 + Math.random() * 9000)}`,
      name: 'High-Acuity ICU Station System',
      brand: currentSite.brandName || 'BioMed',
      price: 245000,
      category: 'all',
      badge: 'Verified OEM',
      shortDesc: 'Precision clinical device with factory calibration and 2-Year OEM Warranty.',
      image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=600&q=80'
    };
    const existingProds = currentSite.customProducts || [];
    setCurrentSite(prev => ({ ...prev, customProducts: [newProd, ...existingProds] }));
  };

  const handleDeleteProduct = (prodId) => {
    const existingProds = currentSite.customProducts || [];
    setCurrentSite(prev => ({ ...prev, customProducts: existingProds.filter(p => p.id !== prodId) }));
  };

  // Hero Banner Slides Management (Carousel / Slider)
  const handleAddHeroSlide = (blockId) => {
    const block = blocks.find(b => b.id === blockId);
    const existingSlides = (block?.data?.slides && block.data.slides.length > 0)
      ? block.data.slides
      : [
          { id: 1, image: block?.data?.bannerImage || currentSite.bannerImage || 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1600&auto=format&fit=crop&q=80', title: 'ICU Critical Care & Ventilators' },
          { id: 2, image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=1600&auto=format&fit=crop&q=80', title: 'Modular Operation Theatre Suite' }
        ];

    const newSlide = {
      id: Date.now(),
      image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=1600&auto=format&fit=crop&q=80',
      title: `Banner Slide ${existingSlides.length + 1}`
    };

    updateBlockData(blockId, 'slides', [...existingSlides, newSlide]);
  };

  const handleDeleteHeroSlide = (blockId, slideId) => {
    const block = blocks.find(b => b.id === blockId);
    const existingSlides = block?.data?.slides || [];
    updateBlockData(blockId, 'slides', existingSlides.filter(s => s.id !== slideId));
  };

  const handleUpdateHeroSlide = (blockId, slideId, field, val) => {
    const block = blocks.find(b => b.id === blockId);
    const existingSlides = block?.data?.slides || [];
    updateBlockData(blockId, 'slides', existingSlides.map(s => s.id === slideId ? { ...s, [field]: val } : s));
  };

  // Top Brands management
  const handleAddBrand = (blockId) => {
    const block = blocks.find(b => b.id === blockId);
    const existingBrands = block?.data?.brands || [
      { name: 'Omron Healthcare', discount: '35% OFF', category: 'Digital Diagnostics' },
      { name: 'Philips Medical', discount: '25% OFF', category: 'ICU Telemetry' },
      { name: 'BPL Medical', discount: '30% OFF', category: 'Cardiology' }
    ];
    updateBlockData(blockId, 'brands', [...existingBrands, {
      name: 'New Healthcare Brand',
      discount: '30% OFF',
      category: 'Biomedical & ICU'
    }]);
  };

  const handleDeleteBrand = (blockId, brandIndex) => {
    const block = blocks.find(b => b.id === blockId);
    const existingBrands = block?.data?.brands || [];
    updateBlockData(blockId, 'brands', existingBrands.filter((_, i) => i !== brandIndex));
  };

  // Testimonials management
  const handleAddTestimonial = (blockId) => {
    const block = blocks.find(b => b.id === blockId);
    const existing = block?.data?.items || [
      { id: 't-1', doctor: 'Dr. Rajesh Sharma', role: 'Head of Critical Care', hospital: 'Apollo Hospitals, Delhi', quote: 'Standardized our ICU with their monitors. Zero breakdown in 18 months.', rating: 5 }
    ];
    updateBlockData(blockId, 'items', [...existing, {
      id: `t-${Date.now()}`,
      doctor: 'Dr. Anita Verma, MD',
      role: 'Medical Director',
      hospital: 'Fortis Healthcare',
      quote: 'Prompt dispatch and OEM calibrated setup. Excellent institutional procurement partner.',
      rating: 5
    }]);
  };

  const handleDeleteTestimonial = (blockId, tId) => {
    const block = blocks.find(b => b.id === blockId);
    const existing = block?.data?.items || [];
    updateBlockData(blockId, 'items', existing.filter(t => t.id !== tId));
  };

  // FAQs management
  const handleAddFaq = (blockId) => {
    const block = blocks.find(b => b.id === blockId);
    const existing = block?.data?.items || [
      { q: 'What is the standard delivery timeline for hospital batches?', a: 'High-frequency consumables dispatch in 24 hours. Capital machinery commissions within 3 to 7 business days.' }
    ];
    updateBlockData(blockId, 'items', [...existing, {
      q: 'Can we request customized Bill of Quantities (BOQ) with GST invoices?',
      a: 'Yes, full commercial 18% GST invoices and institutional BOQ sheets are generated immediately upon request.'
    }]);
  };

  const handleDeleteFaq = (blockId, faqIndex) => {
    const block = blocks.find(b => b.id === blockId);
    const existing = block?.data?.items || [];
    updateBlockData(blockId, 'items', existing.filter((_, i) => i !== faqIndex));
  };

  // Custom Grid Items management
  const handleAddGridItem = (blockId) => {
    const block = blocks.find(b => b.id === blockId);
    const items = block?.data?.items || [];
    const newItem = {
      id: `item-${Date.now()}`,
      title: 'New Feature Advantage',
      desc: 'Engineered for reliability, zero breakdown downtime, and regulatory compliance.'
    };
    updateBlockData(blockId, 'items', [...items, newItem]);
  };

  const handleDeleteGridItem = (blockId, itemId) => {
    const block = blocks.find(b => b.id === blockId);
    const items = block?.data?.items || [];
    updateBlockData(blockId, 'items', items.filter(it => it.id !== itemId));
  };

  // Randomize / Shuffle Fresh UI Look (Har Baar Alag UI)
  const handleRandomizeUiLook = () => {
    const headers = ['Sticky Floating Pill', 'Minimalist Single Row', 'Centered Search', 'Telemetry Bar'];
    const heros = ['Centered Grand Impact', 'Split Sidebar B2B', 'Banner Carousel'];
    const cards = ['Floating Shadow', 'Glassmorphic Modern', 'B2B Row Table', 'Bordered Minimal'];
    const fonts = ['Outfit', 'Plus Jakarta Sans', 'Inter', 'Space Grotesk', 'Poppins', 'Manrope'];
    const colors = ['#0ea5e9', '#059669', '#7c3aed', '#e11d48', '#0d9488', '#d97706', '#182A54', '#0f172a', '#2563eb'];

    const randomPick = (arr, curr) => {
      const filtered = arr.filter(item => item !== curr);
      return filtered[Math.floor(Math.random() * filtered.length)] || arr[Math.floor(Math.random() * arr.length)];
    };

    const newHeader = randomPick(headers, currentSite.headerStyle);
    const newHero = randomPick(heros, currentSite.homepageLayout);
    const newCard = randomPick(cards, currentSite.cardStyle);
    const newFont = randomPick(fonts, currentSite.font);
    const newColor = randomPick(colors, currentSite.primaryColor);

    setCurrentSite(prev => ({
      ...prev,
      headerStyle: newHeader,
      homepageLayout: newHero,
      cardStyle: newCard,
      font: newFont,
      primaryColor: newColor
    }));

    setRandomUiToast(`🎲 Generated Fresh UI: ${newHeader.split(' ')[0]} + ${newHero.split(' ')[0]} + ${newCard.split(' ')[0]}`);
    setTimeout(() => setRandomUiToast(''), 4000);
  };

  // Apply Predefined UI Archetype
  const handleApplyArchetype = (archetype) => {
    setCurrentSite(prev => ({
      ...prev,
      ...archetype.config
    }));
    setRandomUiToast(`✨ Applied "${archetype.name}" UI Archetype!`);
    setTimeout(() => setRandomUiToast(''), 4000);
  };

  // Reset blocks to system defaults
  const handleResetToDefault = () => {
    if (confirm('Reset all sections back to standard biomedical defaults? Any custom edits will be restored to template defaults.')) {
      const defaults = getDefaultBlocksForSite(currentSite);
      setBlocks(defaults);
      setExpandedBlockId(defaults[0]?.id || 'block-hero');
    }
  };

  // Save to MongoDB Atlas via /api/sites PUT
  const handleSaveToMongo = async () => {
    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const payload = {
        ...currentSite,
        domain: site.domain,
        layoutBlocks: blocks,
        activePage: activePage,
        customCss: currentSite.customCss,
        customPages: customPages,
        primaryColor: currentSite.primaryColor,
        brandName: currentSite.brandName,
        tagline: currentSite.tagline,
        heroTitle: currentSite.heroTitle,
        phone: currentSite.phone,
        email: currentSite.email,
        city: currentSite.city,
        logo: currentSite.logo,
        bannerImage: currentSite.bannerImage,
        categories: currentSite.categories,
        customProducts: currentSite.customProducts,
        font: currentSite.font,
        headerStyle: currentSite.headerStyle,
        homepageLayout: currentSite.homepageLayout,
        cardStyle: currentSite.cardStyle
      };

      const res = await fetch('/api/sites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (data.success) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
        if (onSaveSuccess) {
          onSaveSuccess(blocks, { ...currentSite, layoutBlocks: blocks, customCss: currentSite.customCss, customPages });
        }
      } else {
        alert(`Failed to save layout: ${data.error}`);
      }
    } catch (err) {
      alert(`Network error saving layout: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-100 flex flex-col w-screen h-screen overflow-hidden select-none animate-in fade-in duration-150">
      
      {/* =========================================================================
          TOP NAVIGATION BAR (FULL WIDTH STUDIO HEADER)
          ========================================================================= */}
      <header className="h-14 px-4 bg-white border-b border-slate-200 flex items-center justify-between gap-3 shrink-0 shadow-xs z-30">
        
        {/* Left: Back to Dashboard & Site Identity */}
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold border border-slate-200 transition cursor-pointer shadow-2xs"
            title="Return to Super-Admin Dashboard"
          >
            <ArrowLeft size={14} className="text-slate-500" />
            <span className="hidden sm:inline">Back to Dashboard</span>
          </button>

          <div className="h-5 w-px bg-slate-200 hidden sm:block" />

          {/* Domain & Brand Pill */}
          <div className="flex items-center gap-2">
            <span 
              className="w-3.5 h-3.5 rounded-full ring-2 ring-slate-200 shrink-0"
              style={{ backgroundColor: currentSite.primaryColor || '#0ea5e9' }}
            />
            <span className="font-bold text-slate-800 text-sm hidden md:inline">
              {currentSite.brandName}
            </span>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded-md bg-sky-50 text-sky-700 border border-sky-200">
              {currentSite.domain}
            </span>
          </div>
        </div>

        {/* Center: Multi-Page Switcher & Device Viewport */}
        <div className="flex items-center gap-2">
          {/* Multi-Page Selector Dropdown with + New Page button */}
          <div className="flex items-center gap-1.5">
            <div className="flex items-center bg-slate-100 px-2 py-1 rounded-xl border border-slate-200 text-xs">
              <span className="text-[11px] font-bold text-slate-500 mr-1.5 hidden md:inline">Page:</span>
              <select
                value={activePage}
                onChange={(e) => handleSwitchPage(e.target.value)}
                className="bg-white text-xs font-bold text-slate-800 rounded-lg px-2.5 py-1 border border-slate-200 outline-none cursor-pointer hover:border-sky-400"
              >
                <option value="home">🏠 Storefront Home (All Blocks)</option>
                <option value="shop">🛍️ Shop / Clinical Catalog</option>
                <option value="equipment">🏥 Medical Machinery & Refurbished</option>
                <option value="rfq">📋 B2B Bulk Order & RFQ Portal</option>
                <option value="about">ℹ️ About Us & Compliance</option>
                <option value="contact">📞 Helpdesk & Service Desks</option>
                {customPages.map(cp => (
                  <option key={cp.id} value={cp.id}>{cp.name}</option>
                ))}
              </select>
            </div>
            <button
              onClick={() => setShowAddPageModal(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-sky-50 hover:text-sky-700 hover:border-sky-300 border border-slate-200 text-slate-700 text-xs font-bold transition cursor-pointer"
              title="Create New Custom Page"
            >
              <Plus size={12} />
              <span className="hidden lg:inline">Page</span>
            </button>
          </div>

          {/* Viewport Switcher */}
          <div className="hidden sm:flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
            <button
              onClick={() => setDeviceViewport('desktop')}
              className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 transition cursor-pointer ${
                deviceViewport === 'desktop' ? 'bg-white text-sky-700 shadow-xs border border-slate-200/80' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Laptop size={13} />
              <span className="hidden md:inline">Desktop</span>
            </button>
            <button
              onClick={() => setDeviceViewport('tablet')}
              className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 transition cursor-pointer ${
                deviceViewport === 'tablet' ? 'bg-white text-sky-700 shadow-xs border border-slate-200/80' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Tablet size={13} />
            </button>
            <button
              onClick={() => setDeviceViewport('mobile')}
              className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 transition cursor-pointer ${
                deviceViewport === 'mobile' ? 'bg-white text-sky-700 shadow-xs border border-slate-200/80' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Smartphone size={13} />
            </button>
          </div>
        </div>

        {/* Right: Full Canvas Toggle, Custom CSS, Import Theme, Save to MongoDB */}
        <div className="flex items-center gap-2">
          {/* Developer Custom CSS Button */}
          <button
            onClick={() => setShowCssEditor(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border shadow-2xs ${
              currentSite.customCss?.trim()
                ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100 ring-2 ring-amber-200'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
            title="Custom CSS & Developer Styling"
          >
            <Code size={14} className={currentSite.customCss?.trim() ? "text-amber-600" : "text-slate-600"} />
            <span className="hidden sm:inline">Custom CSS</span>
            {currentSite.customCss?.trim() && (
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
            )}
          </button>

          {/* Full Canvas Toggle Button */}
          <button
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border shadow-2xs ${
              isSidebarCollapsed
                ? 'bg-sky-50 text-sky-700 border-sky-300 hover:bg-sky-100 ring-2 ring-sky-200'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
            title={isSidebarCollapsed ? "Show Controls Sidebar" : "Full Canvas Mode (100% Full Screen View)"}
          >
            {isSidebarCollapsed ? <PanelLeftOpen size={14} className="text-sky-600" /> : <PanelLeftClose size={14} />}
            <span className="hidden sm:inline">{isSidebarCollapsed ? "Show Controls" : "Full Canvas"}</span>
          </button>

          {/* Import / Clone Theme */}
          <button
            onClick={() => setIsImporterOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-xs font-semibold transition cursor-pointer shadow-2xs"
            title="Import Live Website URL or Paste HTML"
          >
            <Sparkles size={14} className="text-purple-600" />
            <span className="hidden md:inline">Import / Clone Theme</span>
          </button>

          {/* Reset Template */}
          <button
            onClick={handleResetToDefault}
            className="p-1.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-500 hover:text-slate-700 border border-slate-200 transition cursor-pointer"
            title="Reset to Template Defaults"
          >
            <RotateCcw size={14} />
          </button>

          {/* Save to MongoDB Atlas */}
          <button
            onClick={handleSaveToMongo}
            disabled={isSaving}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-bold text-white transition shadow-sm cursor-pointer ${
              saveSuccess
                ? 'bg-emerald-600 shadow-emerald-500/25 ring-2 ring-emerald-300'
                : 'bg-sky-600 hover:bg-sky-700 shadow-sky-500/25'
            }`}
          >
            {saveSuccess ? <CheckCircle2 size={14} /> : <Save size={14} />}
            <span>{isSaving ? 'Saving...' : saveSuccess ? 'Saved to MongoDB!' : 'Save to MongoDB'}</span>
          </button>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-50 hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition cursor-pointer ml-1"
            title="Close Visual Builder"
          >
            <X size={16} />
          </button>
        </div>

      </header>

      {/* =========================================================================
          MAIN WORKSPACE: SPLIT-SCREEN OR FULL CANVAS VIEW
          ========================================================================= */}
      <div className="flex-1 flex overflow-hidden relative">

        {/* =========================================================================
            LEFT COLUMN: COLLAPSIBLE ACCORDION CONTROLS SIDEBAR
            ========================================================================= */}
        <div
          className={`bg-white border-r border-slate-200 flex flex-col shrink-0 transition-all duration-300 ease-in-out relative z-20 shadow-sm ${
            isSidebarCollapsed
              ? 'w-0 overflow-hidden border-r-0 opacity-0 pointer-events-none'
              : 'w-[420px] max-w-full'
          }`}
        >

          {/* =========================================================================
              STOREFRONT UI ARCHETYPES & RANDOMIZER PANEL (HAR BAAR ALAG UI)
              ========================================================================= */}
          <div className="p-3.5 border-b border-slate-200 bg-white space-y-3 shrink-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center text-xs shadow-xs">
                  🎨
                </span>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 leading-tight">UI Design & Appearance</h4>
                  <p className="text-[10px] text-slate-400">Har website ko alag, unique look dein</p>
                </div>
              </div>

              <button
                onClick={() => setShowUiDesignPanel(!showUiDesignPanel)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg transition cursor-pointer"
                title={showUiDesignPanel ? "Collapse UI Panel" : "Expand UI Panel"}
              >
                {showUiDesignPanel ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
              </button>
            </div>

            {/* Randomizer Button (1-Click Shuffler) */}
            <button
              onClick={handleRandomizeUiLook}
              className="w-full py-2.5 px-3 rounded-2xl bg-gradient-to-r from-sky-600 via-indigo-600 to-purple-600 hover:from-sky-700 hover:via-indigo-700 hover:to-purple-700 text-white font-bold text-xs shadow-md hover:shadow-lg transition flex items-center justify-center gap-2 cursor-pointer group active:scale-98"
              title="Click karke instantly fresh header, fresh hero, fresh card style aur font generate karein"
            >
              <Dices size={16} className="group-hover:rotate-180 transition duration-500 text-amber-300" />
              <span>🎲 Shuffle / Randomize Fresh UI Look</span>
            </button>

            {/* Notification Toast */}
            {randomUiToast && (
              <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span className="truncate">{randomUiToast}</span>
              </div>
            )}

            {showUiDesignPanel && (
              <div className="space-y-3 pt-1 border-t border-slate-100 animate-in fade-in duration-200">
                {/* 1-Click UI Presets */}
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                    1-Click UI Archetypes:
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {UI_ARCHETYPES.map((arch) => {
                      const isActive =
                        currentSite.headerStyle === arch.config.headerStyle &&
                        currentSite.cardStyle === arch.config.cardStyle &&
                        currentSite.homepageLayout === arch.config.homepageLayout;
                      return (
                        <button
                          key={arch.id}
                          onClick={() => handleApplyArchetype(arch)}
                          className={`p-2 rounded-xl text-left border transition cursor-pointer flex flex-col justify-between ${
                            isActive
                              ? 'bg-sky-50 border-sky-400 text-sky-900 shadow-2xs ring-1 ring-sky-300'
                              : 'bg-slate-50/70 hover:bg-slate-100 border-slate-200 text-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-1 font-bold text-[11px]">
                            <span>{arch.icon}</span>
                            <span className="truncate">{arch.name}</span>
                          </div>
                          <span className="text-[9px] text-slate-400 line-clamp-1 mt-0.5">{arch.desc}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Granular Style Dropdowns */}
                <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 block mb-1">Header Style:</label>
                    <select
                      value={currentSite.headerStyle || 'Telemetry Bar'}
                      onChange={(e) => setCurrentSite(prev => ({ ...prev, headerStyle: e.target.value }))}
                      className="w-full p-1.5 rounded-lg border border-slate-200 bg-white font-medium text-slate-800 text-[11px] outline-none focus:border-sky-400 cursor-pointer"
                    >
                      {PRESET_HEADER_STYLES.map(h => (
                        <option key={h.value} value={h.value}>{h.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-500 block mb-1">Card Appearance:</label>
                    <select
                      value={currentSite.cardStyle || 'Bordered Minimal'}
                      onChange={(e) => setCurrentSite(prev => ({ ...prev, cardStyle: e.target.value }))}
                      className="w-full p-1.5 rounded-lg border border-slate-200 bg-white font-medium text-slate-800 text-[11px] outline-none focus:border-sky-400 cursor-pointer"
                    >
                      {PRESET_CARD_STYLES.map(c => (
                        <option key={c.value} value={c.value}>{c.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-500 block mb-1">Hero Layout:</label>
                    <select
                      value={currentSite.homepageLayout || 'Banner Carousel'}
                      onChange={(e) => setCurrentSite(prev => ({ ...prev, homepageLayout: e.target.value }))}
                      className="w-full p-1.5 rounded-lg border border-slate-200 bg-white font-medium text-slate-800 text-[11px] outline-none focus:border-sky-400 cursor-pointer"
                    >
                      {PRESET_HERO_STYLES.map(h => (
                        <option key={h.value} value={h.value}>{h.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-500 block mb-1">Typography Font:</label>
                    <select
                      value={currentSite.font || 'Plus Jakarta Sans'}
                      onChange={(e) => setCurrentSite(prev => ({ ...prev, font: e.target.value }))}
                      className="w-full p-1.5 rounded-lg border border-slate-200 bg-white font-medium text-slate-800 text-[11px] outline-none focus:border-sky-400 cursor-pointer"
                    >
                      {PRESET_FONTS.map(f => (
                        <option key={f.value} value={f.value}>{f.label}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Primary Theme Color & Brand Palette */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <Palette size={12} style={{ color: currentSite.primaryColor }} />
                    <span>Theme Accent Color:</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    {THEME_PALETTES.map((pal) => (
                      <button
                        key={pal.color}
                        onClick={() => setCurrentSite(prev => ({ ...prev, primaryColor: pal.color }))}
                        className={`w-4 h-4 rounded-full transition-transform cursor-pointer ${
                          currentSite.primaryColor?.toLowerCase() === pal.color.toLowerCase()
                            ? 'scale-125 ring-2 ring-slate-800 ring-offset-1'
                            : 'hover:scale-110 opacity-80 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: pal.color }}
                        title={pal.name}
                      />
                    ))}
                  </div>
                </div>

              </div>
            )}
          </div>

          {/* Section List Header */}
          <div className="p-3 border-b border-slate-200 bg-white flex items-center justify-between gap-2 shrink-0">
            <div>
              <h3 className="font-bold text-xs text-slate-900">
                Website Page Sections ({blocks.filter(b => b.enabled).length}/{blocks.length} Active)
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">✨ Drag & Drop: Kisi ko bhi utha ke knhi bhi chipkayein ya click karke edit karein</p>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsSidebarCollapsed(true)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
                title="Collapse sidebar to view full page"
              >
                <PanelLeftClose size={15} />
              </button>

              <button
                onClick={() => setAddBlockOpen(!addBlockOpen)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs transition shadow-2xs cursor-pointer"
              >
                <Plus size={13} />
                <span>Add</span>
              </button>
            </div>
          </div>

          {/* Add Section Dropdown Modal */}
          {addBlockOpen && (
            <div className="p-3 bg-sky-50 border-b border-sky-100 animate-in slide-in-from-top-2 duration-150">
              <span className="text-[11px] font-bold text-sky-900 block mb-2">Chuniye kaunsa section add karna hai:</span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {AVAILABLE_BLOCK_TYPES.map(typeDef => {
                  const meta = SECTION_META[typeDef.type] || { title: typeDef.name, icon: LayoutGrid };
                  const IconComp = meta.icon;
                  return (
                    <button
                      key={typeDef.type}
                      onClick={() => handleAddBlock(typeDef.type)}
                      className="p-2 bg-white rounded-xl border border-sky-200 hover:border-sky-400 hover:shadow-xs text-left transition flex items-center gap-2 group cursor-pointer"
                    >
                      <IconComp size={14} className="text-sky-600 shrink-0" />
                      <div className="truncate">
                        <span className="font-semibold text-slate-800 text-[11px] block truncate group-hover:text-sky-600">
                          {typeDef.name}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Draggable & Editable Section Cards */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-slate-50/50">
            {blocks.map((block, index) => {
              const meta = SECTION_META[block.type] || {
                title: block.name || block.type,
                hindi: 'Custom component block',
                icon: LayoutGrid,
                color: 'text-sky-500 bg-sky-50'
              };
              const IconComp = meta.icon;
              const isExpanded = expandedBlockId === block.id;

              return (
                <div
                  key={block.id}
                  id={`section-card-${block.id}`}
                  draggable
                  onDragStart={(e) => handleDragStart(e, index)}
                  onDragOver={(e) => handleDragOver(e, index)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, index)}
                  className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                    dragOverBlockIndex === index
                      ? 'border-sky-500 ring-4 ring-sky-200 scale-[1.02] bg-sky-50/60 shadow-lg'
                      : isExpanded
                      ? 'bg-white border-sky-400 shadow-md ring-2 ring-sky-100'
                      : block.enabled
                      ? 'bg-white border-slate-200/90 shadow-2xs hover:border-slate-300'
                      : 'bg-slate-100/70 border-dashed border-slate-300 opacity-60'
                  } ${draggedBlockIndex === index ? 'opacity-30 border-dashed border-sky-500 scale-95' : ''}`}
                >
                  {/* Card Header Bar */}
                  <div
                    onClick={() => setExpandedBlockId(isExpanded ? null : block.id)}
                    className="p-2.5 flex items-center justify-between gap-2 cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      {/* Drag Grip Handle */}
                      <div
                        className="cursor-grab active:cursor-grabbing p-1 text-slate-300 hover:text-sky-600 transition shrink-0"
                        title="Drag and drop to reorder anywhere (Utha kar knhi bhi set karein)"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <GripVertical size={14} />
                      </div>

                      <span className="text-[10px] font-mono font-bold text-slate-400 w-3.5 text-center shrink-0">
                        {index + 1}
                      </span>
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${meta.color}`}>
                        <IconComp size={14} />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs font-bold truncate ${block.enabled ? 'text-slate-800' : 'line-through text-slate-400'}`}>
                            {meta.title}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 block truncate">
                          {meta.hindi}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons: Move Up, Move Down, Toggle Hide, Delete, Expand */}
                    <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => moveBlock(index, 'up')}
                        disabled={index === 0}
                        className="p-1 rounded text-slate-400 hover:text-slate-700 disabled:opacity-20 hover:bg-slate-100 transition"
                        title="Move Section Up"
                      >
                        <ArrowUp size={13} />
                      </button>
                      <button
                        onClick={() => moveBlock(index, 'down')}
                        disabled={index === blocks.length - 1}
                        className="p-1 rounded text-slate-400 hover:text-slate-700 disabled:opacity-20 hover:bg-slate-100 transition"
                        title="Move Section Down"
                      >
                        <ArrowDown size={13} />
                      </button>
                      <button
                        onClick={() => toggleBlockVisibility(block.id)}
                        className={`p-1 rounded transition ${block.enabled ? 'text-slate-400 hover:text-slate-700' : 'text-amber-500 bg-amber-50'}`}
                        title={block.enabled ? "Hide Section" : "Show Section"}
                      >
                        {block.enabled ? <Eye size={13} /> : <EyeOff size={13} />}
                      </button>
                      <button
                        onClick={() => duplicateBlock(index)}
                        className="p-1 rounded text-slate-400 hover:text-sky-600 hover:bg-sky-50 transition"
                        title="Duplicate / Clone Section (Section Ki Copy Banayein)"
                      >
                        <Copy size={13} />
                      </button>
                      <button
                        onClick={() => deleteBlock(block.id)}
                        className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                        title="Delete Section"
                      >
                        <Trash2 size={13} />
                      </button>
                      <button
                        onClick={() => setExpandedBlockId(isExpanded ? null : block.id)}
                        className="p-1 rounded text-slate-400 hover:text-slate-700"
                      >
                        {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Accordion Body (Direct Inline Customization Form) */}
                  {isExpanded && (
                    <div className="p-3 border-t border-slate-100 bg-slate-50/50 space-y-3 text-xs animate-in slide-in-from-top-1 duration-100">
                      
                      {/* SECTION 1: TOP ANNOUNCEMENT BAR */}
                      {block.type === 'announcement' && (
                        <>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">
                              Notice Text (Alert Sandesh)
                            </label>
                            <input
                              type="text"
                              value={block.data.text || ''}
                              onChange={(e) => updateBlockData(block.id, 'text', e.target.value)}
                              placeholder="CDSCO & ISO 13485:2016 Certified Equipment..."
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400"
                            />
                          </div>

                          {/* CONTINUOUS MOVING TICKER (MARQUEE) TOGGLE & SETTINGS */}
                          <div className="p-2.5 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 space-y-2">
                            <label className="flex items-center gap-2 cursor-pointer select-none">
                              <input
                                type="checkbox"
                                checked={!!block.data.isMarquee}
                                onChange={(e) => updateBlockData(block.id, 'isMarquee', e.target.checked)}
                                className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400 cursor-pointer"
                              />
                              <span className="font-bold text-slate-800 text-[11px] flex items-center gap-1">
                                <span>⚡ Move Karta Rahe (Continuous Running Ticker)</span>
                              </span>
                            </label>
                            <p className="text-[10px] text-amber-800/80 leading-relaxed pl-6">
                              Notice text screen par lagatar chalta rahega (news ticker / stock ticker ki tarah). Mouse le jaane par automatic pause hoga!
                            </p>

                            {block.data.isMarquee && (
                              <div className="grid grid-cols-2 gap-2 pt-1.5 pl-6 border-t border-amber-200/60">
                                <div>
                                  <label className="block text-[10px] font-bold text-slate-700 mb-1">Ticker Speed</label>
                                  <select
                                    value={block.data.marqueeSpeed || 'normal'}
                                    onChange={(e) => updateBlockData(block.id, 'marqueeSpeed', e.target.value)}
                                    className="w-full px-2 py-1.5 bg-white rounded-lg border border-amber-200 text-slate-800 text-[11px] outline-none"
                                  >
                                    <option value="slow">Slow (36s - Aaram Se)</option>
                                    <option value="normal">Normal (22s - Standard)</option>
                                    <option value="fast">Fast (12s - Tez Ticker)</option>
                                  </select>
                                </div>
                                <div>
                                  <label className="block text-[10px] font-bold text-slate-700 mb-1">Direction</label>
                                  <select
                                    value={block.data.marqueeDirection || 'left'}
                                    onChange={(e) => updateBlockData(block.id, 'marqueeDirection', e.target.value)}
                                    className="w-full px-2 py-1.5 bg-white rounded-lg border border-amber-200 text-slate-800 text-[11px] outline-none"
                                  >
                                    <option value="left">Right to Left (Standard)</option>
                                    <option value="right">Left to Right</option>
                                  </select>
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Badge Text</label>
                              <input
                                type="text"
                                value={block.data.badge || ''}
                                onChange={(e) => updateBlockData(block.id, 'badge', e.target.value)}
                                placeholder="URGENT BATCH"
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Background Color</label>
                              <input
                                type="text"
                                value={block.data.bgColor || currentSite.primaryColor}
                                onChange={(e) => updateBlockData(block.id, 'bgColor', e.target.value)}
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 font-mono text-xs"
                              />
                            </div>
                          </div>
                        </>
                      )}

                      {/* SECTION 2: HEADER & LOGO */}
                      {block.type === 'header' && (
                        <>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">
                              Brand Name (Company Ka Naam) *
                            </label>
                            <input
                              type="text"
                              value={currentSite.brandName || ''}
                              onChange={(e) => setCurrentSite(prev => ({ ...prev, brandName: e.target.value }))}
                              placeholder="e.g. Medikabazaar Biomedical"
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                            />
                          </div>

                          {/* Logo Image URL with Thumbnail Preview */}
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">
                              Brand Logo Image URL (Logo Ka Link)
                            </label>
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={block.data.logoUrl || currentSite.logo || ''}
                                onChange={(e) => {
                                  updateBlockData(block.id, 'logoUrl', e.target.value);
                                  setCurrentSite(prev => ({ ...prev, logo: e.target.value }));
                                }}
                                placeholder="https://.../Mb_logo.png or logo.png"
                                className="flex-1 px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-mono text-[11px]"
                              />
                              {(block.data.logoUrl || currentSite.logo) && (
                                <div className="w-10 h-9 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center p-1 shrink-0 overflow-hidden">
                                  <img
                                    src={block.data.logoUrl || currentSite.logo}
                                    alt="Logo preview"
                                    className="max-h-full max-w-full object-contain"
                                    onError={(e) => { e.currentTarget.style.display = 'none'; }}
                                  />
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Delivery Location Pin</label>
                              <input
                                type="text"
                                value={block.data.locationText || ''}
                                onChange={(e) => updateBlockData(block.id, 'locationText', e.target.value)}
                                placeholder="Delivering to: Delhi, 110001"
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Contact Phone</label>
                              <input
                                type="text"
                                value={currentSite.phone || ''}
                                onChange={(e) => setCurrentSite(prev => ({ ...prev, phone: e.target.value }))}
                                placeholder="1800-419-BIOSIS"
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-mono text-xs"
                              />
                            </div>
                          </div>
                        </>
                      )}

                      {/* SECTION 3: HERO SHOWCASE BANNER */}
                      {block.type === 'hero' && (
                        <>
                          {/* HERO LAYOUT MODE SELECTOR */}
                          <div className="p-3 bg-gradient-to-r from-sky-50 to-indigo-50/60 rounded-2xl border border-sky-200 space-y-2.5">
                            <div className="flex items-center justify-between">
                              <label className="text-[11px] font-bold text-sky-950 flex items-center gap-1.5">
                                <Sparkles size={13} className="text-sky-600" />
                                <span>Hero Layout Archetype</span>
                              </label>
                            </div>
                            <select
                              value={block.data.heroLayout || currentSite.homepageLayout || 'carousel'}
                              onChange={(e) => {
                                updateBlockData(block.id, 'heroLayout', e.target.value);
                                setCurrentSite(prev => ({ ...prev, homepageLayout: e.target.value }));
                              }}
                              className="w-full px-2.5 py-1.5 bg-white rounded-xl border border-sky-200 text-slate-800 text-xs font-semibold outline-none focus:border-sky-400"
                            >
                              <option value="carousel">⚡ Banner Carousel (Multi-Slide Image Slider)</option>
                              <option value="centered">Centered Grand Impact (Apple / Nordic MedTech)</option>
                              <option value="split">Split 2-Column B2B Desk</option>
                              <option value="standard">Standard Single Banner Showcase</option>
                            </select>

                            {/* HIDE TEXT TOGGLE (USER REQUEST: KEWAL CROUSAL BANNER CHAIYE TEXT KA KOYI KAAM NAHI) */}
                            <label className="flex items-center gap-2 cursor-pointer select-none pt-1">
                              <input
                                type="checkbox"
                                checked={!!block.data.hideText}
                                onChange={(e) => updateBlockData(block.id, 'hideText', e.target.checked)}
                                className="w-4 h-4 rounded text-sky-500 focus:ring-sky-400 cursor-pointer"
                              />
                              <span className="text-[11px] font-bold text-slate-800">
                                ❌ Hide All Text (Kewal Banners / Pure Images Dikhayein - Text Ka Koyi Kaam Nahi)
                              </span>
                            </label>
                            {block.data.hideText && (
                              <p className="text-[10px] text-sky-800 italic pl-6">
                                ✨ Text bilkul hide ho gaya hai! Screen par kewal high-resolution banner images ka smooth carousel chalega.
                              </p>
                            )}
                          </div>

                          {/* MULTI-SLIDE BANNER CAROUSEL MANAGER */}
                          <div className="space-y-2 pt-1">
                            <div className="flex items-center justify-between">
                              <label className="block text-[11px] font-bold text-slate-700">
                                Banner Slides ({(block.data?.slides || []).length > 0 ? block.data.slides.length : 2} Active Slides):
                              </label>
                              <button
                                type="button"
                                onClick={() => handleAddHeroSlide(block.id)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 text-[11px] font-bold transition cursor-pointer"
                              >
                                <Plus size={12} />
                                <span>+ Add Slide Banner</span>
                              </button>
                            </div>

                            {/* Slides List */}
                            <div className="space-y-2 max-h-56 overflow-y-auto">
                              {((block.data?.slides && block.data.slides.length > 0) ? block.data.slides : [
                                { id: 1, image: block.data?.bannerImage || currentSite.bannerImage || 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1600&auto=format&fit=crop&q=80', title: 'Banner 1' },
                                { id: 2, image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=1600&auto=format&fit=crop&q=80', title: 'Banner 2' }
                              ]).map((slide, sIdx) => (
                                <div key={slide.id || sIdx} className="p-2.5 bg-white rounded-xl border border-slate-200 flex items-center gap-2">
                                  <div className="w-12 h-9 rounded-lg bg-slate-100 border border-slate-200 overflow-hidden shrink-0">
                                    <img src={slide.image} alt="Slide preview" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <input
                                      type="text"
                                      value={slide.image || ''}
                                      onChange={(e) => handleUpdateHeroSlide(block.id, slide.id, 'image', e.target.value)}
                                      placeholder="https://.../banner.jpg"
                                      className="w-full px-2 py-1 bg-slate-50 rounded-lg border border-slate-200 text-[10px] font-mono text-slate-800 outline-none focus:border-sky-400"
                                    />
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteHeroSlide(block.id, slide.id)}
                                    className="p-1 text-slate-400 hover:text-rose-600 rounded transition shrink-0"
                                    title="Delete Slide"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* OPTIONAL HEADLINE & TEXT (IF NOT HIDDEN) */}
                          {!block.data.hideText && (
                            <div className="space-y-2.5 pt-1 border-t border-slate-200/60">
                              <div>
                                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                                  Main Headline (Bada Title)
                                </label>
                                <input
                                  type="text"
                                  value={block.data.title || currentSite.heroTitle || ''}
                                  onChange={(e) => {
                                    updateBlockData(block.id, 'title', e.target.value);
                                    setCurrentSite(prev => ({ ...prev, heroTitle: e.target.value }));
                                  }}
                                  placeholder="e.g. Precision Biomedical & Critical Care Equipment"
                                  className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                                  Subtitle / Description
                                </label>
                                <textarea
                                  rows={2}
                                  value={block.data.subtitle || currentSite.tagline || ''}
                                  onChange={(e) => {
                                    updateBlockData(block.id, 'subtitle', e.target.value);
                                    setCurrentSite(prev => ({ ...prev, tagline: e.target.value }));
                                  }}
                                  placeholder="Engineered for high-acuity ICUs, Modular Operation Theatres..."
                                  className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 leading-relaxed text-xs"
                                />
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Badge Pill Text</label>
                                  <input
                                    type="text"
                                    value={block.data.badgeText || ''}
                                    onChange={(e) => updateBlockData(block.id, 'badgeText', e.target.value)}
                                    placeholder="Direct OEM Procurement"
                                    className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 text-[11px]"
                                  />
                                </div>
                                <div>
                                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Primary Button Text</label>
                                  <input
                                    type="text"
                                    value={block.data.primaryBtnText || 'Explore Clinical Catalog'}
                                    onChange={(e) => updateBlockData(block.id, 'primaryBtnText', e.target.value)}
                                    placeholder="Explore Clinical Catalog"
                                    className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 text-[11px]"
                                  />
                                </div>
                              </div>
                            </div>
                          )}
                        </>
                      )}

                      {/* SECTION 4: TRUST BADGES */}
                      {block.type === 'trustBadges' && (
                        <div className="space-y-2">
                          <span className="text-[11px] text-slate-500 block">4 standard certifications:</span>
                          <div className="grid grid-cols-2 gap-2 text-[11px]">
                            <div className="p-2 bg-white rounded-xl border border-slate-200">
                              <span className="font-bold text-slate-700 block mb-1">Badge 1</span>
                              <input
                                type="text"
                                value={block.data.badge1Title || 'ISO 13485:2016'}
                                onChange={(e) => updateBlockData(block.id, 'badge1Title', e.target.value)}
                                className="w-full px-2 py-1 rounded bg-slate-50 border border-slate-200 font-semibold mb-1"
                              />
                            </div>
                            <div className="p-2 bg-white rounded-xl border border-slate-200">
                              <span className="font-bold text-slate-700 block mb-1">Badge 2</span>
                              <input
                                type="text"
                                value={block.data.badge2Title || 'CDSCO Approved'}
                                onChange={(e) => updateBlockData(block.id, 'badge2Title', e.target.value)}
                                className="w-full px-2 py-1 rounded bg-slate-50 border border-slate-200 font-semibold mb-1"
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      {/* SECTION 5: CLINICAL SPECIALTIES (CATEGORIES) */}
                      {block.type === 'categories' && (
                        <>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Specialty Heading</label>
                            <input
                              type="text"
                              value={block.data.heading || 'Shop by Clinical Category'}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              placeholder="Shop by Clinical Category"
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                            />
                          </div>

                          <div className="pt-2">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[11px] font-bold text-slate-700">
                                Departments ({(block.data.items || currentSite.categories || []).length}):
                              </span>
                              <button
                                onClick={handleAddCategory}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 text-[11px] font-bold transition cursor-pointer"
                              >
                                <Plus size={12} />
                                <span>+ Add Department</span>
                              </button>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto p-1 bg-white rounded-xl border border-slate-200">
                              {(block.data.items || currentSite.categories || []).map((item, i) => (
                                <div key={item.id || i} className="p-2 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-2 group">
                                  <div className="flex items-center gap-2 min-w-0">
                                    {item.image ? (
                                      <img src={item.image} alt={item.name} className="w-7 h-7 object-contain rounded bg-white p-0.5 shrink-0 border border-slate-200" />
                                    ) : (
                                      <div className="w-7 h-7 rounded bg-sky-100 text-sky-700 flex items-center justify-center text-xs font-bold shrink-0">
                                        {item.icon || '🏥'}
                                      </div>
                                    )}
                                    <div className="min-w-0">
                                      <span className="text-[11px] font-bold text-slate-800 block truncate">{item.name}</span>
                                      {item.desc && <span className="text-[9px] text-slate-400 block truncate">{item.desc}</span>}
                                    </div>
                                  </div>
                                  <button
                                    onClick={() => handleDeleteCategory(item.id || item.name)}
                                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition shrink-0 opacity-70 group-hover:opacity-100"
                                    title="Delete Department"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        </>
                      )}

                      {/* SECTION 6: TOP BRANDS */}
                      {block.type === 'topBrands' && (
                        <>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Brands Section Heading</label>
                            <input
                              type="text"
                              value={block.data.heading || 'Top Healthcare Brands'}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Subheading</label>
                            <input
                              type="text"
                              value={block.data.subheading || ''}
                              onChange={(e) => updateBlockData(block.id, 'subheading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400"
                            />
                          </div>
                          <div className="pt-2">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[11px] font-bold text-slate-700">Brand Showcase List:</span>
                              <button
                                onClick={() => handleAddBrand(block.id)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 text-[11px] font-bold transition cursor-pointer"
                              >
                                <Plus size={12} />
                                <span>+ Add Brand</span>
                              </button>
                            </div>
                            <div className="space-y-1.5 max-h-48 overflow-y-auto">
                              {(block.data.brands || [
                                { name: 'Philips Healthcare', discount: '30% OFF', category: 'Monitoring' },
                                { name: 'Omron Healthcare', discount: '35% OFF', category: 'Diagnostics' },
                                { name: 'BPL Medical', discount: '25% OFF', category: 'ECG' }
                              ]).map((brand, bIdx) => (
                                <div key={bIdx} className="p-2 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-2">
                                  <div className="min-w-0">
                                    <span className="font-bold text-xs text-slate-800 block truncate">{brand.name}</span>
                                    <span className="text-[10px] text-emerald-600 font-semibold">{brand.discount}</span>
                                  </div>
                                  <button
                                    onClick={() => handleDeleteBrand(block.id, bIdx)}
                                    className="p-1 text-slate-400 hover:text-rose-600 rounded transition"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        </>
                      )}

                      {/* SECTION 7: LIGHTNING DEALS */}
                      {block.type === 'dealSpotlight' && (
                        <>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Spotlight Card Title</label>
                            <input
                              type="text"
                              value={block.data.title || 'Lightning Deals on Critical Hospital Supplies'}
                              onChange={(e) => updateBlockData(block.id, 'title', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Countdown Timer</label>
                              <input
                                type="text"
                                value={block.data.timerText || 'Ends in 05h 24m 18s'}
                                onChange={(e) => updateBlockData(block.id, 'timerText', e.target.value)}
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 font-mono text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Button Text</label>
                              <input
                                type="text"
                                value={block.data.ctaText || 'Explore All Flash Deals'}
                                onChange={(e) => updateBlockData(block.id, 'ctaText', e.target.value)}
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs"
                              />
                            </div>
                          </div>
                        </>
                      )}

                      {/* SECTION 8: CONSUMABLES, DIAGNOSTICS, ICU, REFURBISHED */}
                      {(block.type === 'trendingConsumables' || block.type === 'diagnosticMachinery' || block.type === 'criticalCare' || block.type === 'refurbishedEquipment') && (
                        <>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Section Heading</label>
                            <input
                              type="text"
                              value={block.data.heading || ''}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Subheading</label>
                            <input
                              type="text"
                              value={block.data.subheading || ''}
                              onChange={(e) => updateBlockData(block.id, 'subheading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400"
                            />
                          </div>
                        </>
                      )}

                      {/* SECTION 9: PRODUCTS CATALOG */}
                      {block.type === 'products' && (
                        <>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Catalog Section Title</label>
                            <input
                              type="text"
                              value={block.data.heading || 'Certified Biomedical Hardware Catalog'}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Catalog Subheading</label>
                            <input
                              type="text"
                              value={block.data.subheading || ''}
                              onChange={(e) => updateBlockData(block.id, 'subheading', e.target.value)}
                              placeholder="Hospital-grade critical care equipment available for immediate batch procurement..."
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 text-xs"
                            />
                          </div>

                          {/* GRANULAR PRODUCT DISPLAY CONTROLS (USER CONFIGURATION) */}
                          <div className="p-3 bg-gradient-to-r from-sky-50 to-indigo-50/60 rounded-2xl border border-sky-200 space-y-3">
                            <span className="text-[11px] font-bold text-sky-950 flex items-center gap-1.5">
                              <Package size={14} className="text-sky-600" />
                              <span>Product Display & Layout Settings:</span>
                            </span>

                            <div className="grid grid-cols-2 gap-2">
                              {/* 1. HOW MANY PRODUCTS TO SHOW */}
                              <div>
                                <label className="block text-[10px] font-bold text-slate-700 mb-1">
                                  Kitne Dikhane Hai (Count)
                                </label>
                                <select
                                  value={block.data.itemsToShow !== undefined ? block.data.itemsToShow : 9}
                                  onChange={(e) => updateBlockData(block.id, 'itemsToShow', Number(e.target.value))}
                                  className="w-full px-2.5 py-1.5 bg-white rounded-xl border border-sky-200 text-slate-800 text-xs font-semibold outline-none focus:border-sky-400"
                                >
                                  <option value={3}>3 Products (1 Row)</option>
                                  <option value={6}>6 Products (2 Rows)</option>
                                  <option value={8}>8 Products (Compact 8)</option>
                                  <option value={9}>9 Products (Standard 3x3)</option>
                                  <option value={12}>12 Products (Full Grid)</option>
                                  <option value={16}>16 Products (High Volume)</option>
                                  <option value={24}>24 Products (Mega Catalog)</option>
                                  <option value={999}>Sabhi Products (Show All)</option>
                                </select>
                              </div>

                              {/* 2. GRID COLUMNS */}
                              <div>
                                <label className="block text-[10px] font-bold text-slate-700 mb-1">
                                  Grid Columns (Row Layout)
                                </label>
                                <select
                                  value={block.data.columns || 3}
                                  onChange={(e) => updateBlockData(block.id, 'columns', Number(e.target.value))}
                                  className="w-full px-2.5 py-1.5 bg-white rounded-xl border border-sky-200 text-slate-800 text-xs font-semibold outline-none focus:border-sky-400"
                                >
                                  <option value={2}>2 Columns (Bade Cards)</option>
                                  <option value={3}>3 Columns (Standard 3 Cards)</option>
                                  <option value={4}>4 Columns (Compact 4 Cards)</option>
                                </select>
                              </div>
                            </div>

                            {/* 3. FILTER BY CATEGORY (KYA DIKHANA HAI) */}
                            <div>
                              <label className="block text-[10px] font-bold text-slate-700 mb-1">
                                Kya Dikhana Hai (Category / Department Filter)
                              </label>
                              <select
                                value={block.data.filterCategory || 'all'}
                                onChange={(e) => updateBlockData(block.id, 'filterCategory', e.target.value)}
                                className="w-full px-2.5 py-1.5 bg-white rounded-xl border border-sky-200 text-slate-800 text-xs font-medium outline-none focus:border-sky-400"
                              >
                                <option value="all">Sabhi Categories (All Devices & Equipment)</option>
                                <option value="icu">ICU & Critical Care (Ventilators, Monitors, Defibrillators)</option>
                                <option value="surgical">Operation Theatre & Surgery (OT Tables, C-Arm, Anesthesia)</option>
                                <option value="radiology">Radiology & Imaging (CT, MRI, 4D Ultrasound, X-Ray)</option>
                                <option value="pathology">Pathology & Diagnostics (Analyzers, Centrifuges)</option>
                                <option value="infrastructure">Hospital Infrastructure (Motorized ICU Beds, Panels)</option>
                                <option value="cardiology">Cardiology & Patient Monitoring (Multipara, ECG)</option>
                                <option value="dialysis">Renal Care & Hemodialysis (Dialysis Units, RO)</option>
                              </select>
                            </div>

                            {/* 4. SHOW CATEGORY SWITCHER TABS */}
                            <label className="flex items-center gap-2 cursor-pointer select-none pt-1">
                              <input
                                type="checkbox"
                                checked={block.data.showCategoryTabs !== false}
                                onChange={(e) => updateBlockData(block.id, 'showCategoryTabs', e.target.checked)}
                                className="w-4 h-4 rounded text-sky-500 focus:ring-sky-400 cursor-pointer"
                              />
                              <span className="text-[11px] font-bold text-slate-700">
                                Show Category Filter Tabs on Storefront (Visitors can switch)
                              </span>
                            </label>
                          </div>

                          <div className="pt-2">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[11px] font-bold text-slate-700">
                                Custom Added Products ({(currentSite.customProducts || []).length}):
                              </span>
                              <button
                                onClick={handleAddProduct}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 text-[11px] font-bold transition cursor-pointer"
                              >
                                <Plus size={12} />
                                <span>+ Add Custom Product</span>
                              </button>
                            </div>
                            {(currentSite.customProducts && currentSite.customProducts.length > 0) ? (
                              <div className="space-y-1.5 max-h-48 overflow-y-auto">
                                {currentSite.customProducts.map((p) => (
                                  <div key={p.id} className="p-2 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-2">
                                    <div className="min-w-0">
                                      <span className="font-bold text-xs text-slate-800 block truncate">{p.name}</span>
                                      <span className="text-[10px] text-slate-400 font-mono">₹{p.price?.toLocaleString('en-IN')} | SKU: {p.sku}</span>
                                    </div>
                                    <button
                                      onClick={() => handleDeleteProduct(p.id)}
                                      className="p-1 text-slate-400 hover:text-rose-600 rounded transition"
                                      title="Delete Product"
                                    >
                                      <Trash2 size={12} />
                                    </button>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-[11px] text-slate-400 italic bg-white p-2.5 rounded-xl border border-slate-100 text-center">
                                Standard biomedical catalog active. Click "+ Add Custom Product" to inject your own hardware.
                              </p>
                            )}
                          </div>
                        </>
                      )}

                      {/* SECTION: CUSTOM RICH TEXT (customContent) */}
                      {block.type === 'customContent' && (
                        <div className="space-y-2.5">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Headline (Bada Title)</label>
                            <input
                              type="text"
                              value={block.data.heading || ''}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              placeholder="Precision Biomedical Engineering..."
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 font-bold outline-none focus:border-sky-400"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Subheading</label>
                            <input
                              type="text"
                              value={block.data.subheading || ''}
                              onChange={(e) => updateBlockData(block.id, 'subheading', e.target.value)}
                              placeholder="Clinical overview or value proposition..."
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Body Text (Paragraph)</label>
                            <textarea
                              rows={3}
                              value={block.data.bodyText || ''}
                              onChange={(e) => updateBlockData(block.id, 'bodyText', e.target.value)}
                              placeholder="Write your custom story, clinical details, warranty information..."
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 leading-relaxed text-xs"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Text Alignment</label>
                              <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 text-xs">
                                {['left', 'center', 'right'].map((al) => (
                                  <button
                                    key={al}
                                    type="button"
                                    onClick={() => updateBlockData(block.id, 'align', al)}
                                    className={`flex-1 py-1 rounded font-bold capitalize transition cursor-pointer ${
                                      (block.data.align || 'left') === al ? 'bg-sky-500 text-white shadow-2xs' : 'text-slate-600 hover:bg-slate-100'
                                    }`}
                                  >
                                    {al}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Card Background</label>
                              <input
                                type="text"
                                value={block.data.bgColor || '#ffffff'}
                                onChange={(e) => updateBlockData(block.id, 'bgColor', e.target.value)}
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 font-mono text-xs"
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">CTA Button Text</label>
                              <input
                                type="text"
                                value={block.data.btnText || ''}
                                onChange={(e) => updateBlockData(block.id, 'btnText', e.target.value)}
                                placeholder="e.g. Inquire Now"
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Button Link</label>
                              <input
                                type="text"
                                value={block.data.btnLink || '#contact'}
                                onChange={(e) => updateBlockData(block.id, 'btnLink', e.target.value)}
                                placeholder="#contact or /shop"
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 font-mono text-xs"
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      {/* SECTION: CUSTOM FEATURE GRID (customGrid) */}
                      {block.type === 'customGrid' && (
                        <div className="space-y-3">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Section Heading</label>
                            <input
                              type="text"
                              value={block.data.heading || 'Key Hospital Advantages'}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 font-semibold"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Subheading</label>
                              <input
                                type="text"
                                value={block.data.subheading || ''}
                                onChange={(e) => updateBlockData(block.id, 'subheading', e.target.value)}
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Grid Columns</label>
                              <select
                                value={block.data.columns || '3'}
                                onChange={(e) => updateBlockData(block.id, 'columns', e.target.value)}
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs font-bold"
                              >
                                <option value="2">2 Columns (Big Cards)</option>
                                <option value="3">3 Columns (Standard)</option>
                                <option value="4">4 Columns (Compact)</option>
                              </select>
                            </div>
                          </div>

                          {/* Grid Cards Editor */}
                          <div className="pt-2">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[11px] font-bold text-slate-700">
                                Feature Cards ({(block.data.items || []).length}):
                              </span>
                              <button
                                onClick={() => handleAddGridItem(block.id)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 text-[11px] font-bold transition cursor-pointer"
                              >
                                <Plus size={12} />
                                <span>+ Add Card</span>
                              </button>
                            </div>
                            <div className="space-y-2 max-h-56 overflow-y-auto">
                              {(block.data.items || []).map((card) => (
                                <div key={card.id} className="p-2.5 bg-white rounded-xl border border-slate-200 space-y-1.5 relative group">
                                  <div className="flex items-center justify-between gap-2">
                                    <input
                                      type="text"
                                      value={card.title || ''}
                                      onChange={(e) => {
                                        const newItems = (block.data.items || []).map(it => it.id === card.id ? { ...it, title: e.target.value } : it);
                                        updateBlockData(block.id, 'items', newItems);
                                      }}
                                      placeholder="Card Title"
                                      className="font-bold text-xs text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200 w-full"
                                    />
                                    <button
                                      onClick={() => handleDeleteGridItem(block.id, card.id)}
                                      className="p-1 text-slate-400 hover:text-rose-600 rounded transition shrink-0"
                                      title="Delete Card"
                                    >
                                      <Trash2 size={13} />
                                    </button>
                                  </div>
                                  <textarea
                                    rows={2}
                                    value={card.desc || ''}
                                    onChange={(e) => {
                                      const newItems = (block.data.items || []).map(it => it.id === card.id ? { ...it, desc: e.target.value } : it);
                                      updateBlockData(block.id, 'items', newItems);
                                    }}
                                    placeholder="Card description text..."
                                    className="text-xs text-slate-600 bg-slate-50 px-2 py-1 rounded border border-slate-200 w-full"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* SECTION: CUSTOM PROMOTIONAL BANNER (customBanner) */}
                      {block.type === 'customBanner' && (
                        <div className="space-y-2.5">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Banner Heading</label>
                            <input
                              type="text"
                              value={block.data.heading || ''}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 font-bold"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Subheading / Description</label>
                            <textarea
                              rows={2}
                              value={block.data.subheading || ''}
                              onChange={(e) => updateBlockData(block.id, 'subheading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Background Image URL</label>
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={block.data.bannerImage || ''}
                                onChange={(e) => updateBlockData(block.id, 'bannerImage', e.target.value)}
                                placeholder="https://.../banner.jpg"
                                className="flex-1 px-3 py-2 bg-white rounded-xl border border-slate-200 font-mono text-[11px]"
                              />
                              {block.data.bannerImage && (
                                <div className="w-12 h-9 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0">
                                  <img src={block.data.bannerImage} alt="thumb" className="w-full h-full object-cover" />
                                </div>
                              )}
                            </div>
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Button Text</label>
                            <input
                              type="text"
                              value={block.data.btnText || 'Request Institutional BOQ'}
                              onChange={(e) => updateBlockData(block.id, 'btnText', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs"
                            />
                          </div>
                        </div>
                      )}

                      {/* SECTION: CUSTOM CODE / HTML / WIDGET (customEmbed) */}
                      {block.type === 'customEmbed' && (
                        <div className="space-y-2.5">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Widget Title / Note</label>
                            <input
                              type="text"
                              value={block.data.title || 'Custom HTML & Developer Widget'}
                              onChange={(e) => updateBlockData(block.id, 'title', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 font-semibold"
                            />
                          </div>

                          {/* Quick Insert Snippet Buttons */}
                          <div>
                            <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                              Quick Template Snippets:
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              <button
                                type="button"
                                onClick={() => updateBlockData(block.id, 'htmlCode', `<div class="p-8 bg-gradient-to-r from-sky-500 to-indigo-600 rounded-3xl text-white text-center shadow-xl">\n  <h3 class="text-2xl font-bold mb-2">Hospital Emergency Delivery Hotline</h3>\n  <p class="text-sm opacity-90 mb-4">Direct dispatch desk available 24/7 across NCR & Tier-1 cities.</p>\n  <button class="px-6 py-2.5 bg-white text-sky-800 font-bold rounded-xl shadow">Call 1800-419-BIOSIS</button>\n</div>`)}
                                className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-[10px] font-semibold text-slate-700 transition"
                              >
                                + Neon Callout Box
                              </button>
                              <button
                                type="button"
                                onClick={() => updateBlockData(block.id, 'htmlCode', `<div class="p-6 bg-slate-900 rounded-3xl text-white border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">\n  <div>\n    <h4 class="text-lg font-bold text-emerald-400">ISO 13485:2016 Factory Accreditation</h4>\n    <p class="text-xs text-slate-300">Cleanroom manufacturing unit certified for life-support ventilators.</p>\n  </div>\n  <span class="px-4 py-2 bg-emerald-500/20 text-emerald-300 rounded-xl font-mono text-xs border border-emerald-500/30">NABH Audit Approved</span>\n</div>`)}
                                className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-[10px] font-semibold text-slate-700 transition"
                              >
                                + Dark Badge Bar
                              </button>
                            </div>
                          </div>

                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">
                              Raw HTML / Tailwind CSS / Widget Code:
                            </label>
                            <textarea
                              rows={6}
                              value={block.data.htmlCode || ''}
                              onChange={(e) => updateBlockData(block.id, 'htmlCode', e.target.value)}
                              placeholder="<div class='p-6 bg-sky-500 text-white rounded-2xl'>Your Custom Code</div>"
                              className="w-full px-3 py-2 bg-slate-900 text-emerald-400 font-mono text-xs rounded-xl border border-slate-700 outline-none focus:border-sky-400 leading-relaxed"
                            />
                            <p className="text-[10px] text-slate-400 mt-1">
                              💡 Aap yahan koi bhi custom HTML, Tailwind classes, iframe ya button paste kar sakte hain. Preview turant update hoga!
                            </p>
                          </div>
                        </div>
                      )}

                      {/* SECTION: HIGH-CONVERTING CTA (customCta) */}
                      {block.type === 'customCta' && (
                        <div className="space-y-2.5">
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Badge Pill</label>
                              <input
                                type="text"
                                value={block.data.badge || 'DIRECT OEM COLLABORATION'}
                                onChange={(e) => updateBlockData(block.id, 'badge', e.target.value)}
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs font-bold"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold text-slate-700 mb-1">Primary Button</label>
                              <input
                                type="text"
                                value={block.data.primaryBtnText || 'Get Official Stamped Quotation'}
                                onChange={(e) => updateBlockData(block.id, 'primaryBtnText', e.target.value)}
                                className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs font-bold"
                              />
                            </div>
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">CTA Headline</label>
                            <input
                              type="text"
                              value={block.data.heading || 'Ready to Upgrade Your Hospital Equipment?'}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 font-bold"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Subheading / Offer text</label>
                            <textarea
                              rows={2}
                              value={block.data.subheading || ''}
                              onChange={(e) => updateBlockData(block.id, 'subheading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Secondary Button Text (Optional)</label>
                            <input
                              type="text"
                              value={block.data.secondaryBtnText || 'Download Product Spec Sheet'}
                              onChange={(e) => updateBlockData(block.id, 'secondaryBtnText', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-xs"
                            />
                          </div>
                        </div>
                      )}

                      {/* SECTION 10: TESTIMONIALS */}
                      {block.type === 'testimonials' && (
                        <div className="space-y-3">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Testimonials Heading</label>
                            <input
                              type="text"
                              value={block.data.heading || 'What Our Customers Say About Us'}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                            />
                          </div>
                          <div className="pt-1">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[11px] font-bold text-slate-700">Testimonials List:</span>
                              <button
                                onClick={() => handleAddTestimonial(block.id)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 text-[11px] font-bold transition cursor-pointer"
                              >
                                <Plus size={12} />
                                <span>+ Add Review</span>
                              </button>
                            </div>
                            <div className="space-y-2 max-h-48 overflow-y-auto">
                              {(block.data.items || [
                                { id: 't-1', doctor: 'Dr. Rajesh Sharma', role: 'Head of Critical Care', hospital: 'Apollo Hospitals', quote: 'Standardized our ICU with their monitors. Zero breakdown in 18 months.', rating: 5 }
                              ]).map((t) => (
                                <div key={t.id} className="p-2.5 bg-white rounded-xl border border-slate-200 space-y-1">
                                  <div className="flex items-center justify-between">
                                    <span className="font-bold text-xs text-slate-800">{t.doctor}</span>
                                    <button
                                      onClick={() => handleDeleteTestimonial(block.id, t.id)}
                                      className="p-1 text-slate-400 hover:text-rose-600 rounded transition"
                                    >
                                      <Trash2 size={12} />
                                    </button>
                                  </div>
                                  <p className="text-[11px] text-slate-600 italic">"{t.quote}"</p>
                                  <span className="text-[10px] text-sky-600 font-semibold block">{t.hospital}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* SECTION 11: FAQS */}
                      {block.type === 'faqs' && (
                        <div className="space-y-3">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">FAQ Heading</label>
                            <input
                              type="text"
                              value={block.data.heading || 'Frequently Asked Questions'}
                              onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                            />
                          </div>
                          <div className="pt-1">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[11px] font-bold text-slate-700">FAQ Accordions:</span>
                              <button
                                onClick={() => handleAddFaq(block.id)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 text-[11px] font-bold transition cursor-pointer"
                              >
                                <Plus size={12} />
                                <span>+ Add FAQ</span>
                              </button>
                            </div>
                            <div className="space-y-2 max-h-48 overflow-y-auto">
                              {(block.data.items || [
                                { q: 'What is the standard delivery timeline for hospital batches?', a: 'High-frequency consumables dispatch in 24 hours. Capital machinery commissions within 3 to 7 business days.' }
                              ]).map((faq, fIdx) => (
                                <div key={fIdx} className="p-2.5 bg-white rounded-xl border border-slate-200 space-y-1">
                                  <div className="flex items-center justify-between gap-2">
                                    <span className="font-bold text-xs text-slate-800 line-clamp-1">{faq.q}</span>
                                    <button
                                      onClick={() => handleDeleteFaq(block.id, fIdx)}
                                      className="p-1 text-slate-400 hover:text-rose-600 rounded transition shrink-0"
                                    >
                                      <Trash2 size={12} />
                                    </button>
                                  </div>
                                  <p className="text-[11px] text-slate-600 line-clamp-2">{faq.a}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* SECTION 12: RFQ BANNER */}
                      {block.type === 'rfqBanner' && (
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 mb-1">Inquiry Callout Heading</label>
                          <input
                            type="text"
                            value={block.data.heading || 'Planning Hospital Wing Expansion or New ICU Ward?'}
                            onChange={(e) => updateBlockData(block.id, 'heading', e.target.value)}
                            className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400 font-semibold"
                          />
                        </div>
                      )}

                      {/* SECTION 13: HELPDESK & HUBS */}
                      {block.type === 'contactDesk' && (
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Official Support Email</label>
                            <input
                              type="email"
                              value={currentSite.email || ''}
                              onChange={(e) => setCurrentSite(prev => ({ ...prev, email: e.target.value }))}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 font-mono text-[11px]"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 mb-1">Warehouse City</label>
                            <input
                              type="text"
                              value={currentSite.city || ''}
                              onChange={(e) => setCurrentSite(prev => ({ ...prev, city: e.target.value }))}
                              className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-[11px]"
                            />
                          </div>
                        </div>
                      )}

                      {/* SECTION 14: FOOTER */}
                      {block.type === 'footer' && (
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 mb-1">Copyright & Legal Text</label>
                          <input
                            type="text"
                            value={block.data.copyrightText || ''}
                            onChange={(e) => updateBlockData(block.id, 'copyrightText', e.target.value)}
                            placeholder="All Rights Reserved. CDSCO Medical Device Rules..."
                            className="w-full px-3 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-sky-400"
                          />
                        </div>
                      )}

                      {/* ========================================================= */}
                      {/* UNIVERSAL COMPONENT STYLING & MOTION (FOR EVERY SECTION) */}
                      {/* ========================================================= */}
                      <div className="mt-4 pt-3 border-t border-slate-200 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-bold text-slate-800 flex items-center gap-1.5">
                            <Palette size={13} className="text-sky-500" />
                            <span>🎨 Section Colors, Button & Motion Settings</span>
                          </span>
                          <span className="text-[10px] text-slate-400">Har component ko customize karein</span>
                        </div>

                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">Button Color</label>
                            <div className="flex items-center gap-1.5">
                              <input
                                type="color"
                                value={block.data.btnColor || currentSite.primaryColor || '#0ea5e9'}
                                onChange={(e) => updateBlockData(block.id, 'btnColor', e.target.value)}
                                className="w-7 h-7 rounded-lg border border-slate-200 cursor-pointer p-0.5 shrink-0"
                              />
                              <input
                                type="text"
                                value={block.data.btnColor || ''}
                                onChange={(e) => updateBlockData(block.id, 'btnColor', e.target.value)}
                                placeholder={currentSite.primaryColor}
                                className="w-full px-2 py-1 bg-white rounded-lg border border-slate-200 text-[10px] font-mono text-slate-800"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">Background</label>
                            <div className="flex items-center gap-1.5">
                              <input
                                type="color"
                                value={block.data.bgColor || '#ffffff'}
                                onChange={(e) => updateBlockData(block.id, 'bgColor', e.target.value)}
                                className="w-7 h-7 rounded-lg border border-slate-200 cursor-pointer p-0.5 shrink-0"
                              />
                              <input
                                type="text"
                                value={block.data.bgColor || ''}
                                onChange={(e) => updateBlockData(block.id, 'bgColor', e.target.value)}
                                placeholder="Default"
                                className="w-full px-2 py-1 bg-white rounded-lg border border-slate-200 text-[10px] font-mono text-slate-800"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-600 mb-1">Text Color</label>
                            <div className="flex items-center gap-1.5">
                              <input
                                type="color"
                                value={block.data.textColor || '#0f172a'}
                                onChange={(e) => updateBlockData(block.id, 'textColor', e.target.value)}
                                className="w-7 h-7 rounded-lg border border-slate-200 cursor-pointer p-0.5 shrink-0"
                              />
                              <input
                                type="text"
                                value={block.data.textColor || ''}
                                onChange={(e) => updateBlockData(block.id, 'textColor', e.target.value)}
                                placeholder="Default"
                                className="w-full px-2 py-1 bg-white rounded-lg border border-slate-200 text-[10px] font-mono text-slate-800"
                              />
                            </div>
                          </div>
                        </div>

                        {/* MOTION / TICKER & STOP CONTROLS */}
                        <div className="p-2.5 rounded-xl bg-slate-100/80 border border-slate-200/90 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-slate-700 flex items-center gap-1">
                              <Zap size={12} className="text-amber-500" />
                              <span>Motion / Ticker Effect:</span>
                            </span>
                            {/* STOP / PLAY TOGGLE BUTTON */}
                            <button
                              type="button"
                              onClick={() => {
                                const nextActive = block.data.isMotionActive === false ? true : false;
                                updateBlockData(block.id, 'isMotionActive', nextActive);
                              }}
                              className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1 cursor-pointer ${
                                block.data.isMotionActive !== false && block.data.motionType && block.data.motionType !== 'none'
                                  ? 'bg-rose-100 text-rose-700 hover:bg-rose-200 border border-rose-300'
                                  : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border border-emerald-300'
                              }`}
                            >
                              {block.data.isMotionActive !== false && block.data.motionType && block.data.motionType !== 'none' ? (
                                <><span>⏸ Stop Motion (Sthir Karein)</span></>
                              ) : (
                                <><span>▶ Start Motion</span></>
                              )}
                            </button>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[10px] text-slate-500 mb-0.5">Motion Type</label>
                              <select
                                value={block.data.motionType || 'none'}
                                onChange={(e) => {
                                  updateBlockData(block.id, 'motionType', e.target.value);
                                  if (e.target.value !== 'none') {
                                    updateBlockData(block.id, 'isMotionActive', true);
                                  }
                                }}
                                className="w-full px-2 py-1.5 bg-white rounded-lg border border-slate-200 text-slate-800 text-[11px] outline-none"
                              >
                                <option value="none">Sthir (No Motion / Static)</option>
                                <option value="marquee">Move Karta Rahe (Continuous Running Ticker)</option>
                                <option value="pulse">Subtle Breathing Pulse</option>
                                <option value="glow">Neon Glow Border</option>
                              </select>
                            </div>

                            {block.data.motionType === 'marquee' && (
                              <div>
                                <label className="block text-[10px] text-slate-500 mb-0.5">Speed</label>
                                <select
                                  value={block.data.motionSpeed || 'normal'}
                                  onChange={(e) => updateBlockData(block.id, 'motionSpeed', e.target.value)}
                                  className="w-full px-2 py-1.5 bg-white rounded-lg border border-slate-200 text-slate-800 text-[11px] outline-none"
                                >
                                  <option value="slow">Slow (36s)</option>
                                  <option value="normal">Normal (22s)</option>
                                  <option value="fast">Fast (12s)</option>
                                </select>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                    </div>
                  )}

                </div>
              );
            })}
          </div>

          {/* Bottom Bar: Status & Save Button */}
          <div className="p-3 border-t border-slate-200 bg-white flex items-center justify-between gap-3 shrink-0">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <CheckCircle2 size={13} className="text-emerald-500" />
              <span>Right canvas updates automatically.</span>
            </div>

            <button
              onClick={handleSaveToMongo}
              disabled={isSaving}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white transition shadow-sm cursor-pointer ${
                saveSuccess
                  ? 'bg-emerald-600 shadow-emerald-500/25'
                  : 'bg-sky-500 hover:bg-sky-600 shadow-sky-500/25'
              }`}
            >
              <Save size={13} />
              <span>{isSaving ? 'Saving...' : saveSuccess ? 'Saved to Atlas!' : 'Save Layout'}</span>
            </button>
          </div>

        </div>

        {/* =========================================================================
            RIGHT COLUMN: REAL-TIME LIVE STOREFRONT PREVIEW (DYNAMIC DEVICE CANVAS)
            ========================================================================= */}
        <div className="flex-1 bg-slate-200/80 p-3 sm:p-5 flex flex-col items-center justify-center overflow-hidden relative">
          
          {/* Floating Expand Sidebar Button when sidebar is collapsed */}
          {isSidebarCollapsed && (
            <button
              onClick={() => setIsSidebarCollapsed(false)}
              className="absolute left-4 top-4 z-30 flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-white/95 backdrop-blur-md text-slate-800 shadow-xl border border-slate-300 hover:bg-sky-50 hover:text-sky-700 hover:border-sky-300 font-bold text-xs cursor-pointer transition animate-in fade-in"
              title="Open Builder Controls Sidebar"
            >
              <PanelLeftOpen size={15} className="text-sky-600" />
              <span>Show Controls / Sections</span>
            </button>
          )}

          {/* Floating Canvas Meta Pill */}
          <div className="absolute top-4 z-20 bg-white/95 backdrop-blur-md border border-slate-300/80 px-3 py-1.5 rounded-full shadow-md text-xs text-slate-700 flex items-center gap-3">
            <span className="flex items-center gap-1.5 font-semibold text-slate-800">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Live Storefront Preview: <span className="font-mono text-sky-700">{site.domain}</span>
            </span>
            <span className="text-slate-300">|</span>
            <span className="text-[11px] text-slate-500 font-medium">
              Page: <strong className="text-sky-700 uppercase">{activePage}</strong>
            </span>
            <span className="text-slate-300">|</span>
            <span className="text-[11px] text-slate-500 font-medium">
              Viewport: <strong className="text-slate-800">{deviceViewport.toUpperCase()}</strong>
            </span>
            <span className="text-slate-300">|</span>
            <button
              onClick={() => setPreviewReloadKey(Date.now())}
              className="text-sky-600 hover:text-sky-700 font-semibold flex items-center gap-1 text-[11px] cursor-pointer"
            >
              <RefreshCw size={11} />
              <span>Reload</span>
            </button>
          </div>

          {/* Dynamic Resizing Device Frame */}
          <div
            className={`h-full transition-all duration-300 rounded-2xl overflow-hidden shadow-xl flex flex-col bg-white pt-8 ${
              deviceViewport === 'mobile'
                ? 'w-[390px] border-8 border-slate-400/80 shadow-2xl rounded-3xl'
                : deviceViewport === 'tablet'
                ? 'w-[768px] border-8 border-slate-300/80 shadow-xl rounded-3xl'
                : 'w-full border border-slate-300'
            }`}
          >
            <iframe
              ref={iframeRef}
              key={previewReloadKey}
              src={`/preview/${site.domain}?sandbox=true&admin=true&page=${activePage}&t=${previewReloadKey}`}
              className="w-full h-full border-0 bg-white"
              title={`Live Storefront for ${site.domain}`}
            />
          </div>

        </div>

      </div>

      {/* =========================================================================
          DEVELOPER CUSTOM CSS MODAL
          ========================================================================= */}
      {showCssEditor && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 text-slate-100 rounded-3xl w-full max-w-2xl border border-slate-700 shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Code size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Developer Custom CSS Styling</h3>
                  <p className="text-[11px] text-slate-400">Website par koi bhi custom CSS rules inject karein (jaise code se karte hain)</p>
                </div>
              </div>
              <button
                onClick={() => setShowCssEditor(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Snippet Buttons */}
            <div className="px-4 py-2.5 bg-slate-950/60 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0">Quick Snippets:</span>
              <button
                onClick={() => setCurrentSite(prev => ({ ...prev, customCss: (prev.customCss || '') + '\n/* Glassmorphic Header */\nheader, .site-header { backdrop-filter: blur(16px) !important; background: rgba(255, 255, 255, 0.85) !important; }\n' }))}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold transition shrink-0 cursor-pointer"
              >
                + Glassmorphism Header
              </button>
              <button
                onClick={() => setCurrentSite(prev => ({ ...prev, customCss: (prev.customCss || '') + '\n/* Glowing Button Hover */\nbutton.shadow-md:hover { box-shadow: 0 0 25px rgba(14, 165, 233, 0.6) !important; transform: translateY(-2px); }\n' }))}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold transition shrink-0 cursor-pointer"
              >
                + Glowing Buttons
              </button>
              <button
                onClick={() => setCurrentSite(prev => ({ ...prev, customCss: (prev.customCss || '') + '\n/* Ultra Smooth Cards */\n.rounded-3xl, .rounded-2xl { border-radius: 28px !important; transition: all 0.3s ease !important; }\n' }))}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold transition shrink-0 cursor-pointer"
              >
                + Ultra Smooth Cards
              </button>
              <button
                onClick={() => setCurrentSite(prev => ({ ...prev, customCss: '' }))}
                className="px-2 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300 text-[10px] font-semibold transition shrink-0 ml-auto cursor-pointer"
              >
                Clear CSS
              </button>
            </div>

            {/* Code Textarea */}
            <div className="p-4 flex-1 min-h-[260px]">
              <textarea
                rows={12}
                value={currentSite.customCss || ''}
                onChange={(e) => setCurrentSite(prev => ({ ...prev, customCss: e.target.value }))}
                placeholder="/* Custom CSS Rules (Example): */&#10;.site-hero-headline { font-weight: 900; letter-spacing: -0.05em; }&#10;.custom-card { border: 2px solid #0ea5e9; }"
                className="w-full h-full p-3 bg-slate-950 text-amber-300 font-mono text-xs rounded-xl border border-slate-700 outline-none focus:border-amber-400 leading-relaxed resize-none"
              />
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/40 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                ⚡ Changes preview iframe par instantly live render honge.
              </span>
              <button
                onClick={() => setShowCssEditor(false)}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition cursor-pointer"
              >
                Apply & Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          ADD NEW CUSTOM PAGE MODAL
          ========================================================================= */}
      {showAddPageModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-3xl w-full max-w-md border border-slate-200 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
                  <Plus size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Create New Custom Page</h3>
                  <p className="text-[11px] text-slate-400">Add a new dedicated page to this website</p>
                </div>
              </div>
              <button
                onClick={() => setShowAddPageModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreatePage} className="space-y-3 pt-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Page Name (e.g. Services, Gallery, Tenders)</label>
                <input
                  type="text"
                  required
                  value={newPageName}
                  onChange={(e) => setNewPageName(e.target.value)}
                  placeholder="e.g. Hospital Turnkey Projects"
                  className="w-full px-3 py-2 bg-slate-50 rounded-xl border border-slate-200 text-xs font-semibold outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Page URL Slug (Optional)</label>
                <div className="flex items-center">
                  <span className="px-3 py-2 bg-slate-100 rounded-l-xl border border-r-0 border-slate-200 text-slate-500 font-mono text-xs">/</span>
                  <input
                    type="text"
                    value={newPageSlug}
                    onChange={(e) => setNewPageSlug(e.target.value)}
                    placeholder="turnkey-projects"
                    className="flex-1 px-3 py-2 bg-slate-50 rounded-r-xl border border-slate-200 text-xs font-mono outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddPageModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 text-xs font-semibold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs transition shadow-sm cursor-pointer"
                >
                  Create Page & Switch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* External Theme & Website Importer Modal */}
      {isImporterOpen && (
        <SiteThemeImporterModal
          isOpen={isImporterOpen}
          onClose={() => setIsImporterOpen(false)}
          targetSite={currentSite}
          existingSites={existingSites}
          onApplyExtractedTheme={handleApplyExtractedTheme}
        />
      )}

    </div>
  );
}
