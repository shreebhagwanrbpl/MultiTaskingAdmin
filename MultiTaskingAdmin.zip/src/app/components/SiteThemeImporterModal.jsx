'use client';

import React, { useState } from 'react';
import {
  X,
  Globe,
  Code,
  Copy,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  RefreshCw,
  AlertCircle,
  FileText,
  Phone,
  Mail,
  Palette,
  ExternalLink,
  Laptop
} from 'lucide-react';

export default function SiteThemeImporterModal({
  isOpen,
  onClose,
  targetSite,
  existingSites = [],
  onApplyExtractedTheme
}) {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState('url'); // 'url' | 'html' | 'clone'
  const [urlInput, setUrlInput] = useState('');
  const [htmlInput, setHtmlInput] = useState('');
  const [selectedCloneDomain, setSelectedCloneDomain] = useState(
    existingSites.length > 0 ? existingSites[0].domain : ''
  );

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [extractedResult, setExtractedResult] = useState(null);

  // Handle URL Scan
  const handleScanUrl = async (e) => {
    e?.preventDefault();
    if (!urlInput.trim()) {
      setErrorMsg('Please enter a website URL to scan.');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    setExtractedResult(null);

    try {
      const res = await fetch('/api/sites/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'url_scrape',
          url: urlInput.trim(),
          targetSite
        })
      });

      const data = await res.json();
      if (data.success) {
        setExtractedResult(data);
      } else {
        setErrorMsg(data.error || 'Failed to scan website. Check if URL is accessible or paste HTML directly.');
      }
    } catch (err) {
      setErrorMsg(`Network scan error: ${err.message}. Try pasting HTML code directly.`);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle HTML Parse
  const handleParseHtml = async (e) => {
    e?.preventDefault();
    if (!htmlInput.trim()) {
      setErrorMsg('Please paste HTML code or template content.');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    setExtractedResult(null);

    try {
      const res = await fetch('/api/sites/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'parse_html',
          rawHtml: htmlInput,
          targetSite
        })
      });

      const data = await res.json();
      if (data.success) {
        setExtractedResult(data);
      } else {
        setErrorMsg(data.error || 'Failed to parse HTML.');
      }
    } catch (err) {
      setErrorMsg(`Parsing error: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Clone from Network Site
  const handleCloneSite = () => {
    const sourceSite = existingSites.find(s => s.domain === selectedCloneDomain);
    if (!sourceSite) {
      setErrorMsg('Please select a source website to clone from.');
      return;
    }

    setExtractedResult({
      success: true,
      source: 'clone',
      extractedData: {
        domain: targetSite?.domain || sourceSite.domain,
        brandName: sourceSite.brandName,
        tagline: sourceSite.tagline,
        heroTitle: sourceSite.heroTitle || sourceSite.tagline,
        primaryColor: sourceSite.primaryColor,
        phone: sourceSite.phone,
        email: sourceSite.email,
        categoryFocus: sourceSite.categoryFocus,
        headerStyle: sourceSite.headerStyle,
        homepageLayout: sourceSite.homepageLayout,
        cardStyle: sourceSite.cardStyle
      },
      layoutBlocks: sourceSite.layoutBlocks || []
    });
  };

  // Apply to Current Website
  const handleApply = () => {
    if (!extractedResult) return;
    onApplyExtractedTheme(extractedResult, extractedResult.layoutBlocks);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/30 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Sparkles size={19} />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800">
                Import & Adapt Website Theme
              </h3>
              <p className="text-xs text-slate-400">
                Koyi bhi live website ya local HTML code scan karke styling & sections extract karein.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-50 rounded-xl transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center p-1 bg-slate-100 rounded-2xl mt-4 shrink-0 text-xs font-semibold">
          <button
            onClick={() => { setActiveTab('url'); setErrorMsg(null); }}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'url' ? 'bg-white text-indigo-600 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Globe size={13} />
            <span>🌐 Scan Live Website URL</span>
          </button>
          <button
            onClick={() => { setActiveTab('html'); setErrorMsg(null); }}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'html' ? 'bg-white text-indigo-600 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Code size={13} />
            <span>💻 Paste Local HTML / Template</span>
          </button>
          <button
            onClick={() => { setActiveTab('clone'); setErrorMsg(null); }}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'clone' ? 'bg-white text-indigo-600 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Copy size={13} />
            <span>⚡ Clone From Network Site</span>
          </button>
        </div>

        {/* Content Body (Scrollable) */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 text-xs">
          
          {/* TAB 1: LIVE URL SCANNER */}
          {activeTab === 'url' && (
            <div className="space-y-3">
              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Enter Live Website URL (Live Website ka address dalein):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="e.g. https://rajbiosis.com or medtech-equipment.in"
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-indigo-500 font-mono text-xs"
                  />
                  <button
                    type="button"
                    disabled={isLoading}
                    onClick={handleScanUrl}
                    className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0 shadow-sm"
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw size={13} className="animate-spin" />
                        <span>Scanning...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles size={13} />
                        <span>Scan & Extract</span>
                      </>
                    )}
                  </button>
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  💡 Scanner website ka title, main headline, primary color, phone, email aur layout structure extract karega.
                </span>
              </div>
            </div>
          )}

          {/* TAB 2: LOCAL HTML PASTE */}
          {activeTab === 'html' && (
            <div className="space-y-3">
              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Paste Local Website HTML Code (Local file ya template ka HTML code paste karein):
                </label>
                <textarea
                  rows={6}
                  value={htmlInput}
                  onChange={(e) => setHtmlInput(e.target.value)}
                  placeholder="<!DOCTYPE html><html><head><title>My Medical Devices</title>... Paste full HTML or snippet here"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-indigo-500 font-mono text-[11px] leading-relaxed"
                />
              </div>
              <button
                type="button"
                disabled={isLoading}
                onClick={handleParseHtml}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                {isLoading ? <RefreshCw size={13} className="animate-spin" /> : <Sparkles size={13} />}
                <span>Parse Local HTML Template</span>
              </button>
            </div>
          )}

          {/* TAB 3: CLONE FROM NETWORK SITE */}
          {activeTab === 'clone' && (
            <div className="space-y-3">
              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Choose a Site to Clone Structure & Colors From:
                </label>
                <select
                  value={selectedCloneDomain}
                  onChange={(e) => setSelectedCloneDomain(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-800 outline-none focus:border-indigo-500 font-medium"
                >
                  {existingSites.map(s => (
                    <option key={s.domain} value={s.domain}>
                      {s.brandName} ({s.domain}) — {s.categoryFocus}
                    </option>
                  ))}
                </select>
              </div>
              <button
                type="button"
                onClick={handleCloneSite}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Copy size={13} />
                <span>Clone Site Layout & Styling</span>
              </button>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle size={15} className="text-rose-500 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Extracted Theme Preview Card */}
          {extractedResult && extractedResult.extractedData && (
            <div className="p-4 bg-slate-50 border border-indigo-200/90 rounded-2xl space-y-3 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                  <CheckCircle2 size={15} className="text-emerald-500" />
                  <span>Successfully Extracted Website Identity!</span>
                </span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-bold border border-indigo-100">
                  Ready to Apply
                </span>
              </div>

              {/* Data Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block">Brand Name</span>
                  <span className="font-bold text-slate-800">{extractedResult.extractedData.brandName}</span>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] block">Theme Color</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span
                      className="w-4 h-4 rounded-full border border-slate-300 shrink-0"
                      style={{ backgroundColor: extractedResult.extractedData.primaryColor }}
                    />
                    <span className="font-mono text-slate-700 font-semibold">{extractedResult.extractedData.primaryColor}</span>
                  </div>
                </div>

                <div className="col-span-2">
                  <span className="text-slate-400 text-[10px] block">Extracted Headline</span>
                  <span className="text-slate-700 font-medium">{extractedResult.extractedData.heroTitle}</span>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] block">Contact Phone</span>
                  <span className="font-mono text-slate-700">{extractedResult.extractedData.phone}</span>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] block">Contact Email</span>
                  <span className="font-mono text-slate-700">{extractedResult.extractedData.email}</span>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] block">Specialty Focus</span>
                  <span className="text-slate-700">{extractedResult.extractedData.categoryFocus}</span>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] block">Generated Blocks</span>
                  <span className="font-bold text-sky-700">{extractedResult.layoutBlocks?.length || 10} Sections Configured</span>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-semibold transition cursor-pointer"
          >
            Cancel
          </button>

          <button
            disabled={!extractedResult}
            onClick={handleApply}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm shadow-indigo-500/20"
          >
            <Sparkles size={14} />
            <span>Apply This Theme to Website</span>
          </button>
        </div>

      </div>
    </div>
  );
}
