'use client';

import React, { useState } from 'react';
import {
  X,
  Check,
  Sparkles,
  Phone,
  Mail,
  MapPin,
  MessageSquare,
  AlertCircle,
  Palette,
  CheckCircle2,
  RefreshCw,
  Zap,
  Globe,
  Building2
} from 'lucide-react';

export default function BulkUpdateModal({ isOpen, onClose, sites, onSuccess }) {
  if (!isOpen) return null;

  // Scope selection: 'all' | 'rajbiosis' | 'human_bio' | 'global_bio' | 'custom'
  const [scope, setScope] = useState('all');
  const [selectedDomains, setSelectedDomains] = useState(() => sites.map(s => s.domain));

  // Field toggles (only checked fields will be overwritten)
  const [enablePhone, setEnablePhone] = useState(false);
  const [phoneVal, setPhoneVal] = useState('1800-419-BIOSIS');

  const [enableEmail, setEnableEmail] = useState(false);
  const [emailVal, setEmailVal] = useState('institutional@biomedical.com');

  const [enableCity, setEnableCity] = useState(false);
  const [cityVal, setCityVal] = useState('Central Warehouse Hub, Bengaluru');

  const [enableWhatsapp, setEnableWhatsapp] = useState(false);
  const [whatsappVal, setWhatsappVal] = useState('+91 98210 55443');

  const [enableAnnouncement, setEnableAnnouncement] = useState(false);
  const [announcementVal, setAnnouncementVal] = useState('🚨 CDSCO & ISO 13485:2016 Certified Equipment Batch Ready for Priority Hospital Dispatch');

  const [enableColor, setEnableColor] = useState(false);
  const [colorVal, setColorVal] = useState('#0ea5e9');

  const [isUpdating, setIsUpdating] = useState(false);
  const [resultMsg, setResultMsg] = useState(null);

  // Compute targeted sites
  const targetSites = sites.filter(s => {
    if (scope === 'all') return true;
    if (scope === 'rajbiosis') return (s.companyId || 'rajbiosis') === 'rajbiosis';
    if (scope === 'human_bio') return s.companyId === 'human_bio';
    if (scope === 'global_bio') return s.companyId === 'global_bio';
    if (scope === 'custom') return selectedDomains.includes(s.domain);
    return true;
  });

  const handleScopeChange = (newScope) => {
    setScope(newScope);
    if (newScope === 'all') {
      setSelectedDomains(sites.map(s => s.domain));
    } else if (newScope === 'rajbiosis') {
      setSelectedDomains(sites.filter(s => (s.companyId || 'rajbiosis') === 'rajbiosis').map(s => s.domain));
    } else if (newScope === 'human_bio') {
      setSelectedDomains(sites.filter(s => s.companyId === 'human_bio').map(s => s.domain));
    } else if (newScope === 'global_bio') {
      setSelectedDomains(sites.filter(s => s.companyId === 'global_bio').map(s => s.domain));
    }
  };

  const toggleDomain = (domain) => {
    setScope('custom');
    setSelectedDomains(prev =>
      prev.includes(domain) ? prev.filter(d => d !== domain) : [...prev, domain]
    );
  };

  const handleApplyBulkUpdate = async (e) => {
    e.preventDefault();

    const updates = {};
    if (enablePhone && phoneVal.trim()) updates.phone = phoneVal.trim();
    if (enableEmail && emailVal.trim()) updates.email = emailVal.trim();
    if (enableCity && cityVal.trim()) updates.city = cityVal.trim();
    if (enableWhatsapp && whatsappVal.trim()) updates.whatsapp = whatsappVal.trim();
    if (enableAnnouncement && announcementVal.trim()) updates.announcement = announcementVal.trim();
    if (enableColor && colorVal.trim()) updates.primaryColor = colorVal.trim();

    if (Object.keys(updates).length === 0) {
      alert("Please check at least one field to bulk update!");
      return;
    }

    if (targetSites.length === 0) {
      alert("No websites selected in target scope!");
      return;
    }

    setIsUpdating(true);
    setResultMsg(null);

    try {
      const payload = {
        domains: targetSites.map(s => s.domain),
        updates
      };

      const res = await fetch('/api/sites/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (data.success) {
        setResultMsg(`Success! Mass update applied to ${data.modifiedCount} websites in MongoDB Atlas.`);
        setTimeout(() => {
          if (onSuccess) onSuccess();
          onClose();
        }, 1500);
      } else {
        alert(`Bulk update failed: ${data.error}`);
      }
    } catch (err) {
      alert(`Network error: ${err.message}`);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/30 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 flex flex-col max-h-[90vh] overflow-hidden">

        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md shadow-amber-500/20">
              <Zap size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-800 text-base">Network-Wide Mass Sync & Bulk Update</h3>
                <span className="text-xs px-2.5 py-0.5 rounded-full font-mono font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                  Bulk Operations
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Update common phone numbers, emails, addresses, WhatsApp, or notices across multiple websites at once in MongoDB.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Step 1: Select Target Scope */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
              Step 1: Select Target Websites Scope ({targetSites.length} Selected)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => handleScopeChange('all')}
                className={`p-3 rounded-xl border text-xs font-semibold text-center transition cursor-pointer ${scope === 'all'
                    ? 'bg-sky-50 border-sky-400 text-sky-800 ring-2 ring-sky-100'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
              >
                <Globe size={16} className="mx-auto mb-1 text-sky-500" />
                <div>All Websites</div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">({sites.length} sites)</div>
              </button>

              <button
                type="button"
                onClick={() => handleScopeChange('rajbiosis')}
                className={`p-3 rounded-xl border text-xs font-semibold text-center transition cursor-pointer ${scope === 'rajbiosis'
                    ? 'bg-sky-50 border-sky-400 text-sky-800 ring-2 ring-sky-100'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
              >
                <Building2 size={16} className="mx-auto mb-1 text-sky-600" />
                <div>Raj Biosis</div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  ({sites.filter(s => (s.companyId || 'rajbiosis') === 'rajbiosis').length} sites)
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleScopeChange('human_bio')}
                className={`p-3 rounded-xl border text-xs font-semibold text-center transition cursor-pointer ${scope === 'human_bio'
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-800 ring-2 ring-emerald-100'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
              >
                <Building2 size={16} className="mx-auto mb-1 text-emerald-500" />
                <div>Human Bio</div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  ({sites.filter(s => s.companyId === 'human_bio').length} sites)
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleScopeChange('global_bio')}
                className={`p-3 rounded-xl border text-xs font-semibold text-center transition cursor-pointer ${scope === 'global_bio'
                    ? 'bg-indigo-50 border-indigo-400 text-indigo-800 ring-2 ring-indigo-100'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
              >
                <Building2 size={16} className="mx-auto mb-1 text-indigo-500" />
                <div>Global Bio</div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  ({sites.filter(s => s.companyId === 'global_bio').length} sites)
                </div>
              </button>
            </div>

            {/* Targeted Domains Pills */}
            <div className="mt-3 flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-2 bg-slate-50 rounded-xl border border-slate-200/60">
              {sites.map(s => {
                const isChecked = targetSites.some(t => t.domain === s.domain);
                return (
                  <button
                    key={s.domain}
                    type="button"
                    onClick={() => toggleDomain(s.domain)}
                    className={`text-[11px] px-2.5 py-1 rounded-lg font-mono transition flex items-center gap-1 cursor-pointer ${isChecked
                        ? 'bg-sky-500 text-white font-semibold'
                        : 'bg-white text-slate-400 border border-slate-200 hover:text-slate-600'
                      }`}
                  >
                    <span>{s.domain}</span>
                    {isChecked && <Check size={11} />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Choose Fields to Update */}
          <div className="space-y-4">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Step 2: Choose Fields to Overwrite (Check to Enable)
            </label>

            {/* Phone */}
            <div className={`p-3.5 rounded-2xl border transition ${enablePhone ? 'bg-sky-50/40 border-sky-300' : 'bg-slate-50/50 border-slate-200'}`}>
              <div className="flex items-center justify-between mb-2">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enablePhone}
                    onChange={(e) => setEnablePhone(e.target.checked)}
                    className="rounded text-sky-500 focus:ring-sky-400"
                  />
                  <Phone size={14} className="text-sky-500" />
                  <span>Central Helpline Number</span>
                </label>
              </div>
              <input
                type="text"
                disabled={!enablePhone}
                value={phoneVal}
                onChange={(e) => setPhoneVal(e.target.value)}
                placeholder="e.g. 1800-419-BIOSIS"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-800 disabled:opacity-50 disabled:bg-slate-100 outline-none focus:border-sky-400"
              />
            </div>

            {/* Email */}
            <div className={`p-3.5 rounded-2xl border transition ${enableEmail ? 'bg-sky-50/40 border-sky-300' : 'bg-slate-50/50 border-slate-200'}`}>
              <div className="flex items-center justify-between mb-2">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableEmail}
                    onChange={(e) => setEnableEmail(e.target.checked)}
                    className="rounded text-sky-500 focus:ring-sky-400"
                  />
                  <Mail size={14} className="text-emerald-500" />
                  <span>Institutional Procurement Email</span>
                </label>
              </div>
              <input
                type="text"
                disabled={!enableEmail}
                value={emailVal}
                onChange={(e) => setEmailVal(e.target.value)}
                placeholder="e.g. procurement@biomedical.com"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-800 disabled:opacity-50 disabled:bg-slate-100 outline-none focus:border-sky-400"
              />
            </div>

            {/* City & Address */}
            <div className={`p-3.5 rounded-2xl border transition ${enableCity ? 'bg-sky-50/40 border-sky-300' : 'bg-slate-50/50 border-slate-200'}`}>
              <div className="flex items-center justify-between mb-2">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableCity}
                    onChange={(e) => setEnableCity(e.target.checked)}
                    className="rounded text-sky-500 focus:ring-sky-400"
                  />
                  <MapPin size={14} className="text-rose-500" />
                  <span>Central Dispatch City & Hub Address</span>
                </label>
              </div>
              <input
                type="text"
                disabled={!enableCity}
                value={cityVal}
                onChange={(e) => setCityVal(e.target.value)}
                placeholder="e.g. Bengaluru Central Hub, Karnataka"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-800 disabled:opacity-50 disabled:bg-slate-100 outline-none focus:border-sky-400"
              />
            </div>

            {/* WhatsApp */}
            <div className={`p-3.5 rounded-2xl border transition ${enableWhatsapp ? 'bg-sky-50/40 border-sky-300' : 'bg-slate-50/50 border-slate-200'}`}>
              <div className="flex items-center justify-between mb-2">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableWhatsapp}
                    onChange={(e) => setEnableWhatsapp(e.target.checked)}
                    className="rounded text-sky-500 focus:ring-sky-400"
                  />
                  <MessageSquare size={14} className="text-teal-500" />
                  <span>WhatsApp Direct Quotation Desk</span>
                </label>
              </div>
              <input
                type="text"
                disabled={!enableWhatsapp}
                value={whatsappVal}
                onChange={(e) => setWhatsappVal(e.target.value)}
                placeholder="e.g. +91 98210 55443"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-800 disabled:opacity-50 disabled:bg-slate-100 outline-none focus:border-sky-400"
              />
            </div>

            {/* Announcement Banner */}
            <div className={`p-3.5 rounded-2xl border transition ${enableAnnouncement ? 'bg-sky-50/40 border-sky-300' : 'bg-slate-50/50 border-slate-200'}`}>
              <div className="flex items-center justify-between mb-2">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableAnnouncement}
                    onChange={(e) => setEnableAnnouncement(e.target.checked)}
                    className="rounded text-sky-500 focus:ring-sky-400"
                  />
                  <AlertCircle size={14} className="text-amber-500" />
                  <span>Urgent Top Announcement Banner</span>
                </label>
              </div>
              <input
                type="text"
                disabled={!enableAnnouncement}
                value={announcementVal}
                onChange={(e) => setAnnouncementVal(e.target.value)}
                placeholder="e.g. CDSCO & ISO Approved Batch Ready for Priority Hospital Dispatch"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-800 disabled:opacity-50 disabled:bg-slate-100 outline-none focus:border-sky-400"
              />
            </div>

            {/* Theme Primary Color */}
            <div className={`p-3.5 rounded-2xl border transition ${enableColor ? 'bg-sky-50/40 border-sky-300' : 'bg-slate-50/50 border-slate-200'}`}>
              <div className="flex items-center justify-between mb-2">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableColor}
                    onChange={(e) => setEnableColor(e.target.checked)}
                    className="rounded text-sky-500 focus:ring-sky-400"
                  />
                  <Palette size={14} className="text-indigo-500" />
                  <span>Primary Brand Accent Color</span>
                </label>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  disabled={!enableColor}
                  value={colorVal}
                  onChange={(e) => setColorVal(e.target.value)}
                  className="w-10 h-10 rounded-xl border border-slate-200 p-0.5 cursor-pointer disabled:opacity-40"
                />
                <input
                  type="text"
                  disabled={!enableColor}
                  value={colorVal}
                  onChange={(e) => setColorVal(e.target.value)}
                  className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 text-xs bg-white text-slate-800 disabled:opacity-50 disabled:bg-slate-100 outline-none font-mono"
                />
              </div>
            </div>
          </div>

          {resultMsg && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 size={16} className="text-emerald-600" />
              <span>{resultMsg}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500">
            Applying changes to <strong>{targetSites.length} websites</strong> simultaneously in MongoDB.
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200/70 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleApplyBulkUpdate}
              disabled={isUpdating || targetSites.length === 0}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-amber-500 hover:bg-amber-600 transition shadow-sm shadow-amber-500/20 disabled:opacity-50 cursor-pointer"
            >
              {isUpdating ? (
                <>
                  <RefreshCw size={14} className="animate-spin" />
                  <span>Applying to MongoDB...</span>
                </>
              ) : (
                <>
                  <Zap size={14} />
                  <span>Apply Bulk Update ({targetSites.length} Sites)</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
