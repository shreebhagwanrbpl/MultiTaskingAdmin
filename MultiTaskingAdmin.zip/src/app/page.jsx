'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  LayoutDashboard, 
  Globe, 
  Inbox, 
  Package, 
  Settings, 
  Plus, 
  Search, 
  Filter, 
  Download, 
  PhoneCall, 
  Mail, 
  ExternalLink, 
  CheckCircle2, 
  Edit3, 
  Trash2, 
  Database, 
  Server, 
  ShieldCheck, 
  Eye, 
  ArrowRight,
  X,
  Layers,
  Sparkles,
  Palette,
  FileText,
  Send,
  Users,
  Building2,
  Target,
  Clock,
  CheckCheck,
  Paperclip,
  Smartphone,
  Tablet,
  Laptop,
  Check,
  History,
  ChevronRight,
  RefreshCw,
  AlertCircle,
  Wifi,
  WifiOff,
  Key,
  Copy,
  Zap,
  Dices
} from 'lucide-react';
import { PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import VisualPageBuilder from './components/VisualPageBuilder';
import BulkUpdateModal from './components/BulkUpdateModal';
import SiteThemeImporterModal from './components/SiteThemeImporterModal';
import { getDefaultBlocksForSite } from '../data/pageBlocks';

// ============================================================================
// 3 SENDER BIOMEDICAL COMPANIES (Raj Biosis, Human Biomedicals, Global Biomedical)
// ============================================================================
const SENDER_COMPANIES = [
  {
    id: 'rajbiosis',
    name: 'Raj Biosis Private Limited',
    shortName: 'Raj Biosis',
    tagline: 'Biomedical & Hospital Equipment Manufacturer',
    email: 'institutional@rajbiosis.com',
    phone: '1800-419-BIOSIS',
    specialty: 'ICU Critical Care & Advanced Modular OT Systems',
    logo: '/rajbiosis-logo.png',
    address: 'Plot No. 42, Electronic City Phase 1, Bengaluru, Karnataka - 560100',
    isoCert: 'ISO 13485:2016 & CDSCO Certified Medical Device Manufacturer',
    accentColor: '#0ea5e9',
    badge: 'Flagship OEM Division'
  },
  {
    id: 'human_bio',
    name: 'Human Biomedicals',
    shortName: 'Human Biomedicals',
    tagline: 'Patient Monitoring & Life Support Technologies',
    email: 'sales@humanbiomedicals.in',
    phone: '1800-200-HUMAN',
    specialty: 'Multi-Para Monitors, Dialysis & Emergency Defibrillators',
    logo: null,
    address: 'Tower B, Biomedical Innovation Hub, Andheri East, Mumbai, Maharashtra - 400069',
    isoCert: 'ISO 9001:2015 & CE European Standard Medical Systems',
    accentColor: '#10b981',
    badge: 'Patient Monitoring'
  },
  {
    id: 'global_bio',
    name: 'Global Biomedical',
    shortName: 'Global Biomedical',
    tagline: 'Precision Radiology & Diagnostic Imaging',
    email: 'corporate@globalbiomedical.com',
    phone: '1800-888-GLOBAL',
    specialty: 'High-Frequency Digital X-Ray, 4D Ultrasound & C-Arm',
    logo: null,
    address: 'DLF Cyber City, Sector 24, Gurugram, National Capital Region - 122002',
    isoCert: 'AERB Approved & US-FDA Compliance Diagnostic Division',
    accentColor: '#6366f1',
    badge: 'Imaging & Diagnostics'
  }
];

// Pre-built Hospital Email Templates
const EMAIL_TEMPLATES = [
  {
    id: 'followup',
    name: '⚡ Hot RFQ Quote Follow-Up',
    description: 'Nudge doctors and procurement heads who recently requested equipment pricing',
    subject: 'Official Quotation Follow-up & Priority Hospital Allocation - {Company_Name}',
    preheader: 'Special institutional rate and immediate dispatch slot reserved for {Hospital_Name}.',
    body: `Respected {Doctor_Name},
Procurement Committee, {Hospital_Name},

We hope this email finds you well.

This is a gentle follow-up regarding your recent institutional equipment inquiry for {Equipment_Name} with an estimated budget allocation of {Quotation_Amount}.

Our biomedical engineering team is ready to provide:
1. Turnkey onsite equipment installation & hands-on staff training.
2. Full 2-Year Comprehensive OEM Warranty + 5-Year CMC Support.
3. Priority batch dispatch directly from our central warehouse hub.

Would your biomedical team prefer a 15-minute live technical demonstration or an updated institutional price breakdown?`,
    ctaText: 'Review Official OEM Quotation (PDF)',
    ctaUrl: 'https://rajbiosis.com/rfq/view'
  },
  {
    id: 'new_launch',
    name: '🚀 New Specialized Website & Portal Launch',
    description: 'Announce newly launched specialist portals from our 70-site network to hospitals',
    subject: 'Announcing Direct OEM Procurement Portals: {Company_Name} Digital Expansion',
    preheader: 'Access dedicated ICU, Surgical, and Diagnostic portals with zero middleman costs.',
    body: `Dear Healthcare Partner / Biomedical Procurement Head,

We are thrilled to announce the rollout of our specialized digital procurement network across 70 dedicated biomedical websites.

Each specialized portal offers your hospital:
• Direct GeM-Compliant Institutional Pricing schedules.
• High-resolution technical spec-sheets, user manuals, and calibration certificates.
• Instant 1-click quotation generation for hospital board approval.

Visit our newly launched portals today to register your hospital for prioritized OEM dispatch.`,
    ctaText: 'Explore New Equipment Network Portals',
    ctaUrl: 'https://rajbiosis.com/portals'
  },
  {
    id: 'amc_service',
    name: '🔧 AMC & Preventative Maintenance Check',
    description: 'Remind hospital engineering teams to renew service contracts & calibration',
    subject: 'Annual Maintenance (AMC) & Biomedical Calibration Notice - {Hospital_Name}',
    preheader: 'Ensure regulatory NABH compliance and 100% equipment uptime with certified engineers.',
    body: `Attention: Chief Biomedical Engineer & Administration, {Hospital_Name},

Patient safety and clinical regulatory standards mandate routine biomedical calibration of all critical life-support systems.

Our factory-certified service engineers are currently conducting regional maintenance audits for:
• ICU Mechanical Ventilators & Anesthesia Workstations
• Multi-Parameter Monitors & Defibrillator Discharge Calibration
• Digital X-Ray Calibration & Radiation Leakage Safety Inspection

Click below to request an on-demand engineer site visit or renew your comprehensive maintenance contract.`,
    ctaText: 'Schedule Biomedical Calibration Visit',
    ctaUrl: 'https://rajbiosis.com/amc-service'
  },
  {
    id: 'bulk_subsidy',
    name: '🏥 Institutional Bulk Procurement Subsidy',
    description: 'Offer direct manufacturer subsidies for hospital department setups & expansions',
    subject: 'Institutional Subsidy Scheme: Up to 18% Concession on Hospital Setup Upgrades',
    preheader: 'Direct manufacturer price advantage for NABH-accredited hospitals and nursing homes.',
    body: `Dear Medical Director / Hospital Purchase Committee,

To assist new hospital wing expansions across India, our biomedical manufacturing group is pleased to introduce our Institutional Subsidy Program.

Program Privileges for Registered Hospitals:
• Flexible zero-interest installment options for hospital ICU and OT suites.
• Free central telemetry console with every order of 4+ patient monitors.
• Immediate stock allocation for Critical Care Ventilators and 4K Laparoscopy Towers.

Review our certified equipment catalog or contact our institutional desk directly at {Support_Phone}.`,
    ctaText: 'Download Complete Institutional Catalog',
    ctaUrl: 'https://rajbiosis.com/catalog'
  },
  {
    id: 'blank',
    name: '✍️ Custom Blank Campaign',
    description: 'Start with a clean slate to craft any specialized communication or notice',
    subject: '',
    preheader: '',
    body: '',
    ctaText: 'Learn More',
    ctaUrl: 'https://rajbiosis.com'
  }
];

// Target Customers Database for Email Marketing
const MARKETING_CUSTOMERS = [
  { id: 'cust-1', name: 'Dr. S. K. Mehta', role: 'Chief of ICU', hospital: 'Apollo Super Speciality Hospital', email: 'dr.mehta@apollohospitals.com', phone: '+91 98210 55443', equipment: 'ICU Ventilator Pro-X9', quoteAmount: '₹9,70,000', status: 'Pending RFQ' },
  { id: 'cust-2', name: 'Er. Rajesh K. Varma', role: 'Biomedical Lead', hospital: 'Fortis Escorts Heart Institute', email: 'rajesh.varma@fortishealthcare.com', phone: '+91 98112 44321', equipment: 'CardioPulse Multi-Para Monitor', quoteAmount: '₹2,74,000', status: 'Quote Sent' },
  { id: 'cust-3', name: 'Dr. Anita Sen', role: 'Head of Surgery', hospital: 'Tata Memorial Hospital, Mumbai', email: 'anita.sen@tmc.gov.in', phone: '+91 98450 77881', equipment: 'AuraSurg 4K UHD Tower', quoteAmount: '₹14,50,000', status: 'In Review' },
  { id: 'cust-4', name: 'Dr. K. Srinivas', role: 'Chief Radiologist', hospital: 'Care Diagnostic Centre, Hyderabad', email: 'srinivas.k@carediagnostics.in', phone: '+91 99881 22334', equipment: 'RayMaster 500mA Fixed X-Ray', quoteAmount: '₹18,50,000', status: 'Quote Sent' },
  { id: 'cust-5', name: 'Dr. Rajiv Anand', role: 'Emergency Director', hospital: 'Max Super Speciality, Saket', email: 'rajiv.anand@maxhealthcare.com', phone: '+91 98101 99002', equipment: 'DefiQuick Biphasic Defibrillator', quoteAmount: '₹5,85,000', status: 'Order Pipeline' },
  { id: 'cust-6', name: 'Dr. Vikram Rathore', role: 'Purchase Director', hospital: 'AIIMS New Delhi', email: 'procurement@aiims.edu', phone: '+91 98100 11223', equipment: 'Centralized MGPS & ICU Beds', quoteAmount: '₹34,00,000', status: 'Tender Notice' },
  { id: 'cust-7', name: 'Dr. Priya Nair', role: 'Nephrology Head', hospital: 'Manipal Hospital Bengaluru', email: 'priya.nair@manipalhospitals.com', phone: '+91 98440 22331', equipment: 'HemoPure Dialysis Machine', quoteAmount: '₹11,20,000', status: 'Demo Requested' }
];

// ============================================================================
// PRESET CONFIGURATIONS (Users can choose presets OR freely type custom values)
// ============================================================================
const PRESET_FONTS = [
  { value: 'Plus Jakarta Sans', label: 'Plus Jakarta Sans (Modern Medical)' },
  { value: 'Outfit', label: 'Outfit (High-Tech Geometric)' },
  { value: 'Manrope', label: 'Manrope (Swiss Precision)' },
  { value: 'Inter', label: 'Inter (Clean Neutral)' },
  { value: 'Space Grotesk', label: 'Space Grotesk (Biomedical Tech)' },
  { value: 'Poppins', label: 'Poppins (Friendly & Clean)' },
  { value: 'Roboto', label: 'Roboto (Standard Clinical)' },
  { value: 'Montserrat', label: 'Montserrat (Corporate Authority)' }
];

const PRESET_HOMEPAGE_LAYOUTS = [
  { value: 'Banner Carousel', label: 'Style 1: Banner Carousel (E-Commerce)' },
  { value: 'Split Sidebar B2B', label: 'Style 2: Split Sidebar B2B Catalog' },
  { value: 'Turnkey Solution Suites', label: 'Style 3: Turnkey Clinical Suites First' },
  { value: 'Catalog First', label: 'Style 4: Catalog First (Dense Grid)' },
  { value: 'Minimalist Hero', label: 'Style 5: Minimalist Hero Banner' }
];

const PRESET_CARD_STYLES = [
  { value: 'Bordered Minimal', label: 'Style 1: Bordered Minimal with Specs' },
  { value: 'Floating Shadow', label: 'Style 2: Floating Shadow with Full RFQ' },
  { value: 'B2B Row Table', label: 'Style 3: B2B Row Table (IndiaMART style)' },
  { value: 'Glassmorphic Modern', label: 'Style 4: Glassmorphic Modern Card' }
];

const PRESET_HEADER_STYLES = [
  { value: 'Telemetry Bar', label: 'Style 1: Top Telemetry Bar + Brand' },
  { value: 'Minimalist Single Row', label: 'Style 2: Minimalist Single Row' },
  { value: 'Centered Search', label: 'Style 3: Prominent Centered Search' },
  { value: 'Sticky Floating Pill', label: 'Style 4: Sticky Floating Pill Navbar' }
];

const PRESET_CATEGORIES = [
  { value: 'All Clinical Departments', label: 'All Clinical Departments (Complete Catalog)' },
  { value: 'ICU & Critical Care', label: 'ICU & Critical Care Focus' },
  { value: 'Surgical & OT Equipment', label: 'Surgical & OT Equipment Focus' },
  { value: 'Radiology & Imaging', label: 'Radiology & Diagnostic Imaging Focus' },
  { value: 'Diagnostic & Pathology Lab', label: 'Diagnostic & Pathology Lab Focus' },
  { value: 'Hospital Infrastructure', label: 'Hospital Infrastructure Focus' },
  { value: 'Cardiology & Resuscitation', label: 'Cardiology & Resuscitation' },
  { value: 'Dialysis & Nephrology', label: 'Dialysis & Nephrology Units' },
  { value: 'Ophthalmic Surgery', label: 'Ophthalmic & Eye Surgery' },
  { value: 'Dental & Maxillofacial', label: 'Dental & Maxillofacial Chairs' }
];

export default function AdminDashboardPage() {
  const [activeTab, setActiveTab] = useState('sites'); // 'overview', 'sites', 'leads', 'products', 'vps'
  const [siteSearch, setSiteSearch] = useState('');
  const [leadFilterDomain, setLeadFilterDomain] = useState('all');
  const [isAddSiteOpen, setIsAddSiteOpen] = useState(false);
  const [isDashboardImporterOpen, setIsDashboardImporterOpen] = useState(false);
  const [previewingSite, setPreviewingSite] = useState(null);
  const [previewDeviceMode, setPreviewDeviceMode] = useState('desktop'); // 'desktop' | 'tablet' | 'mobile'

  // Live MongoDB Database State
  const [dbStatus, setDbStatus] = useState({
    connected: false,
    checking: true,
    latency: '',
    database: 'biomedical_network',
    counts: { sites: 7, leads: 5, campaigns: 4 },
    uri: '',
    error: null
  });
  const [mongoUriInput, setMongoUriInput] = useState('mongodb+srv://admin:pass@vps-cluster.mongodb.net/biomedical_network');
  const [isTestingMongo, setIsTestingMongo] = useState(false);
  const [mongoTestResult, setMongoTestResult] = useState(null);
  const [isSavingMongo, setIsSavingMongo] = useState(false);
  const [isSeedingMongo, setIsSeedingMongo] = useState(false);

  // Email Marketing Hub State
  const [selectedCompanyId, setSelectedCompanyId] = useState('rajbiosis');
  const [targetAudience, setTargetAudience] = useState('followup'); // 'followup', 'all', 'specific', 'new_sites', 'manual'
  const [selectedCustomerIds, setSelectedCustomerIds] = useState(['cust-1', 'cust-2']);
  const [selectedTemplateId, setSelectedTemplateId] = useState('followup');
  const [campaignSubject, setCampaignSubject] = useState(EMAIL_TEMPLATES[0].subject);
  const [campaignPreheader, setCampaignPreheader] = useState(EMAIL_TEMPLATES[0].preheader);
  const [campaignBody, setCampaignBody] = useState(EMAIL_TEMPLATES[0].body);
  const [ctaText, setCtaText] = useState(EMAIL_TEMPLATES[0].ctaText);
  const [ctaUrl, setCtaUrl] = useState(EMAIL_TEMPLATES[0].ctaUrl);
  const [attachedDocs, setAttachedDocs] = useState(['spec_sheet', 'iso_cert']);
  const [manualEmails, setManualEmails] = useState('procurement@apollohospitals.com, dr.kapoor@fortis.in');
  const [previewDevice, setPreviewDevice] = useState('desktop'); // 'desktop' | 'mobile'
  const [marketingSubTab, setMarketingSubTab] = useState('compose'); // 'compose' | 'history'
  const [isSending, setIsSending] = useState(false);
  const [sendSuccessMsg, setSendSuccessMsg] = useState(null);

  const [campaignHistory, setCampaignHistory] = useState([]);

  const currentCompany = SENDER_COMPANIES.find(c => c.id === selectedCompanyId) || SENDER_COMPANIES[0];

  const getRecipientCount = () => {
    if (targetAudience === 'all') return '2,840 Hospitals & Clinics';
    if (targetAudience === 'followup') return '42 Hot Quotation Leads';
    if (targetAudience === 'new_sites') return '1,420 Network Procurement Heads';
    if (targetAudience === 'specific') return `${selectedCustomerIds.length} Selected Hospitals`;
    if (targetAudience === 'manual') {
      const count = manualEmails.split(',').filter(e => e.trim().length > 0).length;
      return `${count} Manual Email${count === 1 ? '' : 's'}`;
    }
    return '0 Recipients';
  };

  const handleSelectTemplate = (templateId) => {
    setSelectedTemplateId(templateId);
    const tpl = EMAIL_TEMPLATES.find(t => t.id === templateId);
    if (tpl) {
      setCampaignSubject(tpl.subject);
      setCampaignPreheader(tpl.preheader);
      setCampaignBody(tpl.body);
      setCtaText(tpl.ctaText);
      setCtaUrl(tpl.ctaUrl);
    }
  };

  const handleToggleCustomer = (customerId) => {
    setSelectedCustomerIds(prev => 
      prev.includes(customerId) 
        ? prev.filter(id => id !== customerId) 
        : [...prev, customerId]
    );
  };

  const handleSelectAllCustomers = () => {
    if (selectedCustomerIds.length === MARKETING_CUSTOMERS.length) {
      setSelectedCustomerIds([]);
    } else {
      setSelectedCustomerIds(MARKETING_CUSTOMERS.map(c => c.id));
    }
  };

  const handleToggleDoc = (docKey) => {
    setAttachedDocs(prev => 
      prev.includes(docKey) 
        ? prev.filter(k => k !== docKey) 
        : [...prev, docKey]
    );
  };

  const handleInsertTag = (tag) => {
    setCampaignBody(prev => prev + ' ' + tag);
  };

  const getPreviewBody = () => {
    let text = campaignBody;
    text = text.replaceAll('{Doctor_Name}', 'Dr. S. K. Mehta');
    text = text.replaceAll('{Hospital_Name}', 'Apollo Super Speciality Hospital');
    text = text.replaceAll('{Equipment_Name}', 'RajBiosis-Vent Pro-X9 Ventilator');
    text = text.replaceAll('{Quotation_Amount}', '₹9,70,000');
    text = text.replaceAll('{Company_Name}', currentCompany.name);
    text = text.replaceAll('{Support_Phone}', currentCompany.phone);
    return text;
  };

  const getPreviewSubject = () => {
    let subj = campaignSubject;
    subj = subj.replaceAll('{Doctor_Name}', 'Dr. S. K. Mehta');
    subj = subj.replaceAll('{Hospital_Name}', 'Apollo Super Speciality');
    subj = subj.replaceAll('{Equipment_Name}', 'ICU Ventilator Pro-X9');
    subj = subj.replaceAll('{Company_Name}', currentCompany.name);
    return subj;
  };

  const handleSendCampaign = (e) => {
    e?.preventDefault();
    if (!campaignSubject.trim()) {
      alert("Please enter a subject line for your email campaign!");
      return;
    }
    if (!campaignBody.trim()) {
      alert("Please write the email content before sending!");
      return;
    }
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      const newLog = {
        id: `CAMP-${Math.floor(100000 + Math.random() * 900000)}`,
        company: currentCompany.name,
        companyId: currentCompany.id,
        subject: getPreviewSubject(),
        audience: getRecipientCount(),
        sentAt: 'Just now',
        openRate: '0.0%',
        status: 'Delivered',
        recipients: targetAudience === 'specific' ? selectedCustomerIds.length : (targetAudience === 'followup' ? 42 : (targetAudience === 'all' ? 2840 : 1420))
      };
      setCampaignHistory(prev => [newLog, ...prev]);
      setSendSuccessMsg(`Campaign successfully broadcast to ${getRecipientCount()} from ${currentCompany.name}!`);
      setTimeout(() => setSendSuccessMsg(null), 6000);

      // Persist to MongoDB
      try {
        fetch('/api/campaigns', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newLog)
        });
      } catch (err) {
        console.warn('MongoDB campaign sync:', err);
      }
    }, 1200);
  };

  const handleSendTestEmail = () => {
    alert(`Test email sent to admin@rajbiosis.com as preview from '${currentCompany.name}'. Check your inbox!`);
  };

  // 70 Websites Initial Registry State (Multi-tenant loaded from MongoDB)
  const [sites, setSites] = useState([]);
  const [isSitesLoading, setIsSitesLoading] = useState(true);

  // Multi-Company Brand Filter: 'all' | 'rajbiosis' | 'human_bio' | 'global_bio'
  const [selectedCompanyFilter, setSelectedCompanyFilter] = useState('all');

  // Visual Page Builder Modal State
  const [builderSite, setBuilderSite] = useState(null);
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);

  // Bulk Mass Update Modal State
  const [isBulkUpdateOpen, setIsBulkUpdateOpen] = useState(false);

  // Parent Company for New/Edited Website
  const [newCompanyId, setNewCompanyId] = useState('rajbiosis');

  // Centralized Inquiries / Leads (cross-domain) - Loaded live from MongoDB Atlas
  const [leads, setLeads] = useState([]);

  // Selected / Editing Site ID (null = creating new site)
  const [editingSiteId, setEditingSiteId] = useState(null);

  // Form State for creating / editing site
  const [newDomain, setNewDomain] = useState('');
  const [newBrandName, setNewBrandName] = useState('');
  const [newTagline, setNewTagline] = useState('');
  const [newColor, setNewColor] = useState('#0ea5e9');
  const [newFont, setNewFont] = useState('Plus Jakarta Sans');
  const [newHeaderStyle, setNewHeaderStyle] = useState('Telemetry Bar');
  const [newHomepageLayout, setNewHomepageLayout] = useState('Banner Carousel');
  const [newCardStyle, setNewCardStyle] = useState('Bordered Minimal');
  const [newPhone, setNewPhone] = useState('1800-419-BIOSIS');
  const [newEmail, setNewEmail] = useState('sales@biomedical.in');
  const [newCity, setNewCity] = useState('New Delhi, India');
  const [newCategoryFocus, setNewCategoryFocus] = useState('All Clinical Departments');
  const [newThemeMode, setNewThemeMode] = useState('Clean Medical Light');
  const [newWhatsapp, setNewWhatsapp] = useState('');
  const [newHeroTitle, setNewHeroTitle] = useState('');
  const [newAnnouncement, setNewAnnouncement] = useState('');
  const [newLogo, setNewLogo] = useState('');
  const [newBannerImage, setNewBannerImage] = useState('');
  const [newExtractedBlocks, setNewExtractedBlocks] = useState(null);
  const [newExtractedCategories, setNewExtractedCategories] = useState(null);
  const [newExtractedProducts, setNewExtractedProducts] = useState(null);

  // Custom Input Toggles (allow user to freely type anything or pick preset)
  const [customFontMode, setCustomFontMode] = useState(false);
  const [customLayoutMode, setCustomLayoutMode] = useState(false);
  const [customCardMode, setCustomCardMode] = useState(false);
  const [customHeaderMode, setCustomHeaderMode] = useState(false);
  const [customCategoryMode, setCustomCategoryMode] = useState(false);
  const [showAdvancedLaunchSettings, setShowAdvancedLaunchSettings] = useState(false);

  const randomizeLaunchUiStyle = () => {
    const sampleColors = ['#0ea5e9', '#059669', '#7c3aed', '#e11d48', '#0d9488', '#d97706', '#182A54', '#0f172a', '#2563eb'];
    const sampleFonts = ['Outfit', 'Plus Jakarta Sans', 'Inter', 'Space Grotesk', 'Poppins', 'Manrope'];
    const sampleHeaders = ['Sticky Floating Pill', 'Minimalist Single Row', 'Centered Search', 'Telemetry Bar'];
    const sampleLayouts = ['Centered Grand Impact', 'Split Sidebar B2B', 'Banner Carousel'];
    const sampleCards = ['Floating Shadow', 'Glassmorphic Modern', 'B2B Row Table', 'Bordered Minimal'];
    const pick = arr => arr[Math.floor(Math.random() * arr.length)];

    setNewColor(pick(sampleColors));
    setNewFont(pick(sampleFonts));
    setNewHeaderStyle(pick(sampleHeaders));
    setNewHomepageLayout(pick(sampleLayouts));
    setNewCardStyle(pick(sampleCards));
    setCustomFontMode(false);
    setCustomLayoutMode(false);
    setCustomCardMode(false);
    setCustomHeaderMode(false);
  };

  const resetForm = () => {
    setEditingSiteId(null);
    setShowAdvancedLaunchSettings(false);
    setNewCompanyId(selectedCompanyFilter !== 'all' ? selectedCompanyFilter : 'rajbiosis');
    setNewDomain('');
    setNewBrandName('');
    setNewTagline('');

    // Har baar alag, unique UI randomize karein
    const sampleColors = ['#0ea5e9', '#059669', '#7c3aed', '#e11d48', '#0d9488', '#d97706', '#182A54', '#0f172a', '#2563eb'];
    const sampleFonts = ['Outfit', 'Plus Jakarta Sans', 'Inter', 'Space Grotesk', 'Poppins', 'Manrope'];
    const sampleHeaders = ['Sticky Floating Pill', 'Minimalist Single Row', 'Centered Search', 'Telemetry Bar'];
    const sampleLayouts = ['Centered Grand Impact', 'Split Sidebar B2B', 'Banner Carousel'];
    const sampleCards = ['Floating Shadow', 'Glassmorphic Modern', 'B2B Row Table', 'Bordered Minimal'];
    const pick = arr => arr[Math.floor(Math.random() * arr.length)];

    setNewColor(pick(sampleColors));
    setNewFont(pick(sampleFonts));
    setNewHeaderStyle(pick(sampleHeaders));
    setNewHomepageLayout(pick(sampleLayouts));
    setNewCardStyle(pick(sampleCards));

    setNewPhone('1800-419-BIOSIS');
    setNewEmail('sales@biomedical.in');
    setNewCity('New Delhi, India');
    setNewCategoryFocus('All Clinical Departments');
    setNewThemeMode('Clean Medical Light');
    setNewWhatsapp('');
    setNewHeroTitle('');
    setNewAnnouncement('');
    setNewLogo('');
    setNewBannerImage('');
    setNewExtractedBlocks(null);
    setNewExtractedCategories(null);
    setNewExtractedProducts(null);
    setCustomFontMode(false);
    setCustomLayoutMode(false);
    setCustomCardMode(false);
    setCustomHeaderMode(false);
    setCustomCategoryMode(false);
  };

  // Load live data from MongoDB on mount
  useEffect(() => {
    checkDbStatus();
    loadSitesFromDb();
    loadLeadsFromDb();
    loadCampaignsFromDb();
  }, []);

  // Handle URL query parameters (e.g. ?builder=rajbiosis.com or ?import=true)
  useEffect(() => {
    if (typeof window !== 'undefined' && sites.length > 0) {
      const params = new URLSearchParams(window.location.search);
      const builderParam = params.get('builder');
      if (builderParam) {
        const found = sites.find(s => s.domain === builderParam || s.id === builderParam);
        if (found) {
          setBuilderSite(found);
          setIsBuilderOpen(true);
        }
      }
      if (params.get('import') === 'true') {
        setIsDashboardImporterOpen(true);
      }
    }
  }, [sites]);

  const checkDbStatus = async () => {
    try {
      const res = await fetch('/api/db/status');
      const data = await res.json();
      setDbStatus({
        connected: !!data.connected,
        checking: false,
        latency: data.latency || '',
        database: data.database || 'biomedical_network',
        counts: data.counts || { sites: 7, leads: 5, campaigns: 4 },
        uri: data.uri || '',
        error: data.error
      });
      if (data.uri) {
        setMongoUriInput(data.uri);
      }
    } catch (e) {
      setDbStatus(prev => ({ ...prev, checking: false, connected: false, error: e.message }));
    }
  };

  const loadSitesFromDb = async () => {
    setIsSitesLoading(true);
    try {
      const res = await fetch('/api/sites');
      const data = await res.json();
      if (data.success && Array.isArray(data.sites)) {
        setSites(data.sites);
      }
    } catch (e) {
      console.warn('MongoDB sites fallback:', e);
    } finally {
      setIsSitesLoading(false);
    }
  };

  const loadLeadsFromDb = async () => {
    try {
      const res = await fetch('/api/leads');
      const data = await res.json();
      if (data.success && Array.isArray(data.leads)) {
        setLeads(data.leads);
      }
    } catch (e) {
      console.warn('MongoDB leads fallback:', e);
    }
  };

  const loadCampaignsFromDb = async () => {
    try {
      const res = await fetch('/api/campaigns');
      const data = await res.json();
      if (data.success && Array.isArray(data.campaigns)) {
        setCampaignHistory(data.campaigns);
      }
    } catch (e) {
      console.warn('MongoDB campaigns fallback:', e);
    }
  };

  const handleTestMongoUri = async () => {
    setIsTestingMongo(true);
    setMongoTestResult(null);
    try {
      const res = await fetch('/api/db/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'test', uri: mongoUriInput })
      });
      const data = await res.json();
      setMongoTestResult(data);
    } catch (e) {
      setMongoTestResult({ success: false, connected: false, error: e.message });
    } finally {
      setIsTestingMongo(false);
    }
  };

  const handleSaveMongoUri = async () => {
    setIsSavingMongo(true);
    setMongoTestResult(null);
    try {
      const res = await fetch('/api/db/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'save', uri: mongoUriInput })
      });
      const data = await res.json();
      setMongoTestResult(data);
      if (data.success) {
        await checkDbStatus();
        await loadSitesFromDb();
        await loadLeadsFromDb();
        await loadCampaignsFromDb();
      }
    } catch (e) {
      setMongoTestResult({ success: false, error: e.message });
    } finally {
      setIsSavingMongo(false);
    }
  };

  const handleReseedMongo = async () => {
    setIsSeedingMongo(true);
    try {
      const res = await fetch('/api/db/seed', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        await checkDbStatus();
        await loadSitesFromDb();
        await loadLeadsFromDb();
        await loadCampaignsFromDb();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSeedingMongo(false);
    }
  };

  const handleApplyImportedThemeDashboard = (resultOrData) => {
    if (!resultOrData) return;
    const data = resultOrData.extractedData || resultOrData;
    const blocks = resultOrData.layoutBlocks;
    resetForm();
    if (data.domain) setNewDomain(data.domain);
    if (data.brandName) setNewBrandName(data.brandName);
    if (data.tagline) setNewTagline(data.tagline);
    if (data.heroTitle) setNewHeroTitle(data.heroTitle);
    if (data.primaryColor) setNewColor(data.primaryColor);
    if (data.phone) setNewPhone(data.phone);
    if (data.email) setNewEmail(data.email);
    if (data.categoryFocus) setNewCategoryFocus(data.categoryFocus);
    if (data.logo) setNewLogo(data.logo);
    if (data.bannerImage) setNewBannerImage(data.bannerImage);
    if (data.categories) setNewExtractedCategories(data.categories);
    if (data.customProducts) setNewExtractedProducts(data.customProducts);
    if (blocks && Array.isArray(blocks)) setNewExtractedBlocks(blocks);
    setIsDashboardImporterOpen(false);
    setIsAddSiteOpen(true);
  };

  const openCreateSite = () => {
    resetForm();
    setIsAddSiteOpen(true);
  };

  const openEditSite = (site) => {
    setEditingSiteId(site.id || site._id || site.domain);
    setNewCompanyId(site.companyId || 'rajbiosis');
    setNewDomain(site.domain);
    setNewBrandName(site.brandName);
    setNewTagline(site.tagline || '');
    setNewColor(site.primaryColor || '#dc2626');
    setNewFont(site.font || 'Plus Jakarta Sans');
    setNewHeaderStyle(site.headerStyle || 'Telemetry Bar');
    setNewHomepageLayout(site.homepageLayout || 'Banner Carousel');
    setNewCardStyle(site.cardStyle || 'Bordered Minimal');
    setNewCategoryFocus(site.categoryFocus || 'All Clinical Departments');
    setNewPhone(site.phone || '1800-XXX-XXXX');
    setNewEmail(site.email || `sales@${site.domain}`);
    setNewCity(site.city || 'New Delhi, India');
    setNewThemeMode(site.themeMode || 'Clean Medical Light');
    setNewWhatsapp(site.whatsapp || '');
    setNewHeroTitle(site.heroTitle || '');
    setNewAnnouncement(site.announcement || '');
    setNewLogo(site.logo || '');
    setNewBannerImage(site.bannerImage || '');
    setNewExtractedBlocks(site.layoutBlocks || null);
    setNewExtractedCategories(site.categories || null);
    setNewExtractedProducts(site.customProducts || null);

    // Auto-detect if current values are custom or presets
    setCustomFontMode(!PRESET_FONTS.some(f => f.value === site.font));
    setCustomLayoutMode(!PRESET_HOMEPAGE_LAYOUTS.some(l => l.value === site.homepageLayout));
    setCustomCardMode(!PRESET_CARD_STYLES.some(c => c.value === site.cardStyle));
    setCustomHeaderMode(!PRESET_HEADER_STYLES.some(h => h.value === site.headerStyle));
    setCustomCategoryMode(!PRESET_CATEGORIES.some(c => c.value === site.categoryFocus));

    setIsAddSiteOpen(true);
  };

  const handleDeleteSite = async (site) => {
    const siteDomain = site?.domain || '';
    const siteId = site?.id || '';
    const siteMongoId = site?._id || '';

    if (!confirm(`Are you sure you want to permanently delete website '${siteDomain}' from MongoDB and your network?`)) {
      return;
    }

    // Optimistically remove from state
    setSites(prev => prev.filter(s => {
      if (siteDomain && s.domain === siteDomain) return false;
      if (siteId && s.id && s.id === siteId) return false;
      if (siteMongoId && s._id && s._id === siteMongoId) return false;
      return true;
    }));

    // Purge any preview override in localStorage
    try {
      if (siteDomain) localStorage.removeItem(`preview_override_${siteDomain}`);
    } catch (e) {}

    try {
      const queryParams = new URLSearchParams();
      if (siteId) queryParams.set('id', siteId);
      if (siteDomain) queryParams.set('domain', siteDomain);
      if (siteMongoId) queryParams.set('_id', siteMongoId);

      const res = await fetch(`/api/sites?${queryParams.toString()}`, { 
        method: 'DELETE' 
      });
      const data = await res.json();
      if (!data.success) {
        alert(`Failed to delete website from MongoDB: ${data.error}`);
        await loadSitesFromDb();
      } else {
        await checkDbStatus();
      }
    } catch (err) {
      alert(`Network error deleting site: ${err.message}`);
      await loadSitesFromDb();
    }
  };

  const handleSaveSite = async (e, openInBuilder = false) => {
    if (e && e.preventDefault) e.preventDefault();
    if (!newDomain || !newBrandName) {
      alert("Please enter Domain Name and Brand Name!");
      return;
    }

    const defaultBlocks = getDefaultBlocksForSite({
      domain: newDomain.toLowerCase().trim(),
      heroTitle: newHeroTitle.trim(),
      announcement: newAnnouncement.trim(),
      city: newCity || 'New Delhi, India'
    });

    if (editingSiteId) {
      // Update existing site
      const existing = sites.find(s => s.id === editingSiteId || s._id === editingSiteId || s.domain === editingSiteId) || {};
      const updatedSite = {
        ...existing,
        id: editingSiteId,
        companyId: newCompanyId || 'rajbiosis',
        domain: newDomain.toLowerCase().trim(),
        brandName: newBrandName.trim(),
        tagline: newTagline.trim() || 'Biomedical & Hospital Equipment Systems',
        primaryColor: newColor,
        font: newFont || 'Plus Jakarta Sans',
        headerStyle: newHeaderStyle || 'Telemetry Bar',
        homepageLayout: newHomepageLayout || 'Banner Carousel',
        cardStyle: newCardStyle || 'Bordered Minimal',
        categoryFocus: newCategoryFocus || 'All Clinical Departments',
        phone: newPhone || '1800-419-BIOSIS',
        email: newEmail || `sales@${newDomain.toLowerCase().trim()}`,
        city: newCity || 'New Delhi, India',
        themeMode: newThemeMode,
        whatsapp: newWhatsapp.trim(),
        heroTitle: newHeroTitle.trim(),
        announcement: newAnnouncement.trim(),
        logo: newLogo || existing.logo || '',
        bannerImage: newBannerImage || existing.bannerImage || '',
        categories: newExtractedCategories || existing.categories || undefined,
        customProducts: newExtractedProducts || existing.customProducts || undefined,
        layoutBlocks: (newExtractedBlocks && newExtractedBlocks.length > 0)
          ? newExtractedBlocks
          : (existing.layoutBlocks && existing.layoutBlocks.length > 0 ? existing.layoutBlocks : defaultBlocks)
      };
      setSites(prev => prev.map(s => (s.id === editingSiteId || s._id === editingSiteId || s.domain === editingSiteId) ? { ...s, ...updatedSite } : s));
      try {
        await fetch('/api/sites', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updatedSite)
        });
      } catch (err) {
        console.warn('MongoDB sync:', err);
      }
      setIsAddSiteOpen(false);
      resetForm();

      if (openInBuilder) {
        setBuilderSite(updatedSite);
        setIsBuilderOpen(true);
      }
    } else {
      // Create new site
      const newSiteObj = {
        id: `site-${String(sites.length + 1).padStart(2, '0')}`,
        companyId: newCompanyId || 'rajbiosis',
        domain: newDomain.toLowerCase().trim(),
        brandName: newBrandName.trim(),
        tagline: newTagline.trim() || 'Biomedical & Hospital Equipment Systems',
        primaryColor: newColor,
        font: newFont || 'Plus Jakarta Sans',
        headerStyle: newHeaderStyle || 'Telemetry Bar',
        homepageLayout: newHomepageLayout || 'Banner Carousel',
        cardStyle: newCardStyle || 'Bordered Minimal',
        categoryFocus: newCategoryFocus || 'All Clinical Departments',
        phone: newPhone || '1800-419-BIOSIS',
        email: newEmail || `sales@${newDomain.toLowerCase().trim()}`,
        city: newCity || 'New Delhi, India',
        themeMode: newThemeMode,
        whatsapp: newWhatsapp.trim(),
        heroTitle: newHeroTitle.trim(),
        announcement: newAnnouncement.trim(),
        logo: newLogo || '',
        bannerImage: newBannerImage || '',
        categories: newExtractedCategories || undefined,
        customProducts: newExtractedProducts || undefined,
        status: 'Live',
        leadsCount: 0,
        layoutBlocks: (newExtractedBlocks && newExtractedBlocks.length > 0) ? newExtractedBlocks : defaultBlocks
      };
      setSites([newSiteObj, ...sites]);
      try {
        await fetch('/api/sites', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newSiteObj)
        });
      } catch (err) {
        console.warn('MongoDB sync:', err);
      }
      setIsAddSiteOpen(false);
      resetForm();

      if (openInBuilder) {
        setBuilderSite(newSiteObj);
        setIsBuilderOpen(true);
      }
    }
  };

  const filteredSites = sites.filter(s => {
    if (selectedCompanyFilter !== 'all' && (s.companyId || 'rajbiosis') !== selectedCompanyFilter) {
      return false;
    }
    if (siteSearch.trim()) {
      const q = siteSearch.toLowerCase();
      return (
        s.domain?.toLowerCase().includes(q) ||
        s.brandName?.toLowerCase().includes(q) ||
        s.city?.toLowerCase().includes(q) ||
        s.tagline?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const filteredLeads = leads.filter(l => {
    if (selectedCompanyFilter !== 'all') {
      const leadSite = sites.find(s => s.domain === l.siteDomain);
      if (leadSite && (leadSite.companyId || 'rajbiosis') !== selectedCompanyFilter) return false;
    }
    if (leadFilterDomain !== 'all') {
      return l.siteDomain === leadFilterDomain;
    }
    return true;
  });

  const totalPipelineVal = filteredLeads.reduce((acc, l) => {
    const num = parseInt((l.amount || l.quoteAmount || '0').replace(/[^0-9]/g, '')) || 0;
    return acc + num;
  }, 0);
  const formattedPipeline = totalPipelineVal > 0 
    ? `₹${(totalPipelineVal >= 10000000 ? (totalPipelineVal / 10000000).toFixed(2) + ' Cr' : (totalPipelineVal / 100000).toFixed(2) + ' L')}` 
    : '₹0.00';

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50/60 text-slate-700 font-sans">
      
      {/* Left Sidebar (Sticky & Fixed) */}
      <aside className="w-64 bg-white border-r border-slate-100 flex flex-col justify-between shrink-0 hidden md:flex shadow-xs h-screen sticky top-0 overflow-y-auto">
        <div>
          {/* Admin Header with Multi-Brand Overview */}
          <div className="p-4 border-b border-slate-100 flex items-center gap-3 bg-white">
            <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200/90 p-1 flex items-center justify-center shadow-xs shrink-0 overflow-hidden hover:border-sky-300 transition">
              <img src="/rajbiosis-logo.png" alt="Raj Biosis Private Limited" className="w-full h-full object-contain" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold tracking-tight text-slate-800 truncate flex items-center gap-1">
                <span className="truncate">Multi-Brand Hub</span>
                <span className="text-[9px] bg-sky-50 text-sky-700 font-mono px-1.5 py-0.2 rounded border border-sky-200/80 font-bold shrink-0">B2B</span>
              </div>
              <div className="text-[10px] text-slate-400 truncate">Raj Biosis • Human • Global</div>
            </div>
          </div>

          {/* PARENT BRANDS & COMPANIES (3 Parent Companies Selector) */}
          <div className="p-3 border-b border-slate-100 bg-slate-50/50">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 mb-2 flex items-center justify-between">
              <span>Parent Brands</span>
              <span className="font-mono text-sky-600 font-semibold">3 Companies</span>
            </div>
            <div className="space-y-1">
              {/* All Companies */}
              <button
                type="button"
                onClick={() => { setSelectedCompanyFilter('all'); setActiveTab('sites'); }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                  selectedCompanyFilter === 'all' && activeTab === 'sites'
                    ? 'bg-sky-50 text-sky-900 border border-sky-300 shadow-xs ring-1 ring-sky-200 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                <span className="flex items-center gap-2">
                  <Globe size={14} className={selectedCompanyFilter === 'all' && activeTab === 'sites' ? 'text-sky-600' : 'text-slate-400'} />
                  <span>All Companies</span>
                </span>
                <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                  selectedCompanyFilter === 'all' && activeTab === 'sites' ? 'bg-sky-200 text-sky-900 font-bold' : 'bg-slate-200/60 text-slate-500'
                }`}>
                  {sites.length}
                </span>
              </button>

              {/* Raj Biosis */}
              <button
                type="button"
                onClick={() => { setSelectedCompanyFilter('rajbiosis'); setActiveTab('sites'); }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                  selectedCompanyFilter === 'rajbiosis' && activeTab === 'sites'
                    ? 'bg-sky-50 text-sky-800 border border-sky-300 shadow-xs ring-1 ring-sky-200 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                <span className="flex items-center gap-2 min-w-0">
                  <span className="w-2.5 h-2.5 rounded-full bg-sky-500 shrink-0"></span>
                  <span className="truncate">Raj Biosis</span>
                </span>
                <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                  selectedCompanyFilter === 'rajbiosis' && activeTab === 'sites' ? 'bg-sky-200 text-sky-800 font-bold' : 'bg-slate-200/60 text-slate-500'
                }`}>
                  {sites.filter(s => (s.companyId || 'rajbiosis') === 'rajbiosis').length}
                </span>
              </button>

              {/* Human Biomedicals */}
              <button
                type="button"
                onClick={() => { setSelectedCompanyFilter('human_bio'); setActiveTab('sites'); }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                  selectedCompanyFilter === 'human_bio' && activeTab === 'sites'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 shadow-xs ring-1 ring-emerald-200 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                <span className="flex items-center gap-2 min-w-0">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></span>
                  <span className="truncate">Human Biomedicals</span>
                </span>
                <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                  selectedCompanyFilter === 'human_bio' && activeTab === 'sites' ? 'bg-emerald-200 text-emerald-800 font-bold' : 'bg-slate-200/60 text-slate-500'
                }`}>
                  {sites.filter(s => s.companyId === 'human_bio').length}
                </span>
              </button>

              {/* Global Biomedical */}
              <button
                type="button"
                onClick={() => { setSelectedCompanyFilter('global_bio'); setActiveTab('sites'); }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                  selectedCompanyFilter === 'global_bio' && activeTab === 'sites'
                    ? 'bg-indigo-50 text-indigo-800 border border-indigo-300 shadow-xs ring-1 ring-indigo-200 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                <span className="flex items-center gap-2 min-w-0">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 shrink-0"></span>
                  <span className="truncate">Global Biomedical</span>
                </span>
                <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                  selectedCompanyFilter === 'global_bio' && activeTab === 'sites' ? 'bg-indigo-200 text-indigo-800 font-bold' : 'bg-slate-200/60 text-slate-500'
                }`}>
                  {sites.filter(s => s.companyId === 'global_bio').length}
                </span>
              </button>
            </div>
          </div>

          {/* Nav Items */}
          <nav className="p-3 space-y-1 text-xs font-semibold">

            <button
              onClick={() => setActiveTab('leads')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition cursor-pointer ${
                activeTab === 'leads' 
                  ? 'bg-sky-50 text-sky-700 font-semibold border border-sky-200/80 shadow-xs' 
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 font-medium'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Inbox size={16} />
                <span>Central Leads & RFQ</span>
              </span>
              <span className="text-[10px] bg-sky-500 text-white font-bold px-1.5 py-0.5 rounded-full">
                {leads.length}
              </span>
            </button>


            <button
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition cursor-pointer ${
                activeTab === 'products' 
                  ? 'bg-sky-50 text-sky-700 font-semibold border border-sky-200/80 shadow-xs' 
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 font-medium'
              }`}
            >
              <Package size={16} />
              <span>Global Catalog ({PRODUCTS.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('vps')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition cursor-pointer ${
                activeTab === 'vps' 
                  ? 'bg-sky-50 text-sky-700 font-semibold border border-sky-200/80 shadow-xs' 
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 font-medium'
              }`}
            >
              <Server size={16} />
              <span>VPS & MongoDB Config</span>
            </button>
          </nav>
        </div>

        {/* Bottom User / Return */}
        <div className="p-4 border-t border-slate-100 space-y-3">
          <Link
            href="/"
            target="_blank"
            className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-800 text-xs font-semibold rounded-xl transition border border-slate-200/80 shadow-xs"
          >
            <span>View Public Storefront</span>
            <ExternalLink size={13} />
          </Link>

          <button
            type="button"
            onClick={() => setActiveTab('vps')}
            className="w-full flex items-center justify-between text-[11px] p-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200/60 transition cursor-pointer text-left shadow-2xs"
          >
            <span className="font-mono text-slate-500 flex items-center gap-1.5">
              <Database size={12} className={dbStatus.connected ? "text-emerald-500" : "text-amber-500"} />
              <span>MongoDB</span>
            </span>
            {dbStatus.connected ? (
              <span className="text-emerald-600 flex items-center gap-1.5 font-semibold text-[10px]">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Connected ({dbStatus.latency || 'Live'})
              </span>
            ) : (
              <span className="text-amber-600 flex items-center gap-1.5 font-medium text-[10px]">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                Standby Mode
              </span>
            )}
          </button>
        </div>
      </aside>

      {/* Main Workspace Area (Scrollable with Sticky Sidebar) */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
        
        {/* Top Navbar */}
        <header className="h-16 bg-white/95 backdrop-blur-md border-b border-slate-100 px-6 flex items-center justify-between sticky top-0 z-30 shrink-0">
          <div className="flex items-center gap-3">
            <h1 className="text-base font-bold text-slate-800 flex items-center gap-2">
              {activeTab === 'sites' && (
                <>
                  <span>
                    {selectedCompanyFilter === 'all' 
                      ? 'Multi-Brand Websites Network Registry' 
                      : `${SENDER_COMPANIES.find(c => c.id === selectedCompanyFilter)?.name} Registry`}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-md font-mono bg-slate-100 text-slate-600 border border-slate-200">
                    {filteredSites.length} Platforms
                  </span>
                </>
              )}
              {activeTab === 'leads' && 'Central Hospital Inquiries & Quotation Desk'}
              {activeTab === 'marketing' && 'Multi-Brand Email Marketing Hub (Raj Biosis, Human & Global Bio)'}
              {activeTab === 'products' && 'Global Biomedical Inventory & Distribution'}
              {activeTab === 'vps' && 'VPS Deployment & MongoDB Pipeline'}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            {activeTab === 'sites' && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsBulkUpdateOpen(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold rounded-xl border border-amber-200 transition cursor-pointer shadow-2xs"
                  title="Mass Sync: Update phone, email, address, WhatsApp across multiple websites in MongoDB"
                >
                  <Zap size={14} className="text-amber-600" />
                  <span>Mass Sync / Bulk Update</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsDashboardImporterOpen(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-xl border border-indigo-200 transition cursor-pointer shadow-2xs"
                  title="Import or clone theme colors, brand, and layout from any live website URL or local HTML template"
                >
                  <Sparkles size={14} className="text-indigo-600" />
                  <span>Import / Clone Website</span>
                </button>
                <button
                  type="button"
                  onClick={openCreateSite}
                  className="flex items-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white text-xs font-semibold rounded-xl transition shadow-sm shadow-sky-500/20 cursor-pointer"
                >
                  <Plus size={15} />
                  <span>Launch New Website</span>
                </button>
              </div>
            )}

            {activeTab === 'marketing' && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setMarketingSubTab('compose')}
                  className={`text-xs px-3.5 py-1.5 rounded-xl font-semibold transition cursor-pointer ${
                    marketingSubTab === 'compose'
                      ? 'bg-sky-500 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
                  }`}
                >
                  ✍️ Compose Campaign
                </button>
                <button
                  onClick={() => setMarketingSubTab('history')}
                  className={`text-xs px-3.5 py-1.5 rounded-xl font-semibold transition flex items-center gap-1.5 cursor-pointer ${
                    marketingSubTab === 'history'
                      ? 'bg-sky-500 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
                  }`}
                >
                  <History size={13} />
                  <span>Delivery Logs ({campaignHistory.length})</span>
                </button>
              </div>
            )}

            {/* Live MongoDB Status Pill in Header */}
            <button
              type="button"
              onClick={() => setActiveTab('vps')}
              className={`text-xs px-3 py-1.5 rounded-xl border font-mono transition flex items-center gap-2 cursor-pointer shadow-2xs ${
                dbStatus.connected 
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200/80 hover:bg-emerald-100/70' 
                  : 'bg-amber-50 text-amber-700 border-amber-200/80 hover:bg-amber-100/70'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${dbStatus.connected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'}`}></span>
              <span className="font-semibold">{dbStatus.connected ? `MongoDB: Live (${dbStatus.latency || 'OK'})` : 'MongoDB: Standby'}</span>
            </button>

            <div className="text-xs text-slate-500 font-mono bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200/80">
              Host: <span className="text-slate-700 font-semibold">rajbiosis.com</span>
            </div>
          </div>
        </header>

        {/* Dashboard Content Body */}
        <main className="p-6 space-y-6">

          {/* Quick Metrics Bar (Dynamic for Marketing or Sites) */}
          {activeTab === 'marketing' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-sm transition flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Sender Brands</span>
                  <span className="text-2xl font-bold text-slate-800">3 OEM Divisions</span>
                  <span className="text-[11px] text-sky-600 font-medium block mt-0.5">Raj Biosis, Human & Global</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-500 flex items-center justify-center font-bold">
                  <Building2 size={20} />
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-sm transition flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Hospital Reach</span>
                  <span className="text-2xl font-bold text-slate-800">2,840 <span className="text-xs font-semibold text-emerald-600">Verified</span></span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">Doctors & Procurement Heads</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-500 flex items-center justify-center font-bold">
                  <Users size={20} />
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-sm transition flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">RFQ Follow-Ups</span>
                  <span className="text-2xl font-bold text-slate-800">42 <span className="text-xs font-semibold text-amber-600">Hot Deals</span></span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">Quotes Pending Approval</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center font-bold">
                  <Target size={20} />
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-sm transition flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Avg. Open Rate</span>
                  <span className="text-2xl font-bold text-slate-800">68.4%</span>
                  <span className="text-[11px] text-indigo-600 font-medium block mt-0.5">+14% vs B2B Healthcare</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-500 flex items-center justify-center font-bold">
                  <CheckCheck size={20} />
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-sm transition flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Active Platforms</span>
                  <span className="text-2xl font-bold text-slate-800">{filteredSites.length} <span className="text-xs font-semibold text-sky-600 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-100">Unlimited Scale</span></span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    {selectedCompanyFilter === 'all' ? '3 Parent Brands Network' : SENDER_COMPANIES.find(c => c.id === selectedCompanyFilter)?.shortName}
                  </span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-500 flex items-center justify-center font-bold">
                  <Globe size={20} />
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-sm transition flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Hospital RFQs & Leads</span>
                  <span className="text-2xl font-bold text-slate-800">{filteredLeads.length} <span className="text-xs font-semibold text-emerald-600">{filteredLeads.length > 0 ? 'Live Inquiries' : 'No Inquiries Yet'}</span></span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">Direct MongoDB RFQ Inquiries</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-500 flex items-center justify-center font-bold">
                  <Inbox size={20} />
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-sm transition flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Quotation Pipeline</span>
                  <span className="text-2xl font-bold text-slate-800">{formattedPipeline}</span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">{filteredLeads.length} Active Quotes In Pipeline</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center font-bold">
                  <FileText size={20} />
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs hover:shadow-sm transition flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Certified Hardware</span>
                  <span className="text-2xl font-bold text-slate-800">{PRODUCTS.length} Models</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-500 flex items-center justify-center font-bold">
                  <Package size={20} />
                </div>
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 1: 70 WEBSITES MANAGER TABLE
              ========================================================================= */}
          {activeTab === 'sites' && (
            <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden">
              {/* Search & Actions Bar */}
              <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="relative max-w-sm w-full">
                  <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={siteSearch}
                    onChange={(e) => setSiteSearch(e.target.value)}
                    placeholder="Search by domain, brand or layout..."
                    className="w-full pl-9 pr-4 py-2 bg-slate-50/80 text-xs rounded-xl border border-slate-200/80 text-slate-700 outline-none focus:bg-white focus:border-sky-400 transition placeholder-slate-400"
                  />
                </div>

                <div className="text-xs text-slate-400 font-medium">
                  Showing <span className="text-slate-700 font-semibold">{filteredSites.length}</span> configured biomedical platforms
                </div>
              </div>

              {/* Websites Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 text-slate-400 font-semibold uppercase tracking-wider text-[10px] bg-slate-50/50">
                      <th className="py-3 px-4">Domain & Brand</th>
                      <th className="py-3 px-4">Color & Font Theme</th>
                      <th className="py-3 px-4">Homepage Layout Style</th>
                      <th className="py-3 px-4">Card Style</th>
                      <th className="py-3 px-4">Contact Desk</th>
                      <th className="py-3 px-4">Leads</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100/70 font-medium text-slate-600">
                    {filteredSites.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-14 text-center">
                          <div className="max-w-sm mx-auto space-y-2">
                            <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                              <Globe size={22} />
                            </div>
                            <h4 className="text-sm font-bold text-slate-700">
                              {isSitesLoading ? 'Loading Platforms from MongoDB...' : 'No Websites Found'}
                            </h4>
                            <p className="text-xs text-slate-400">
                              {isSitesLoading 
                                ? 'Connecting to cluster and fetching multi-tenant configurations...' 
                                : siteSearch 
                                ? `No websites match search query "${siteSearch}".` 
                                : 'All websites have been removed or none configured yet. Click "+ Launch New Website" to add one.'}
                            </p>
                            {!isSitesLoading && !siteSearch && (
                              <div className="flex items-center justify-center gap-2 pt-2 flex-wrap">
                                <button
                                  onClick={openCreateSite}
                                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-sky-500 text-white text-xs font-semibold shadow-xs hover:bg-sky-600 transition cursor-pointer"
                                >
                                  <Plus size={14} />
                                  <span>Launch Website Now</span>
                                </button>
                                <button
                                  onClick={handleReseedMongo}
                                  disabled={isSeedingMongo}
                                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition cursor-pointer border border-slate-200 disabled:opacity-50"
                                >
                                  <Sparkles size={14} className={isSeedingMongo ? "animate-spin text-amber-500" : "text-amber-500"} />
                                  <span>{isSeedingMongo ? 'Seeding MongoDB...' : '⚡ Load Starter Websites (3 Brands)'}</span>
                                </button>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    ) : (
                      filteredSites.map((site) => (
                        <tr key={site.id || site._id || site.domain} className="hover:bg-sky-50/30 transition">
                        {/* Domain & Brand */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase tracking-wider border ${
                              (site.companyId || 'rajbiosis') === 'rajbiosis'
                                ? 'bg-sky-50 text-sky-700 border-sky-200'
                                : site.companyId === 'human_bio'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : 'bg-indigo-50 text-indigo-700 border-indigo-200'
                            }`}>
                              {(site.companyId || 'rajbiosis') === 'rajbiosis' ? 'Raj Biosis' : site.companyId === 'human_bio' ? 'Human Bio' : 'Global Bio'}
                            </span>
                            <span className="text-[10px] font-mono text-slate-400 font-normal">({site.domain})</span>
                          </div>
                          <div className="font-semibold text-slate-800 text-sm">
                            {site.brandName}
                          </div>
                          <span className="text-[11px] text-slate-400 truncate block max-w-[180px]">
                            {site.tagline}
                          </span>
                        </td>

                        {/* Theme & Color Swatch */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-4 h-4 rounded-full border border-slate-200 shrink-0 shadow-xs ring-2 ring-slate-100"
                              style={{ backgroundColor: site.primaryColor }}
                              title={site.primaryColor}
                            />
                            <div>
                              <span className="text-xs font-mono font-medium text-slate-700 block">{site.primaryColor}</span>
                              <span className="text-[10px] text-slate-400">{site.font}</span>
                            </div>
                          </div>
                        </td>

                        {/* Layout */}
                        <td className="py-3.5 px-4">
                          <span className="inline-block px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200/60 text-slate-700 text-[11px] font-medium">
                            {site.homepageLayout}
                          </span>
                          <span className="text-[10px] text-slate-400 block mt-0.5 font-mono">{site.headerStyle}</span>
                        </td>

                        {/* Card Style */}
                        <td className="py-3.5 px-4">
                          <span className="text-xs text-slate-600 font-mono">{site.cardStyle}</span>
                          <span className="text-[10px] text-slate-400 block">{site.categoryFocus}</span>
                        </td>

                        {/* Contact */}
                        <td className="py-3.5 px-4">
                          <div className="text-xs text-slate-700 font-mono font-medium">{site.phone}</div>
                          <span className="text-[10px] text-slate-400 truncate block">{site.city}</span>
                        </td>

                        {/* Leads Generated */}
                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-sky-700 bg-sky-50 border border-sky-100 px-2 py-0.5 rounded-md text-xs font-mono">
                            {site.leadsCount || 0} RFQs
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setBuilderSite(site);
                                setIsBuilderOpen(true);
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 font-bold text-[11px] flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
                              title="Open WordPress / Elementor Visual Page Builder"
                            >
                              <Sparkles size={13} className="text-amber-500" />
                              <span>Visual Builder</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => openEditSite(site)}
                              className="p-1.5 hover:bg-sky-50 text-slate-400 hover:text-sky-600 rounded-lg transition cursor-pointer"
                              title="Edit Website Config (Colors, Fonts, Layout)"
                            >
                              <Edit3 size={14} />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteSite(site)}
                              className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-500 rounded-lg transition cursor-pointer"
                              title="Delete Website"
                            >
                              <Trash2 size={14} />
                            </button>
                            <button
                              type="button"
                              onClick={() => setPreviewingSite(site)}
                              className="p-1.5 hover:bg-sky-50 text-sky-600 rounded-lg transition cursor-pointer"
                              title="Open Live Website Sandbox Preview"
                            >
                              <Eye size={14} />
                            </button>
                            <Link
                              href={`/preview/${site.domain}`}
                              target="_blank"
                              className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-700 rounded-lg transition"
                              title="Open Full Storefront in New Tab"
                            >
                              <ExternalLink size={13} />
                            </Link>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 2: CENTRAL LEADS & RFQ INQUIRIES DESK
              ========================================================================= */}
          {activeTab === 'leads' && (
            <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden space-y-4">
              {/* Filter Bar */}
              <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <label className="text-xs font-semibold text-slate-500">Filter by Website:</label>
                  <select
                    value={leadFilterDomain}
                    onChange={(e) => setLeadFilterDomain(e.target.value)}
                    className="bg-slate-50/80 border border-slate-200/80 rounded-xl px-3 py-1.5 text-xs text-slate-700 font-mono outline-none focus:bg-white focus:border-sky-400"
                  >
                    <option value="all">All 70 Websites ({leads.length})</option>
                    {sites.map(s => (
                      <option key={s.id} value={s.domain}>{s.brandName} ({s.domain})</option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={() => alert("Exporting all hospital leads to CSV / Excel...")}
                  className="text-xs py-1.5 px-3 bg-white border border-slate-200/80 text-slate-600 hover:bg-slate-50 rounded-xl font-medium flex items-center gap-1.5 transition shadow-xs"
                >
                  <Download size={13} />
                  <span>Export to Excel / CSV</span>
                </button>
              </div>

              {/* Leads Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 text-slate-400 font-semibold uppercase tracking-wider text-[10px] bg-slate-50/50">
                      <th className="py-3 px-4">Ref & Date</th>
                      <th className="py-3 px-4">Source Website</th>
                      <th className="py-3 px-4">Hospital & Doctor</th>
                      <th className="py-3 px-4">Requested Hardware</th>
                      <th className="py-3 px-4">Quotation Value</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100/70 font-medium text-slate-600">
                    {filteredLeads.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center">
                          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
                            <Inbox size={22} />
                          </div>
                          <h4 className="text-sm font-bold text-slate-700">No Hospital Quotation Inquiries Yet</h4>
                          <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                            When doctors, hospital purchase officers, or clinic heads request quotes on any connected website, inquiries will be registered here directly in MongoDB.
                          </p>
                        </td>
                      </tr>
                    ) : (
                      filteredLeads.map((lead) => (
                      <tr key={lead.id} className="hover:bg-sky-50/30 transition">
                        <td className="py-3 px-4">
                          <span className="font-mono font-semibold text-slate-700 block">{lead.id}</span>
                          <span className="text-[10px] text-slate-400">{lead.date}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded bg-sky-50 text-sky-700 border border-sky-100 font-mono text-[11px] font-medium">
                            {lead.siteDomain}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-800 text-xs">{lead.hospital}</div>
                          <span className="text-[11px] text-slate-500 block">{lead.contact}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{lead.phone}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-slate-700 font-medium">{lead.equipment}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-emerald-600 font-bold text-sm font-mono">{lead.amount}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-amber-50 text-amber-700 border border-amber-200/70">
                            {lead.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <a
                            href={`tel:${lead.phone}`}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold transition shadow-xs"
                          >
                            <PhoneCall size={12} />
                            <span>Call</span>
                          </a>
                        </td>
                      </tr>
                    ))
                  )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 3: GLOBAL CATALOG MANAGER
              ========================================================================= */}
          {activeTab === 'products' && (
            <div className="bg-white rounded-3xl border border-slate-100 shadow-xs p-6 space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <h3 className="text-base font-bold text-slate-800">Central Medical Inventory Pool</h3>
                  <p className="text-xs text-slate-400">All 18 certified devices available for distribution across all 70 websites.</p>
                </div>
                <span className="px-3 py-1 rounded-xl bg-emerald-50 text-xs font-mono text-emerald-700 font-semibold border border-emerald-100">
                  {PRODUCTS.length} Devices Synced
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {PRODUCTS.map(p => (
                  <div key={p.id} className="bg-slate-50/50 hover:bg-white p-4 rounded-2xl border border-slate-100 hover:border-sky-200 hover:shadow-xs transition flex items-center gap-3">
                    <img src={p.image} alt={p.name} className="w-14 h-14 object-contain rounded-xl bg-white p-1.5 border border-slate-100 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-slate-800 truncate">{p.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">SKU: {p.sku}</div>
                      <div className="text-xs font-bold text-sky-600 mt-1">₹{(p.price).toLocaleString('en-IN')}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 4: LIVE MONGODB CONNECTION STUDIO & MULTI-DOMAIN PIPELINE
              ========================================================================= */}
          {activeTab === 'vps' && (
            <div className="space-y-6">

              {/* Top MongoDB Cluster Status Banner */}
              <div className={`p-6 rounded-3xl border shadow-xs transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                dbStatus.connected 
                  ? 'bg-emerald-50/70 border-emerald-200/80 text-emerald-950' 
                  : 'bg-amber-50/70 border-amber-200/80 text-amber-950'
              }`}>
                <div className="flex items-start sm:items-center gap-3.5">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-white shadow-xs shrink-0 ${
                    dbStatus.connected ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}>
                    <Database size={24} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-slate-800">
                        {dbStatus.connected ? 'MongoDB Cluster Connected & Active' : 'MongoDB Standby Mode (In-Memory Fallback Active)'}
                      </h3>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                        dbStatus.connected ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}>
                        {dbStatus.connected ? 'LIVE POOL' : 'STANDBY CACHE'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {dbStatus.connected 
                        ? `All 70 websites, hospital quotations, and marketing campaigns are continuously synchronizing with '${dbStatus.database}'. Latency: ${dbStatus.latency}.`
                        : 'Currently serving and saving data in memory with zero downtime. Connect your MongoDB Atlas cluster or local MongoDB instance below to activate persistent storage.'
                      }
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <button
                    type="button"
                    onClick={checkDbStatus}
                    className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw size={13} className={dbStatus.checking ? "animate-spin" : ""} />
                    <span>Check Connection</span>
                  </button>
                </div>
              </div>

              {/* MongoDB Cluster Metric Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Database Name</span>
                  <span className="text-lg font-bold font-mono text-slate-800 truncate block mt-0.5">{dbStatus.database || 'biomedical_network'}</span>
                  <span className="text-[11px] text-emerald-600 font-medium block mt-1">Multi-Tenant Namespace</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Sites Collection</span>
                  <span className="text-2xl font-bold text-slate-800">{sites.length} <span className="text-xs font-semibold text-sky-600">Websites</span></span>
                  <span className="text-[11px] text-slate-400 block mt-1">Config & Domain Registry</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Leads Collection</span>
                  <span className="text-2xl font-bold text-slate-800">{leads.length} <span className="text-xs font-semibold text-emerald-600">Inquiries</span></span>
                  <span className="text-[11px] text-slate-400 block mt-1">Hospital Quotes & RFQs</span>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block">Campaigns Collection</span>
                  <span className="text-2xl font-bold text-slate-800">{campaignHistory.length} <span className="text-xs font-semibold text-indigo-600">Broadcasts</span></span>
                  <span className="text-[11px] text-slate-400 block mt-1">Delivery & Telemetry Logs</span>
                </div>
              </div>

              {/* Interactive MongoDB Connection Configuration Studio */}
              <div className="bg-white rounded-3xl border border-slate-100 shadow-xs p-6 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                  <div>
                    <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                      <Key size={16} className="text-sky-500" />
                      <span>MongoDB Connection URI & Credentials</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Connect your production MongoDB Atlas cluster or VPS MongoDB instance. Enter your URI and test the connection in real time.
                    </p>
                  </div>

                  {/* Quick Preset Buttons */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[11px] text-slate-400 font-medium">Quick Presets:</span>
                    <button
                      type="button"
                      onClick={() => setMongoUriInput('mongodb+srv://admin:pass@vps-cluster.mongodb.net/biomedical_network')}
                      className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100/80 text-sky-700 text-[11px] font-semibold transition cursor-pointer border border-sky-200/60"
                    >
                      ☁️ Atlas Cloud
                    </button>
                    <button
                      type="button"
                      onClick={() => setMongoUriInput('mongodb://127.0.0.1:27017/biomedical_network')}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold transition cursor-pointer"
                    >
                      💻 Localhost
                    </button>
                    <button
                      type="button"
                      onClick={() => setMongoUriInput('mongodb://127.0.0.1:27017/biomedical_network')}
                      className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100/80 text-emerald-700 text-[11px] font-semibold transition cursor-pointer border border-emerald-200/60"
                    >
                      🖥️ VPS Port 27017
                    </button>
                  </div>
                </div>

                {/* URI Input & Buttons */}
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      MongoDB Connection URI (mongodb:// or mongodb+srv://)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={mongoUriInput}
                        onChange={(e) => setMongoUriInput(e.target.value)}
                        placeholder="mongodb+srv://<username>:<password>@cluster0.mongodb.net/biomedical_network"
                        className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-800 outline-none focus:bg-white focus:border-sky-400 transition"
                      />
                    </div>
                    <span className="text-[11px] text-slate-400 mt-1 block">
                      💡 Tip for Atlas: Ensure your IP address is whitelisted in MongoDB Atlas Network Access (or set to 0.0.0.0/0 for anywhere).
                    </span>
                  </div>

                  {/* Actions Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={isTestingMongo}
                        onClick={handleTestMongoUri}
                        className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 shadow-2xs"
                      >
                        {isTestingMongo ? (
                          <>
                            <RefreshCw size={13} className="animate-spin text-sky-500" />
                            <span>Testing Ping...</span>
                          </>
                        ) : (
                          <>
                            <Wifi size={13} className="text-sky-500" />
                            <span>Test Live Connection</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        disabled={isSavingMongo}
                        onClick={handleSaveMongoUri}
                        className="px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-sm shadow-sky-500/25"
                      >
                        {isSavingMongo ? (
                          <>
                            <RefreshCw size={13} className="animate-spin" />
                            <span>Saving to .env.local...</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 size={13} />
                            <span>Save to .env.local & Connect</span>
                          </>
                        )}
                      </button>
                    </div>

                    <button
                      type="button"
                      disabled={isSeedingMongo}
                      onClick={handleReseedMongo}
                      className="px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 text-xs font-semibold transition cursor-pointer border border-slate-200/80 flex items-center gap-1.5 self-start sm:self-auto"
                    >
                      <RefreshCw size={12} className={isSeedingMongo ? "animate-spin text-sky-500" : ""} />
                      <span>Re-Sync All Collections</span>
                    </button>
                  </div>

                  {/* Real-Time Test Feedback Banner */}
                  {mongoTestResult && (
                    <div className={`p-4 rounded-2xl border text-xs shadow-xs transition ${
                      mongoTestResult.connected 
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
                        : 'bg-rose-50 border-rose-200 text-rose-900'
                    }`}>
                      <div className="flex items-center gap-2 font-bold mb-1">
                        {mongoTestResult.connected ? (
                          <>
                            <CheckCircle2 size={16} className="text-emerald-600" />
                            <span>MongoDB Connection Test Passed!</span>
                          </>
                        ) : (
                          <>
                            <AlertCircle size={16} className="text-rose-600" />
                            <span>MongoDB Connection Failed</span>
                          </>
                        )}
                      </div>
                      <div className="text-[11px] font-mono leading-relaxed pl-6">
                        {mongoTestResult.connected ? (
                          <>
                            <div>Status: Ping OK | Latency: <strong>{mongoTestResult.latency}</strong> | Database: <strong>{mongoTestResult.database}</strong></div>
                            <div>Collections Found: {mongoTestResult.collections?.join(', ') || 'sites, leads, campaigns'}</div>
                          </>
                        ) : (
                          <>
                            <div>Error: {mongoTestResult.error}</div>
                            <div className="text-rose-700/80 mt-1 font-sans">
                              Check that: 1) MongoDB server is running, 2) IP whitelist is open in Atlas, 3) Username & Password are correct.
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Database Collections & Data Architecture Explorer */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-lg border border-sky-100">
                      db.collection('sites')
                    </span>
                    <span className="text-xs font-bold font-mono text-slate-800">{sites.length} Docs</span>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Stores the multi-tenant registry for all 70 biomedical websites. Each document defines domain routing, theme colors, typography fonts, header styles, and company ownership.
                  </p>
                  <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-1 text-[10px] font-mono text-slate-500">
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">domain</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">brandName</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">primaryColor</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">font</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">headerStyle</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">leadsCount</span>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100">
                      db.collection('leads')
                    </span>
                    <span className="text-xs font-bold font-mono text-slate-800">{leads.length} Docs</span>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Captures all incoming hospital quotations, doctor inquiries, and equipment RFQ orders routed from the 70 public storefronts directly to central sales administration.
                  </p>
                  <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-1 text-[10px] font-mono text-slate-500">
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">doctorName</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">hospital</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">equipment</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">quoteAmount</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">siteDomain</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">status</span>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                      db.collection('campaigns')
                    </span>
                    <span className="text-xs font-bold font-mono text-slate-800">{campaignHistory.length} Docs</span>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Stores multi-brand email marketing broadcasts across Raj Biosis, Human Biomedicals, and Global Biomedical, including recipient lists, open rates, and dispatch timestamps.
                  </p>
                  <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-1 text-[10px] font-mono text-slate-500">
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">id</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">company</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">subject</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">audience</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">openRate</span>
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded">status</span>
                  </div>
                </div>
              </div>

              {/* Nginx Wildcard Multi-Domain Reverse Proxy Guide */}
              <div className="bg-white rounded-3xl border border-slate-100 shadow-xs p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Server size={16} className="text-sky-500" />
                    <h4 className="text-sm font-bold text-slate-800">VPS Nginx Wildcard Reverse Proxy Configuration</h4>
                  </div>
                  <span className="text-[11px] font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded">/etc/nginx/sites-available/biomedical</span>
                </div>
                <p className="text-xs text-slate-400">
                  Deploy this configuration on your Ubuntu/Linux VPS to route all 70 domains to Next.js automatically without redeploying code.
                </p>
                <div className="bg-slate-50 p-4 rounded-2xl font-mono text-xs text-slate-700 border border-slate-200/80 overflow-x-auto space-y-1">
                  <p className="text-slate-400"># Route all 70 domains & wildcard subdomains to Next.js port 3000/3001</p>
                  <p className="text-sky-700 font-semibold">server &#123;</p>
                  <p className="pl-4">listen 80;</p>
                  <p className="pl-4">server_name *.rajbiosis.com pulmocare.in surgitech.in cardiopulse.in nephrolife.in orthodrive.in laparovision.com;</p>
                  <p className="pl-4 text-emerald-700">location / &#123;</p>
                  <p className="pl-8">proxy_pass http://127.0.0.1:3000;</p>
                  <p className="pl-8">proxy_set_header Host $host;</p>
                  <p className="pl-8">proxy_set_header X-Real-IP $remote_addr;</p>
                  <p className="pl-8">proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;</p>
                  <p className="pl-4 text-emerald-700">&#125;</p>
                  <p className="text-sky-700 font-semibold">&#125;</p>
                </div>
              </div>

            </div>
          )}

          {/* =========================================================================
              TAB 5: MULTI-BRAND EMAIL MARKETING HUB (RAJ BIOSIS, HUMAN & GLOBAL)
              ========================================================================= */}
          {activeTab === 'marketing' && (
            <div className="space-y-6">

              {/* Notification Banner */}
              {sendSuccessMsg && (
                <div className="p-4 bg-emerald-50 border border-emerald-200/80 rounded-2xl flex items-center justify-between text-xs text-emerald-800 shadow-sm transition">
                  <div className="flex items-center gap-2.5 font-semibold">
                    <CheckCircle2 size={18} className="text-emerald-600 shrink-0" />
                    <span>{sendSuccessMsg}</span>
                  </div>
                  <button onClick={() => setSendSuccessMsg(null)} className="text-emerald-600 hover:text-emerald-800 cursor-pointer">
                    <X size={15} />
                  </button>
                </div>
              )}

              {/* SUBTAB 1: COMPOSE & BROADCAST CAMPAIGN (CLEAN & SIMPLE 3-STEP LAYOUT) */}
              {marketingSubTab === 'compose' && (
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">

                  {/* LEFT COLUMN: 3 EASY STEPS (7 Cols) */}
                  <div className="xl:col-span-7 space-y-5">

                    {/* Quick Guidance Header */}
                    <div className="bg-sky-50/70 border border-sky-200/70 rounded-2xl p-4 flex items-center justify-between text-xs text-sky-900 shadow-xs">
                      <div className="flex items-center gap-2.5">
                        <span className="w-8 h-8 rounded-xl bg-sky-500 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                          ✉️
                        </span>
                        <div>
                          <div className="font-bold text-slate-800">Email Marketing & Hospital Follow-Up Desk</div>
                          <div className="text-[11px] text-sky-700">Easily broadcast hospital quotations, follow-ups, and network announcements in 3 simple steps.</div>
                        </div>
                      </div>
                      <span className="hidden sm:inline-block px-3 py-1 bg-white text-sky-700 font-semibold rounded-xl border border-sky-200 text-[11px] shadow-xs">
                        Total Reach: {getRecipientCount()}
                      </span>
                    </div>

                    {/* STEP 1: SENDER BRAND SELECTION */}
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-lg bg-sky-500 text-white font-bold text-xs flex items-center justify-center">1</span>
                          <h3 className="text-sm font-bold text-slate-800">Step 1: Select Sender Brand (From Which Company to Send)</h3>
                        </div>
                        <span className="text-[11px] text-slate-400 font-medium">3 Registered Brands</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {SENDER_COMPANIES.map((company) => {
                          const isSelected = selectedCompanyId === company.id;
                          return (
                            <button
                              key={company.id}
                              type="button"
                              onClick={() => setSelectedCompanyId(company.id)}
                              className={`p-3.5 rounded-xl border transition text-left cursor-pointer flex flex-col justify-between ${
                                isSelected
                                  ? 'bg-sky-50 border-sky-500 ring-2 ring-sky-400/25 shadow-xs'
                                  : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                              }`}
                            >
                              <div>
                                <div className="flex items-center justify-between mb-2">
                                  {company.logo ? (
                                    <div className="w-12 h-10 rounded-lg bg-white border border-slate-200 p-0.5 flex items-center justify-center">
                                      <img src={company.logo} alt={company.name} className="w-full h-full object-contain" />
                                    </div>
                                  ) : (
                                    <div 
                                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow-xs"
                                      style={{ backgroundColor: company.accentColor }}
                                    >
                                      {company.shortName.charAt(0)}
                                    </div>
                                  )}
                                  {isSelected && (
                                    <span className="text-xs bg-sky-500 text-white px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                                      <Check size={11} strokeWidth={3} /> Selected
                                    </span>
                                  )}
                                </div>
                                <div className="font-bold text-xs text-slate-800">{company.shortName}</div>
                                <p className="text-[11px] text-slate-500 mt-0.5">{company.specialty}</p>
                              </div>
                              <div className="mt-2.5 pt-2 border-t border-slate-100 text-[10px] font-mono text-sky-700 truncate font-medium">
                                {company.email}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* STEP 2: AUDIENCE SELECTION */}
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-lg bg-sky-500 text-white font-bold text-xs flex items-center justify-center">2</span>
                          <h3 className="text-sm font-bold text-slate-800">Step 2: Select Target Audience & Recipients</h3>
                        </div>
                        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {getRecipientCount()}
                        </span>
                      </div>

                      {/* 4 Clean Audience Buttons */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        <button
                          type="button"
                          onClick={() => setTargetAudience('followup')}
                          className={`p-3 rounded-xl border transition text-left cursor-pointer flex flex-col justify-between ${
                            targetAudience === 'followup'
                              ? 'bg-amber-50/80 border-amber-400 font-semibold ring-2 ring-amber-300/30 shadow-xs'
                              : 'bg-white border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 text-xs text-amber-800">
                            <Target size={15} className="text-amber-500 shrink-0" />
                            <span>Pending Quotes</span>
                          </div>
                          <span className="text-[11px] text-slate-500 mt-1">42 Hot Leads</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setTargetAudience('all')}
                          className={`p-3 rounded-xl border transition text-left cursor-pointer flex flex-col justify-between ${
                            targetAudience === 'all'
                              ? 'bg-sky-50/80 border-sky-400 font-semibold ring-2 ring-sky-300/30 shadow-xs'
                              : 'bg-white border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 text-xs text-sky-800">
                            <Users size={15} className="text-sky-500 shrink-0" />
                            <span>All Hospitals</span>
                          </div>
                          <span className="text-[11px] text-slate-500 mt-1">2,840 Database</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setTargetAudience('specific')}
                          className={`p-3 rounded-xl border transition text-left cursor-pointer flex flex-col justify-between ${
                            targetAudience === 'specific'
                              ? 'bg-indigo-50/80 border-indigo-400 font-semibold ring-2 ring-indigo-300/30 shadow-xs'
                              : 'bg-white border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 text-xs text-indigo-800">
                            <Building2 size={15} className="text-indigo-500 shrink-0" />
                            <span>Specific Doctors</span>
                          </div>
                          <span className="text-[11px] text-slate-500 mt-1">{selectedCustomerIds.length} Selected</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setTargetAudience('new_sites')}
                          className={`p-3 rounded-xl border transition text-left cursor-pointer flex flex-col justify-between ${
                            targetAudience === 'new_sites'
                              ? 'bg-emerald-50/80 border-emerald-400 font-semibold ring-2 ring-emerald-300/30 shadow-xs'
                              : 'bg-white border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 text-xs text-emerald-800">
                            <Globe size={15} className="text-emerald-500 shrink-0" />
                            <span>70 Portals Launch</span>
                          </div>
                          <span className="text-[11px] text-slate-500 mt-1">1,420 Contacts</span>
                        </button>
                      </div>

                      {/* If Specific Doctors Selected: Show Simple Checklist */}
                      {targetAudience === 'specific' && (
                        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2 mt-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-semibold text-slate-700">Select Target Doctors & Hospitals:</span>
                            <button
                              type="button"
                              onClick={handleSelectAllCustomers}
                              className="text-sky-600 hover:text-sky-700 font-semibold text-[11px] cursor-pointer"
                            >
                              {selectedCustomerIds.length === MARKETING_CUSTOMERS.length ? 'Deselect All' : 'Select All'}
                            </button>
                          </div>
                          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                            {MARKETING_CUSTOMERS.map((cust) => (
                              <label
                                key={cust.id}
                                className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-200/70 text-xs cursor-pointer hover:border-sky-300 transition"
                              >
                                <div className="flex items-center gap-2">
                                  <input
                                    type="checkbox"
                                    checked={selectedCustomerIds.includes(cust.id)}
                                    onChange={() => handleToggleCustomer(cust.id)}
                                    className="rounded text-sky-500 cursor-pointer"
                                  />
                                  <div>
                                    <span className="font-semibold text-slate-800">{cust.name}</span>
                                    <span className="text-slate-400 text-[11px] ml-1.5">({cust.hospital})</span>
                                  </div>
                                </div>
                                <span className="font-mono text-emerald-600 font-semibold text-[11px]">{cust.quoteAmount}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* STEP 3: MESSAGE & TEMPLATE */}
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-lg bg-sky-500 text-white font-bold text-xs flex items-center justify-center">3</span>
                          <h3 className="text-sm font-bold text-slate-800">Step 3: Compose Email & Select Sales Template</h3>
                        </div>
                      </div>

                      {/* 1-Click Templates Pills */}
                      <div className="space-y-1.5">
                        <span className="text-[11px] font-semibold text-slate-500">1-Click Pre-Built Sales Templates:</span>
                        <div className="flex flex-wrap gap-2 text-xs">
                          {EMAIL_TEMPLATES.map((tpl) => (
                            <button
                              key={tpl.id}
                              type="button"
                              onClick={() => handleSelectTemplate(tpl.id)}
                              className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition cursor-pointer ${
                                selectedTemplateId === tpl.id
                                  ? 'bg-sky-500 text-white border-sky-500 shadow-xs font-semibold'
                                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                              }`}
                            >
                              {tpl.name}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Subject Line */}
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-700 block">Subject Line *</label>
                        <input
                          type="text"
                          value={campaignSubject}
                          onChange={(e) => setCampaignSubject(e.target.value)}
                          placeholder="e.g. Official Quotation & Priority Hospital Allocation - Raj Biosis"
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:bg-white focus:border-sky-400 font-medium transition"
                        />
                      </div>

                      {/* Tag Shortcut Helper Bar */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-semibold text-slate-700 block">Message Body *</label>
                          <div className="flex items-center gap-1.5 text-[11px]">
                            <span className="text-slate-400">Quick Tags:</span>
                            <button
                              type="button"
                              onClick={() => handleInsertTag('{Doctor_Name}')}
                              className="px-2 py-0.5 bg-slate-100 hover:bg-sky-100 text-slate-700 rounded text-[10px] font-mono cursor-pointer"
                            >
                              + Doctor Name
                            </button>
                            <button
                              type="button"
                              onClick={() => handleInsertTag('{Hospital_Name}')}
                              className="px-2 py-0.5 bg-slate-100 hover:bg-sky-100 text-slate-700 rounded text-[10px] font-mono cursor-pointer"
                            >
                              + Hospital Name
                            </button>
                            <button
                              type="button"
                              onClick={() => handleInsertTag('{Equipment_Name}')}
                              className="px-2 py-0.5 bg-slate-100 hover:bg-sky-100 text-slate-700 rounded text-[10px] font-mono cursor-pointer"
                            >
                              + Equipment
                            </button>
                          </div>
                        </div>
                        <textarea
                          rows={7}
                          value={campaignBody}
                          onChange={(e) => setCampaignBody(e.target.value)}
                          placeholder="Write your email body here or customize any pre-built template above..."
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:bg-white focus:border-sky-400 font-sans leading-relaxed transition"
                        />
                      </div>

                      {/* Simple CTA & Attachment in 1 row */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1 border-t border-slate-100">
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Call-To-Action (CTA) Button Text</label>
                          <input
                            type="text"
                            value={ctaText}
                            onChange={(e) => setCtaText(e.target.value)}
                            placeholder="Review Official OEM Quotation (PDF)"
                            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:bg-white focus:border-sky-400 mb-1.5"
                          />
                        </div>

                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Attach Technical Documents</label>
                          <label className="flex items-center gap-2 p-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer text-[11px] text-slate-700">
                            <input
                              type="checkbox"
                              checked={attachedDocs.includes('spec_sheet')}
                              onChange={() => handleToggleDoc('spec_sheet')}
                              className="rounded text-sky-500 cursor-pointer"
                            />
                            <Paperclip size={13} className="text-slate-400 shrink-0" />
                            <span>Attach Product Spec-Sheet & ISO-13485 PDF</span>
                          </label>
                        </div>
                      </div>

                      {/* Big, Clear Action Buttons */}
                      <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="text-xs text-slate-500">
                          Sender: <strong className="text-slate-800">{currentCompany.name}</strong> • Reach: <strong className="text-sky-600">{getRecipientCount()}</strong>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={handleSendTestEmail}
                            className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition cursor-pointer"
                          >
                            ✉️ Send Test Email
                          </button>

                          <button
                            type="button"
                            disabled={isSending}
                            onClick={handleSendCampaign}
                            className="px-6 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 disabled:opacity-50 text-white text-xs font-bold transition shadow-sm shadow-sky-500/25 flex items-center gap-2 cursor-pointer"
                          >
                            {isSending ? (
                              <>
                                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                                <span>Sending...</span>
                              </>
                            ) : (
                              <>
                                <Send size={14} />
                                <span>Send Campaign Now ({getRecipientCount()})</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* RIGHT COLUMN: LIVE REALISTIC EMAIL PREVIEW (5 Cols - Sticky) */}
                  <div className="xl:col-span-5 space-y-3 xl:sticky xl:top-20 self-start">
                    <div className="flex items-center justify-between bg-white px-4 py-2.5 rounded-2xl border border-slate-200/80 shadow-xs">
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                        <Eye size={15} className="text-sky-500" />
                        <span>Live Email Preview (Hospital Inbox)</span>
                      </div>
                      
                      <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-xs">
                        <button
                          type="button"
                          onClick={() => setPreviewDevice('desktop')}
                          className={`px-2 py-0.5 rounded transition text-[11px] font-medium flex items-center gap-1 cursor-pointer ${
                            previewDevice === 'desktop' ? 'bg-white text-sky-700 shadow-xs font-semibold' : 'text-slate-500'
                          }`}
                        >
                          <Laptop size={12} />
                          <span>Desktop</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setPreviewDevice('mobile')}
                          className={`px-2 py-0.5 rounded transition text-[11px] font-medium flex items-center gap-1 cursor-pointer ${
                            previewDevice === 'mobile' ? 'bg-white text-sky-700 shadow-xs font-semibold' : 'text-slate-500'
                          }`}
                        >
                          <Smartphone size={12} />
                          <span>Mobile</span>
                        </button>
                      </div>
                    </div>

                    {/* Realistic Email Box */}
                    <div 
                      className={`mx-auto bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden transition-all duration-300 max-h-[calc(100vh-9.5rem)] flex flex-col ${
                        previewDevice === 'mobile' ? 'max-w-sm' : 'w-full'
                      }`}
                    >
                      {/* Email Header Chrome */}
                      <div className="bg-slate-50 border-b border-slate-200/80 p-3 space-y-1.5 text-xs shrink-0">
                        <div className="font-bold text-slate-800 text-xs sm:text-sm">
                          {getPreviewSubject() || 'Official Hospital Procurement Communication'}
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2">
                          <span>From: <strong className="text-slate-700">{currentCompany.name}</strong> &lt;{currentCompany.email}&gt;</span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          To: Dr. S. K. Mehta &lt;dr.mehta@apollohospitals.com&gt;
                        </div>
                      </div>

                      {/* Email Content Body */}
                      <div className="p-5 space-y-3.5 bg-white text-xs text-slate-700 overflow-y-auto flex-1">

                        {/* Brand Banner */}
                        <div className="pb-3 border-b border-slate-100 flex items-center justify-between">
                          {selectedCompanyId === 'rajbiosis' ? (
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 bg-white p-1 rounded-xl border border-slate-200 shadow-2xs shrink-0 flex items-center justify-center">
                                <img src="/rajbiosis-logo.png" alt="Raj Biosis Private Limited" className="w-full h-full object-contain" />
                              </div>
                              <div>
                                <div className="font-bold text-slate-900 text-sm">Raj Biosis Private Limited</div>
                                <div className="text-[10px] text-slate-400">ICU & Critical Care Biomedical OEM</div>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2.5">
                              <div 
                                className="w-9 h-9 rounded-xl text-white font-bold flex items-center justify-center text-sm shadow-xs"
                                style={{ backgroundColor: currentCompany.accentColor }}
                              >
                                {currentCompany.shortName.charAt(0)}
                              </div>
                              <div>
                                <div className="font-bold text-slate-900 text-sm">{currentCompany.name}</div>
                                <div className="text-[10px] text-slate-400">{currentCompany.tagline}</div>
                              </div>
                            </div>
                          )}
                          <span className="text-[9px] bg-sky-50 text-sky-700 border border-sky-200 px-2 py-0.5 rounded-full font-mono">
                            Verified OEM
                          </span>
                        </div>

                        {/* Body Text */}
                        <div className="whitespace-pre-line text-xs sm:text-[12px] leading-relaxed text-slate-700">
                          {getPreviewBody() || 'Please compose your email message in the editor on the left.'}
                        </div>

                        {/* Attached Specs Highlight Box */}
                        {attachedDocs.includes('spec_sheet') && (
                          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs">
                            <div className="flex items-center gap-2 truncate">
                              <FileText size={14} className="text-rose-500 shrink-0" />
                              <span className="truncate font-medium text-slate-800">RajBiosis-Vent-Pro-X9-TechSpec.pdf</span>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono shrink-0">2.4 MB • PDF</span>
                          </div>
                        )}

                        {/* CTA Button Preview */}
                        <div className="pt-2 text-center">
                          <a
                            href={ctaUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-white text-xs font-bold shadow-xs hover:shadow-md transition"
                            style={{ backgroundColor: currentCompany.accentColor }}
                          >
                            <span>{ctaText || 'Review Official Quotation'}</span>
                            <ArrowRight size={13} />
                          </a>
                        </div>

                        {/* Simple Footer */}
                        <div className="pt-3 border-t border-slate-100 text-[10px] text-slate-400 text-center space-y-1">
                          <p className="font-semibold text-slate-600">{currentCompany.name} • {currentCompany.isoCert}</p>
                          <p>Toll-Free: <strong className="text-slate-600 font-mono">{currentCompany.phone}</strong> | Email: <strong className="text-slate-600 font-mono">{currentCompany.email}</strong></p>
                        </div>

                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* SUBTAB 2: DELIVERY LOGS & CAMPAIGN HISTORY */}
              {marketingSubTab === 'history' && (
                <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden space-y-4">
                  <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-base font-bold text-slate-800">Sent Campaigns & Performance Delivery Logs</h3>
                      <p className="text-xs text-slate-400">Tracking open rates, recipient reach, and inbox deliveries across all 3 biomedical companies.</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setMarketingSubTab('compose')}
                      className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-semibold transition flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
                    >
                      <Plus size={15} />
                      <span>New Campaign</span>
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-100 text-slate-400 font-semibold uppercase tracking-wider text-[10px] bg-slate-50/50">
                          <th className="py-3 px-4">Ref ID & Date</th>
                          <th className="py-3 px-4">Sender Division</th>
                          <th className="py-3 px-4">Subject & Campaign Name</th>
                          <th className="py-3 px-4">Target Audience</th>
                          <th className="py-3 px-4">Open Rate</th>
                          <th className="py-3 px-4">Delivery Status</th>
                          <th className="py-3 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100/70 font-medium text-slate-600">
                        {campaignHistory.map((camp) => (
                          <tr key={camp.id} className="hover:bg-sky-50/30 transition">
                            <td className="py-3 px-4">
                              <span className="font-mono font-semibold text-slate-700 block">{camp.id}</span>
                              <span className="text-[10px] text-slate-400">{camp.sentAt}</span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 border border-sky-100 font-semibold text-xs whitespace-nowrap inline-block">
                                {camp.company}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="font-semibold text-slate-800 text-xs block">{camp.subject}</span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="text-slate-700 font-medium">{camp.audience}</span>
                              <span className="text-[10px] text-slate-400 block font-mono">{camp.recipients} Recipients</span>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2">
                                <span className="font-bold font-mono text-emerald-600 text-xs">{camp.openRate}</span>
                                <div className="w-12 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                                  <div 
                                    className="h-full bg-emerald-500 rounded-full" 
                                    style={{ width: camp.openRate }}
                                  ></div>
                                </div>
                              </div>
                            </td>
                            <td className="py-3 px-4">
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/70">
                                <CheckCircle2 size={11} className="text-emerald-500" />
                                <span>{camp.status}</span>
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => {
                                  setCampaignSubject(camp.subject);
                                  setMarketingSubTab('compose');
                                }}
                                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition cursor-pointer"
                              >
                                Re-send
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

            </div>
          )}

        </main>
      </div>

      {/* =========================================================================
          CREATE NEW WEBSITE MODAL (SIMPLIFIED & CONNECTED TO VISUAL BUILDER)
          ========================================================================= */}
      {isAddSiteOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/30 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 max-h-[92vh] overflow-y-auto shadow-2xl">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center font-bold shadow-md shadow-sky-500/20">
                  {editingSiteId ? <Edit3 size={18} /> : <Sparkles size={19} />}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">
                    {editingSiteId ? `Edit Website: ${newDomain || 'Site Config'}` : 'Launch New Biomedical Website'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {editingSiteId 
                      ? 'Update domain identity and open in Visual Page Builder.'
                      : 'Nayi website launch karein aur sidha Visual Page Builder me customize karein.'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => { setIsAddSiteOpen(false); resetForm(); }} 
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-50 transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={(e) => handleSaveSite(e, false)} className="space-y-4">
              <div className="space-y-4 text-xs">
                
                {/* Storefront UI Style Bar with 1-Click Shuffle */}
                <div className="p-3 bg-gradient-to-r from-sky-50 via-indigo-50 to-purple-50 rounded-2xl border border-sky-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
                  <div className="space-y-0.5">
                    <span className="text-[11px] font-bold text-slate-800 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span>Assigned UI Style (Har Website Ke Liye Unique):</span>
                    </span>
                    <p className="text-[10px] text-slate-500 flex flex-wrap items-center gap-1">
                      <span className="font-semibold text-sky-700">{newHeaderStyle}</span> • 
                      <span className="font-semibold text-indigo-700">{newHomepageLayout}</span> • 
                      <span className="font-semibold text-purple-700">{newCardStyle}</span> • 
                      <span className="font-semibold text-slate-700">{newFont}</span>
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={randomizeLaunchUiStyle}
                    className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-200/80 font-bold text-[11px] shadow-2xs hover:shadow-xs transition flex items-center gap-1.5 shrink-0 self-start sm:self-auto cursor-pointer"
                    title="Click karke dusra naya UI style generate karein"
                  >
                    <Dices size={14} className="text-indigo-600" />
                    <span>🎲 Shuffle Fresh UI</span>
                  </button>
                </div>

                {/* 1. Parent Company Ownership */}
                <div>
                  <label className="text-slate-700 font-bold block mb-1.5">
                    Parent Brand / Company Ownership *
                  </label>
                  <select
                    value={newCompanyId}
                    onChange={(e) => setNewCompanyId(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:bg-white focus:border-sky-400 font-semibold transition"
                  >
                    <option value="rajbiosis">Raj Biosis Private Limited (Flagship OEM Division)</option>
                    <option value="human_bio">Human Biomedicals (Patient Monitoring & Life Support)</option>
                    <option value="global_bio">Global Biomedical (Precision Radiology & Diagnostic Imaging)</option>
                  </select>
                </div>

                {/* 2. Domain & Brand Name */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-slate-700 font-bold block mb-1.5">Domain Name *</label>
                    <input
                      type="text"
                      required
                      value={newDomain}
                      onChange={(e) => setNewDomain(e.target.value)}
                      placeholder="e.g. aerorespi.in / medsurge.com"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:bg-white focus:border-sky-400 font-mono transition placeholder-slate-400 font-medium"
                    />
                  </div>

                  <div>
                    <label className="text-slate-700 font-bold block mb-1.5">Brand / Website Name *</label>
                    <input
                      type="text"
                      required
                      value={newBrandName}
                      onChange={(e) => setNewBrandName(e.target.value)}
                      placeholder="e.g. AeroRespi Medical Systems"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:bg-white focus:border-sky-400 transition placeholder-slate-400 font-medium"
                    />
                  </div>
                </div>

                {/* 3. Primary Theme Color (Interactive Picker + Quick Palettes) */}
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-slate-700 font-bold flex items-center gap-1.5">
                      <Palette size={14} className="text-sky-500" />
                      <span>Primary Brand Theme Color:</span>
                    </label>
                    <span className="font-mono text-slate-600 font-semibold">{newColor}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={newColor}
                      onChange={(e) => setNewColor(e.target.value)}
                      className="w-9 h-9 rounded-xl border-0 cursor-pointer p-0 shrink-0"
                    />
                    <div className="flex items-center gap-2 flex-wrap">
                      {[
                        { name: 'Sky Clinical', color: '#0ea5e9' },
                        { name: 'Emerald Bio', color: '#059669' },
                        { name: 'Cyber Indigo', color: '#4f46e5' },
                        { name: 'Emergency Rose', color: '#e11d48' },
                        { name: 'Precision Violet', color: '#7c3aed' },
                        { name: 'Clinical Amber', color: '#d97706' }
                      ].map(p => (
                        <button
                          key={p.name}
                          type="button"
                          onClick={() => setNewColor(p.color)}
                          className={`w-6 h-6 rounded-full border-2 transition transform hover:scale-110 cursor-pointer ${
                            newColor === p.color ? 'border-slate-800 ring-2 ring-sky-300' : 'border-white shadow-xs'
                          }`}
                          style={{ backgroundColor: p.color }}
                          title={p.name}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                {/* 4. Contact Essentials */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-slate-600 font-semibold block mb-1">Toll-Free Phone</label>
                    <input
                      type="text"
                      value={newPhone}
                      onChange={(e) => setNewPhone(e.target.value)}
                      placeholder="1800-419-BIOSIS"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:bg-white focus:border-sky-400 font-mono transition placeholder-slate-400"
                    />
                  </div>

                  <div>
                    <label className="text-slate-600 font-semibold block mb-1">Official Support Email</label>
                    <input
                      type="email"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="sales@biomedical.in"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:bg-white focus:border-sky-400 font-mono transition placeholder-slate-400"
                    />
                  </div>
                </div>

                {/* 5. City Hub & WhatsApp */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-slate-600 font-semibold block mb-1">Warehouse / City Hub</label>
                    <input
                      type="text"
                      value={newCity}
                      onChange={(e) => setNewCity(e.target.value)}
                      placeholder="e.g. Mumbai / New Delhi / Bangalore"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:bg-white focus:border-sky-400 transition placeholder-slate-400"
                    />
                  </div>

                  <div>
                    <label className="text-slate-600 font-semibold block mb-1">WhatsApp RFQ Desk</label>
                    <input
                      type="text"
                      value={newWhatsapp}
                      onChange={(e) => setNewWhatsapp(e.target.value)}
                      placeholder="+91 98000 12345 (Doctor Chat)"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:bg-white focus:border-sky-400 font-mono transition placeholder-slate-400"
                    />
                  </div>
                </div>

                {/* 6. Tagline */}
                <div>
                  <label className="text-slate-600 font-semibold block mb-1">Brand Tagline / Mission (Optional)</label>
                  <input
                    type="text"
                    value={newTagline}
                    onChange={(e) => setNewTagline(e.target.value)}
                    placeholder="e.g. Precision ICU Ventilators & Critical Life Support Systems"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:bg-white focus:border-sky-400 transition placeholder-slate-400"
                  />
                </div>

                {/* 7. Collapsible Advanced Layout Presets */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAdvancedLaunchSettings(!showAdvancedLaunchSettings)}
                    className="w-full py-2 px-3 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center justify-between border border-slate-200 transition cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5">
                      <Settings size={14} className="text-slate-500" />
                      <span>Advanced Presets (Font, Header Style, Layout) — Optional</span>
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      {showAdvancedLaunchSettings ? '▲ Hide Advanced' : '▼ Show Advanced'}
                    </span>
                  </button>

                  {showAdvancedLaunchSettings && (
                    <div className="mt-3 p-4 bg-slate-50/70 rounded-2xl border border-slate-200 space-y-3.5 animate-in fade-in duration-150">
                      
                      {/* Typography Font */}
                      <div className="space-y-1">
                        <label className="text-slate-600 font-semibold block">Typography Font Family</label>
                        <select
                          value={newFont}
                          onChange={(e) => setNewFont(e.target.value)}
                          className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-slate-800 outline-none focus:border-sky-400"
                        >
                          {PRESET_FONTS.map(f => (
                            <option key={f.value} value={f.value}>{f.label}</option>
                          ))}
                        </select>
                      </div>

                      {/* Header Style */}
                      <div className="space-y-1">
                        <label className="text-slate-600 font-semibold block">Header Style</label>
                        <select
                          value={newHeaderStyle}
                          onChange={(e) => setNewHeaderStyle(e.target.value)}
                          className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-slate-800 outline-none focus:border-sky-400"
                        >
                          {PRESET_HEADER_STYLES.map(h => (
                            <option key={h.value} value={h.value}>{h.label}</option>
                          ))}
                        </select>
                      </div>

                      {/* Homepage Layout Style */}
                      <div className="space-y-1">
                        <label className="text-slate-600 font-semibold block">Homepage Layout Architecture</label>
                        <select
                          value={newHomepageLayout}
                          onChange={(e) => setNewHomepageLayout(e.target.value)}
                          className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-slate-800 outline-none focus:border-sky-400"
                        >
                          {PRESET_HOMEPAGE_LAYOUTS.map(l => (
                            <option key={l.value} value={l.value}>{l.label}</option>
                          ))}
                        </select>
                      </div>

                      {/* Product Card Design */}
                      <div className="space-y-1">
                        <label className="text-slate-600 font-semibold block">Product Card Design</label>
                        <select
                          value={newCardStyle}
                          onChange={(e) => setNewCardStyle(e.target.value)}
                          className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-slate-800 outline-none focus:border-sky-400"
                        >
                          {PRESET_CARD_STYLES.map(c => (
                            <option key={c.value} value={c.value}>{c.label}</option>
                          ))}
                        </select>
                      </div>

                      {/* Primary Category Focus */}
                      <div className="space-y-1">
                        <label className="text-slate-600 font-semibold block">Primary Category Focus</label>
                        <select
                          value={newCategoryFocus}
                          onChange={(e) => setNewCategoryFocus(e.target.value)}
                          className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-slate-800 outline-none focus:border-sky-400"
                        >
                          {PRESET_CATEGORIES.map(c => (
                            <option key={c.value} value={c.value}>{c.label}</option>
                          ))}
                        </select>
                      </div>

                    </div>
                  )}
                </div>

              </div>

              {/* Form Action Buttons Bar */}
              <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setPreviewingSite({
                      id: editingSiteId || 'site-preview',
                      domain: newDomain.trim() || 'preview-demo.in',
                      brandName: newBrandName.trim() || 'Biomedical Life Systems',
                      tagline: newTagline.trim() || 'Hospital Critical Equipment',
                      primaryColor: newColor,
                      font: newFont || 'Plus Jakarta Sans',
                      headerStyle: newHeaderStyle || 'Telemetry Bar',
                      homepageLayout: newHomepageLayout || 'Banner Carousel',
                      cardStyle: newCardStyle || 'Bordered Minimal',
                      categoryFocus: newCategoryFocus || 'All Clinical Departments',
                      phone: newPhone || '1800-419-BIOSIS',
                      email: newEmail || `sales@${newDomain.trim() || 'preview-demo.in'}`,
                      city: newCity || 'New Delhi, India',
                      themeMode: newThemeMode,
                      whatsapp: newWhatsapp,
                      heroTitle: newHeroTitle,
                      announcement: newAnnouncement
                    });
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 text-xs font-semibold transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Eye size={13} />
                  <span>Preview Config</span>
                </button>

                <div className="flex items-center gap-2 justify-end flex-wrap">
                  <button
                    type="button"
                    onClick={() => { setIsAddSiteOpen(false); resetForm(); }}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-600 text-xs font-semibold transition cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border border-slate-200"
                    title="Direct save without opening builder"
                  >
                    <Plus size={13} />
                    <span>⚡ Quick Launch</span>
                  </button>

                  {/* Primary Highlighted Button: Launch & Open in Visual Page Builder */}
                  <button
                    type="button"
                    onClick={(e) => handleSaveSite(e, true)}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white text-xs font-bold transition shadow-md shadow-sky-500/25 flex items-center gap-2 cursor-pointer"
                    title="Launch website and immediately open Full-Page Visual Customizer"
                  >
                    <Sparkles size={14} />
                    <span>🎨 Launch in Visual Page Builder</span>
                  </button>
                </div>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* =========================================================================
          LIVE WEBSITE SANDBOX PREVIEW MODAL (Full Device Switcher & Real Storefront)
          ========================================================================= */}
      {previewingSite && (
        <div className="fixed inset-0 z-50 bg-slate-900/30 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6 animate-in fade-in duration-200">
          <div className="bg-white border border-slate-200/90 rounded-3xl w-full max-w-7xl h-[94vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Top Chrome / Navigation Bar */}
            <div className="bg-slate-50/90 border-b border-slate-200 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
              {/* Site Details Pill */}
              <div className="flex items-center gap-3">
                <div 
                  className="w-3.5 h-3.5 rounded-full ring-2 ring-slate-300 shrink-0 shadow-xs" 
                  style={{ backgroundColor: previewingSite.primaryColor }}
                  title={`Brand Color: ${previewingSite.primaryColor}`}
                />
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-800 text-sm">{previewingSite.brandName}</span>
                  <span className="font-mono text-xs text-sky-700 bg-sky-50 border border-sky-200 px-2 py-0.5 rounded-md font-semibold">
                    {previewingSite.domain}
                  </span>
                </div>
                <span className="hidden md:inline-block text-[11px] text-slate-500 border-l border-slate-200 pl-3">
                  Font: <strong className="text-slate-700">{previewingSite.font}</strong> | Focus: <strong className="text-slate-700">{previewingSite.categoryFocus}</strong>
                </span>
              </div>

              {/* Center: Device Viewport Switcher */}
              <div className="flex items-center bg-slate-200/70 p-1 rounded-xl border border-slate-200 text-xs">
                <button
                  type="button"
                  onClick={() => setPreviewDeviceMode('desktop')}
                  className={`px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5 transition cursor-pointer ${
                    previewDeviceMode === 'desktop'
                      ? 'bg-white text-sky-700 shadow-xs font-bold border border-slate-200/80'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Desktop Full Width (100%)"
                >
                  <Laptop size={14} />
                  <span className="hidden sm:inline">Desktop</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDeviceMode('tablet')}
                  className={`px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5 transition cursor-pointer ${
                    previewDeviceMode === 'tablet'
                      ? 'bg-white text-sky-700 shadow-xs font-bold border border-slate-200/80'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Tablet Mode (768px)"
                >
                  <Tablet size={14} />
                  <span className="hidden sm:inline">Tablet</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDeviceMode('mobile')}
                  className={`px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5 transition cursor-pointer ${
                    previewDeviceMode === 'mobile'
                      ? 'bg-white text-sky-700 shadow-xs font-bold border border-slate-200/80'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Mobile View (390px)"
                >
                  <Smartphone size={14} />
                  <span className="hidden sm:inline">Mobile</span>
                </button>
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-2">
                <Link
                  href={`/preview/${previewingSite.domain}?sandbox=true`}
                  target="_blank"
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-sky-600 text-xs font-semibold transition flex items-center gap-1.5 shadow-2xs"
                  title="Open Full Screen in New Tab"
                >
                  <span>Open Full Tab</span>
                  <ExternalLink size={13} />
                </Link>

                <button
                  type="button"
                  onClick={() => {
                    const s = previewingSite;
                    setPreviewingSite(null);
                    openEditSite(s);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                  title="Edit Colors, Fonts & Layout"
                >
                  <Edit3 size={13} />
                  <span className="hidden sm:inline">Edit Config</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPreviewingSite(null)}
                  className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-400 hover:text-rose-500 border border-slate-200/60 flex items-center justify-center transition cursor-pointer"
                  title="Close Preview"
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            {/* Viewport Frame Container */}
            <div className="flex-1 bg-slate-100/80 p-2 sm:p-4 overflow-hidden flex items-center justify-center">
              <div 
                className={`h-full bg-white transition-all duration-300 rounded-2xl overflow-hidden shadow-xl flex flex-col ${
                  previewDeviceMode === 'mobile' 
                    ? 'w-[390px] border-4 border-slate-300' 
                    : previewDeviceMode === 'tablet' 
                    ? 'w-[768px] border-4 border-slate-300' 
                    : 'w-full border border-slate-200'
                }`}
              >
                <iframe
                  src={`/preview/${previewingSite.domain}?sandbox=true`}
                  className="w-full h-full border-0 bg-white"
                  title={`Live Storefront for ${previewingSite.domain}`}
                />
              </div>
            </div>

            {/* Bottom Status Ribbon */}
            <div className="bg-slate-50 border-t border-slate-200 px-4 py-2 flex items-center justify-between text-[11px] text-slate-500 shrink-0">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Multi-Site Biomedical Engine: Configured in MongoDB Atlas. Instant real-time updates.</span>
              </div>
              <div className="hidden sm:flex items-center gap-3 font-mono">
                <span>Viewport: {previewDeviceMode.toUpperCase()}</span>
                <span>•</span>
                <span>MongoDB Live Synced</span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Visual Page Builder Modal (WordPress / Elementor Blocks) */}
      {isBuilderOpen && builderSite && (
        <VisualPageBuilder
          isOpen={isBuilderOpen}
          site={builderSite}
          existingSites={sites}
          onClose={() => {
            setIsBuilderOpen(false);
            setBuilderSite(null);
          }}
          onSaveSuccess={(updatedBlocks, fullUpdatedSite) => {
            const updated = fullUpdatedSite || { ...builderSite, layoutBlocks: updatedBlocks };
            setSites(prev => prev.map(s => s.domain === builderSite.domain ? { ...s, ...updated } : s));
            setBuilderSite(prev => ({ ...prev, ...updated }));
            loadSitesFromDb();
          }}
        />
      )}

      {/* Mass Sync / Bulk Update Modal */}
      {isBulkUpdateOpen && (
        <BulkUpdateModal
          isOpen={isBulkUpdateOpen}
          onClose={() => setIsBulkUpdateOpen(false)}
          sites={sites}
          onSuccess={() => {
            loadSitesFromDb();
          }}
        />
      )}

      {/* Dashboard External Site Theme Importer Modal */}
      {isDashboardImporterOpen && (
        <SiteThemeImporterModal
          isOpen={isDashboardImporterOpen}
          onClose={() => setIsDashboardImporterOpen(false)}
          targetSite={null}
          existingSites={sites}
          onApplyExtractedTheme={handleApplyImportedThemeDashboard}
        />
      )}

    </div>
  );
}
